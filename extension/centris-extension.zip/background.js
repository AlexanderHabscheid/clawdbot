// Sentris AI Browser Control Extension - Background Script
// Handles communication with desktop app and browser control APIs with vision capabilities
//
// Communication Priority:
// 1. Native Messaging (fastest, ~1-2ms overhead)
// 2. WebSocket (fallback, ~5-10ms overhead)
//
// Memory & Context Persistence:
// - TabContextManager: Tracks context across browser tabs
// - CrossTabSync: Syncs memory across tabs and devices

// ═══════════════════════════════════════════════════════════════════════════
// IMPORT MODULES (Manifest V3 Service Worker)
// ═══════════════════════════════════════════════════════════════════════════
try {
  importScripts('tab_context.js', 'cross_tab_sync.js');
  console.log('[Background] Imported tab_context.js and cross_tab_sync.js');
} catch (e) {
  console.warn('[Background] Could not import memory modules:', e.message);
}

// Configuration for backend connection
// For local development: connects to localhost
// For future SaaS: can be configured via chrome.storage
const CONFIG = {
  // Native Messaging host name (must match manifest)
  NATIVE_HOST_NAME: 'com.centris.host',
  
  // Whether to prefer Native Messaging over WebSocket
  PREFER_NATIVE_MESSAGING: true,
  
  // Get WebSocket URL for extension connection
  getExtensionWebSocketUrl: async function() {
    return new Promise((resolve) => {
      // Check user config (for future SaaS support)
      chrome.storage.sync.get(['backend_url'], (result) => {
        if (result.backend_url) {
          // User configured remote backend
          resolve(result.backend_url);
        } else {
          // Default: localhost for local development
          resolve('ws://localhost:8765');
        }
      });
    });
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// COMMUNICATION STATE
// ═══════════════════════════════════════════════════════════════════════════

// Communication method: 'native_messaging' | 'websocket' | 'disconnected'
let communicationMethod = 'disconnected';

// Native Messaging state
let nativePort = null;
let nativeMessagingAvailable = false;
let nativeMessagingRetryCount = 0;
const MAX_NATIVE_MESSAGING_RETRIES = 3;

// WebSocket state
let wsConnection = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

// Vision streaming state
let visionStreamingActive = false;
let visionStreamInterval = null;
let visionStreamCallbacks = new Map(); // tabId -> callback

// Browser process monitoring
let processMonitorActive = false;
let tabProcessInfo = new Map(); // tabId -> {memory, cpu, status}

// ═══════════════════════════════════════════════════════════════════════════
// CDP OVERLAY SYSTEM - Works on ALL sites including Gmail (bypasses CSP)
// Uses Chrome DevTools Protocol via chrome.debugger API
// This is how Chrome DevTools itself draws element highlights!
// ═══════════════════════════════════════════════════════════════════════════

// Track which tabs have debugger attached
const debuggerAttachedTabs = new Map(); // tabId -> boolean

/**
 * Attach debugger to a tab (required for CDP overlay)
 * Note: This will show a "debugging this tab" banner which is actually GOOD
 * - It shows the user the tab is being controlled by AI
 */
async function attachDebugger(tabId) {
  if (debuggerAttachedTabs.get(tabId)) {
    return true; // Already attached
  }
  
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
    debuggerAttachedTabs.set(tabId, true);
    logWithTimestamp('info', `🔧 CDP: Attached debugger to tab ${tabId} (AI control indicator shown)`);
    
    // Enable the Overlay domain for drawing
    await chrome.debugger.sendCommand({ tabId }, 'Overlay.enable');
    
    return true;
  } catch (e) {
    logWithTimestamp('warn', `⚠️ CDP: Could not attach debugger to tab ${tabId}: ${e.message}`);
    return false;
  }
}

/**
 * Detach debugger from a tab
 */
async function detachDebugger(tabId) {
  if (!debuggerAttachedTabs.get(tabId)) {
    return;
  }
  
  try {
    await chrome.debugger.detach({ tabId });
    debuggerAttachedTabs.delete(tabId);
    logWithTimestamp('info', `🔧 CDP: Detached debugger from tab ${tabId}`);
  } catch (e) {
    // Ignore - might already be detached
    debuggerAttachedTabs.delete(tabId);
  }
}

/**
 * Highlight an element using CDP Overlay.highlightRect
 * This works on ALL sites including Gmail!
 */
async function cdpHighlightRect(tabId, x, y, width, height, durationMs = 2000) {
  try {
    const attached = await attachDebugger(tabId);
    if (!attached) {
      logWithTimestamp('warn', 'CDP highlight skipped - debugger not attached');
      return false;
    }
    
    // Draw a highlighted rectangle using CDP
    await chrome.debugger.sendCommand({ tabId }, 'Overlay.highlightRect', {
      x: Math.round(x),
      y: Math.round(y),
      width: Math.round(width),
      height: Math.round(height),
      color: { r: 252, g: 102, b: 26, a: 0.3 },  // Orange fill with transparency
      outlineColor: { r: 252, g: 102, b: 26, a: 1 }  // Solid orange outline
    });
    
    logWithTimestamp('info', `🎯 CDP: Highlighted rect at (${x}, ${y}) ${width}x${height}`);
    
    // Hide highlight after duration
    setTimeout(async () => {
      try {
        await chrome.debugger.sendCommand({ tabId }, 'Overlay.hideHighlight');
      } catch (e) {
        // Ignore - tab might have closed
      }
    }, durationMs);
    
    return true;
  } catch (e) {
    logWithTimestamp('warn', `⚠️ CDP highlight failed: ${e.message}`);
    return false;
  }
}

/**
 * Show a visual cursor click indicator using CDP
 * Draws a cursor + ripple effect at the click location
 */
async function cdpShowClickIndicator(tabId, x, y, durationMs = 1500) {
  try {
    const attached = await attachDebugger(tabId);
    if (!attached) {
      return false;
    }
    
    // Use Overlay.highlightRect to show a click indicator
    // We'll draw a small circle/square at the click point
    const size = 30;
    await chrome.debugger.sendCommand({ tabId }, 'Overlay.highlightRect', {
      x: Math.round(x - size/2),
      y: Math.round(y - size/2),
      width: size,
      height: size,
      color: { r: 252, g: 102, b: 26, a: 0.6 },  // Orange with transparency
      outlineColor: { r: 252, g: 102, b: 26, a: 1 }  // Solid orange
    });
    
    logWithTimestamp('info', `👆 CDP: Click indicator at (${x}, ${y})`);
    
    // Hide after duration
    setTimeout(async () => {
      try {
        await chrome.debugger.sendCommand({ tabId }, 'Overlay.hideHighlight');
      } catch (e) {
        // Ignore
      }
    }, durationMs);
    
    return true;
  } catch (e) {
    logWithTimestamp('warn', `⚠️ CDP click indicator failed: ${e.message}`);
    return false;
  }
}

/**
 * Show an inspection message/tooltip using CDP
 */
async function cdpShowInspectMessage(tabId, message, x, y) {
  try {
    const attached = await attachDebugger(tabId);
    if (!attached) {
      return false;
    }
    
    // Use inspect mode to show a message
    await chrome.debugger.sendCommand({ tabId }, 'Overlay.setShowViewportSizeOnResize', {
      show: false
    });
    
    // Note: Full message overlay requires more complex CDP usage
    // For now, the highlight + debugger banner serves as visual feedback
    return true;
  } catch (e) {
    return false;
  }
}

// Clean up debugger when tab closes
chrome.tabs.onRemoved.addListener((tabId) => {
  debuggerAttachedTabs.delete(tabId);
});

// Handle debugger detach events
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId) {
    debuggerAttachedTabs.delete(source.tabId);
    logWithTimestamp('info', `🔧 CDP: Debugger detached from tab ${source.tabId}: ${reason}`);
  }
});

// Detailed logging utility
function logWithTimestamp(level, message, data = null) {
  const timestamp = new Date().toISOString();
  const prefix = `[Sentris Extension ${timestamp}]`;
  const logMessage = data ? `${prefix} ${message}` : `${prefix} ${message}`;
  
  switch (level) {
    case 'info':
      console.log(logMessage, data || '');
      break;
    case 'warn':
      console.warn(logMessage, data || '');
      break;
    case 'error':
      console.error(logMessage, data || '');
      break;
    case 'debug':
      console.debug(logMessage, data || '');
      break;
    default:
      console.log(logMessage, data || '');
  }
}

// Connection state tracking
let connectionState = {
  lastConnectionAttempt: null,
  lastSuccessfulConnection: null,
  lastDisconnection: null,
  handshakeSent: false,
  handshakeAcknowledged: false,
  messageCount: { sent: 0, received: 0 },
  communicationMethod: 'disconnected'  // 'native_messaging' | 'websocket' | 'disconnected'
};

// ═══════════════════════════════════════════════════════════════════════════
// NATIVE MESSAGING FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Try to connect via Native Messaging first (faster)
 * Falls back to WebSocket if Native Messaging is not available
 */
async function initializeCommunication() {
  logWithTimestamp('info', '🚀 Initializing communication...', {
    preferNative: CONFIG.PREFER_NATIVE_MESSAGING
  });
  
  if (CONFIG.PREFER_NATIVE_MESSAGING) {
    // Try Native Messaging first
    const nativeConnected = await tryConnectNativeMessaging();
    if (nativeConnected) {
      communicationMethod = 'native_messaging';
      connectionState.communicationMethod = 'native_messaging';
      logWithTimestamp('info', '✅ Using Native Messaging (fastest mode)', {
        method: 'native_messaging',
        overhead: '~1-2ms'
      });
      return;
    }
  }
  
  // Fall back to WebSocket
  logWithTimestamp('info', '📡 Falling back to WebSocket connection', {
    reason: CONFIG.PREFER_NATIVE_MESSAGING ? 'Native Messaging not available' : 'Native Messaging disabled'
  });
  communicationMethod = 'websocket';
  connectionState.communicationMethod = 'websocket';
  await connectToDesktopApp();
}

/**
 * Diagnose Native Messaging errors based on error message
 */
function getNativeMessagingErrorDiagnosis(errorMessage) {
  if (!errorMessage) return null;
  
  const errorLower = errorMessage.toLowerCase();
  
  if (errorLower.includes('specified native messaging host not found') || 
      errorLower.includes('host not found')) {
    return {
      issue: 'Native host manifest not installed',
      solution: 'Run install_native_host.sh to install the manifest',
      manifestPath: '~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.centris.host.json'
    };
  }
  
  if (errorLower.includes('access denied') || errorLower.includes('permission')) {
    return {
      issue: 'Permission denied',
      solution: 'Check file permissions on host script and manifest',
      checkScript: 'ls -l /usr/local/bin/centris_host.py',
      checkManifest: 'ls -l ~/Library/Application\\ Support/Google/Chrome/NativeMessagingHosts/com.centris.host.json'
    };
  }
  
  if (errorLower.includes('invalid extension') || errorLower.includes('extension id')) {
    return {
      issue: 'Extension ID mismatch',
      solution: 'Update manifest with correct extension ID from chrome://extensions',
      manifestPath: '~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.centris.host.json'
    };
  }
  
  if (errorLower.includes('could not connect') || errorLower.includes('connection')) {
    return {
      issue: 'Host script connection failed',
      solution: 'Check if host script exists and is executable',
      checkScript: 'which python3 && ls -l /usr/local/bin/centris_host.py'
    };
  }
  
  return {
    issue: 'Unknown error',
    solution: 'Check Chrome console and host script logs',
    checkLogs: 'Check Console.app for centris_host.py errors'
  };
}

/**
 * Try to connect via Native Messaging
 * Returns true if successful, false if should fall back to WebSocket
 */
async function tryConnectNativeMessaging() {
  return new Promise((resolve) => {
    try {
      logWithTimestamp('info', '🔌 Attempting Native Messaging connection...', {
        hostName: CONFIG.NATIVE_HOST_NAME,
        attempt: nativeMessagingRetryCount + 1,
        extensionId: chrome.runtime.id
      });
      
      // Connect to native host
      nativePort = chrome.runtime.connectNative(CONFIG.NATIVE_HOST_NAME);
      
      // Check for immediate errors (Chrome sets lastError synchronously)
      const immediateError = chrome.runtime.lastError;
      if (immediateError) {
        logWithTimestamp('error', '❌ Native Messaging connection failed immediately', {
          error: immediateError.message,
          hostName: CONFIG.NATIVE_HOST_NAME,
          extensionId: chrome.runtime.id,
          commonCauses: [
            'Native host manifest not installed',
            'Extension ID mismatch in manifest',
            'Host script not found or not executable',
            'Python3 not available in PATH'
          ]
        });
        nativeMessagingAvailable = false;
        nativePort = null;
        resolve(false);
        return;
      }
      
      if (!nativePort) {
        logWithTimestamp('warn', '⚠️ Native Messaging port is null', {
          hostName: CONFIG.NATIVE_HOST_NAME,
          extensionId: chrome.runtime.id
        });
        nativeMessagingAvailable = false;
        resolve(false);
        return;
      }
      
      // Set up message handler
      nativePort.onMessage.addListener((message) => {
        handleNativeMessage(message);
      });
      
      // Set up disconnect handler
      nativePort.onDisconnect.addListener(() => {
        const error = chrome.runtime.lastError;
        const errorDetails = error ? {
          message: error.message,
          // Common error messages and their meanings
          diagnosis: getNativeMessagingErrorDiagnosis(error.message)
        } : {
          message: 'No error message (disconnected without error)',
          possibleCauses: [
            'Host script exited immediately',
            'Host script crashed on startup',
            'Python3 not found or script syntax error',
            'Host script path incorrect in manifest'
          ]
        };
        
        logWithTimestamp('warn', '🔌 Native Messaging disconnected', {
          ...errorDetails,
          wasConnected: nativeMessagingAvailable,
          hostName: CONFIG.NATIVE_HOST_NAME,
          extensionId: chrome.runtime.id
        });
        
        nativePort = null;
        nativeMessagingAvailable = false;
        
        // If we were using Native Messaging, fall back to WebSocket
        if (communicationMethod === 'native_messaging') {
          logWithTimestamp('info', '📡 Falling back to WebSocket after Native Messaging disconnect');
          communicationMethod = 'websocket';
          connectionState.communicationMethod = 'websocket';
          connectToDesktopApp();
        }
      });
      
      // Wait a short time for connection to establish
      setTimeout(() => {
        if (nativePort) {
          // Send handshake
          const handshakeMessage = {
            type: 'extension_ready',
            version: '2.0.0',
            extensionId: chrome.runtime.id,
            capabilities: [
              'native_messaging',
              'vision_streaming',
              'full_page_screenshots',
              'element_screenshots',
              'vision_based_detection',
              'coordinate_clicking',
              'process_monitoring',
              'window_management'
            ]
          };
          
          try {
            nativePort.postMessage(handshakeMessage);
            nativeMessagingAvailable = true;
            logWithTimestamp('info', '✅ Native Messaging handshake sent', {
              extensionId: chrome.runtime.id
            });
            resolve(true);
          } catch (e) {
            logWithTimestamp('error', '❌ Failed to send Native Messaging handshake', {
              error: e.message
            });
            nativeMessagingAvailable = false;
            resolve(false);
          }
        } else {
          logWithTimestamp('warn', '⚠️ Native port became null during setup');
          resolve(false);
        }
      }, 100);
      
    } catch (e) {
      logWithTimestamp('warn', '⚠️ Native Messaging not available', {
        error: e.message,
        hostName: CONFIG.NATIVE_HOST_NAME
      });
      nativeMessagingAvailable = false;
      nativePort = null;
      resolve(false);
    }
  });
}

/**
 * Handle message received from Native Messaging host
 */
function handleNativeMessage(message) {
  const receiveTime = new Date().toISOString();
  connectionState.messageCount.received++;
  
  logWithTimestamp('debug', '📥 Native message received', {
    type: message.type,
    id: message.id,
    receiveTime
  });
  
  // Handle host_ready message (initial handshake from host)
  if (message.type === 'host_ready') {
    logWithTimestamp('info', '✅ Native host ready', {
      version: message.version,
      backendConnected: message.backend_connected,
      pid: message.pid
    });
    connectionState.handshakeAcknowledged = true;
    return;
  }
  
  // Handle fallback signal from host
  if (message.fallback_to_websocket) {
    logWithTimestamp('info', '📡 Host requested fallback to WebSocket', {
      reason: message.error
    });
    nativeMessagingAvailable = false;
    communicationMethod = 'websocket';
    connectionState.communicationMethod = 'websocket';
    connectToDesktopApp();
    return;
  }
  
  // Handle handshake acknowledgment
  if (message.type === 'handshake_ack') {
    logWithTimestamp('info', '✅ Native Messaging handshake acknowledged', {
      backendConnected: message.backend_connected
    });
    connectionState.handshakeAcknowledged = true;
    return;
  }
  
  // Handle pong (keep-alive response)
  if (message.type === 'pong') {
    logWithTimestamp('debug', '📡 Pong received from native host');
    return;
  }
  
  // Forward other messages to handleDesktopAppMessage
  // This processes commands the same way as WebSocket messages
  handleDesktopAppMessage(message);
}

/**
 * Send message via the best available method (Native Messaging or WebSocket)
 * This is the unified send function that replaces direct WebSocket sends
 */
function sendMessage(message) {
  connectionState.messageCount.sent++;
  
  // Try Native Messaging first if available
  if (communicationMethod === 'native_messaging' && nativePort && nativeMessagingAvailable) {
    try {
      nativePort.postMessage(message);
      logWithTimestamp('debug', '📤 Sent via Native Messaging', {
        type: message.type,
        id: message.id
      });
      return true;
    } catch (e) {
      logWithTimestamp('warn', '⚠️ Native Messaging send failed, trying WebSocket', {
        error: e.message
      });
      // Fall through to WebSocket
    }
  }
  
  // Fall back to WebSocket
  if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
    try {
      wsConnection.send(JSON.stringify(message));
      logWithTimestamp('debug', '📤 Sent via WebSocket', {
        type: message.type,
        id: message.id
      });
      return true;
    } catch (e) {
      logWithTimestamp('error', '❌ WebSocket send failed', {
        error: e.message
      });
      return false;
    }
  }
  
  logWithTimestamp('error', '❌ No communication channel available', {
    nativeAvailable: nativeMessagingAvailable,
    wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
  });
  return false;
}

/**
 * Get current connection status for popup display
 */
function getConnectionStatus() {
  return {
    method: communicationMethod,
    connected: communicationMethod !== 'disconnected',
    nativeMessagingAvailable,
    webSocketConnected: wsConnection && wsConnection.readyState === WebSocket.OPEN,
    stats: connectionState
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// WEBSOCKET CONNECTION (FALLBACK)
// ═══════════════════════════════════════════════════════════════════════════

// Initialize WebSocket connection to desktop app
async function connectToDesktopApp() {
  const connectionId = Date.now();
  connectionState.lastConnectionAttempt = new Date().toISOString();
  connectionState.handshakeSent = false;
  connectionState.handshakeAcknowledged = false;
  
  logWithTimestamp('info', `🔄 Connection attempt #${reconnectAttempts + 1} initiated`, {
    connectionId,
    currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
  });
  
  // Prevent duplicate connections
  if (wsConnection && (wsConnection.readyState === WebSocket.CONNECTING || wsConnection.readyState === WebSocket.OPEN)) {
    logWithTimestamp('warn', '⚠️ Connection attempt skipped - already connecting or connected', {
      currentState: getWebSocketStateName(wsConnection.readyState),
      connectionId
    });
    return;
  }
  
  // Close existing connection if it exists but is closing/closed
  if (wsConnection && wsConnection.readyState !== WebSocket.CLOSED) {
    logWithTimestamp('info', '🔌 Closing existing connection before new attempt', {
      previousState: getWebSocketStateName(wsConnection.readyState),
      connectionId
    });
    try {
      wsConnection.close();
    } catch (e) {
      logWithTimestamp('warn', '⚠️ Error closing existing connection', { error: e.message, connectionId });
    }
  }
  
  try {
    // Get WebSocket URL from config (supports both localhost and remote backend)
    const wsUrl = await CONFIG.getExtensionWebSocketUrl();
    logWithTimestamp('info', '🌐 Resolved WebSocket URL', { url: wsUrl, connectionId });
    
    logWithTimestamp('info', '🔌 Creating WebSocket connection', { url: wsUrl, connectionId });
    wsConnection = new WebSocket(wsUrl);
    
    wsConnection.onopen = () => {
      const openTime = new Date().toISOString();
      connectionState.lastSuccessfulConnection = openTime;
      reconnectAttempts = 0;
      
      logWithTimestamp('info', '✅ WebSocket connection OPENED - handshake successful', {
        connectionId,
        openTime,
        readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
        url: wsUrl,
        reconnectAttempts: 0
      });
      
      // Wait a moment to ensure WebSocket is fully ready before sending
      setTimeout(() => {
        if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
          const handshakeMessage = { 
            type: 'extension_ready',
            version: '2.0.0',
            extensionId: chrome.runtime.id,  // Send extension ID for Native Messaging host registration
            capabilities: [
              'native_messaging',
              'vision_streaming',
              'full_page_screenshots',
              'element_screenshots',
              'vision_based_detection',
              'coordinate_clicking',
              'process_monitoring',
              'window_management'
            ]
          };
          
          logWithTimestamp('info', '📤 Sending extension_ready handshake message', {
            connectionId,
            messageType: handshakeMessage.type,
            version: handshakeMessage.version,
            capabilities: handshakeMessage.capabilities,
            capabilityCount: handshakeMessage.capabilities.length
          });
          
          const sent = sendToDesktopApp(handshakeMessage);
          if (sent) {
            connectionState.handshakeSent = true;
            logWithTimestamp('info', '✅ Handshake message sent successfully', {
              connectionId,
              timestamp: new Date().toISOString()
            });
          } else {
            logWithTimestamp('error', '❌ Failed to send handshake message', {
              connectionId,
              readyState: getWebSocketStateName(wsConnection?.readyState)
            });
          }
        } else {
          logWithTimestamp('warn', '⚠️ WebSocket not ready after onopen callback', {
            connectionId,
            readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
            delay: '100ms'
          });
        }
      }, 100);
      
      // Notify popup that connection is established (if popup is open)
      try {
        chrome.runtime.sendMessage({
          type: 'extension_ready',
          version: '2.0.0',
          capabilities: [
            'vision_streaming',
            'full_page_screenshots',
            'element_screenshots',
            'vision_based_detection',
            'coordinate_clicking',
            'process_monitoring',
            'window_management'
          ]
        }, () => {
          // Ignore errors if popup is not open
          if (chrome.runtime.lastError) {
            logWithTimestamp('debug', 'Popup not available (this is normal)', {
              error: chrome.runtime.lastError.message
            });
          } else {
            logWithTimestamp('debug', '✅ Popup notified of connection', { connectionId });
          }
        });
      } catch (e) {
        logWithTimestamp('debug', 'Popup notification failed (non-critical)', {
          error: e.message,
          connectionId
        });
      }
    };
    
    wsConnection.onmessage = async (event) => {
      const receiveTime = new Date().toISOString();
      connectionState.messageCount.received++;
      
      try {
        const messageSize = event.data ? event.data.length : 0;
        logWithTimestamp('debug', '📥 Message received from backend', {
          connectionId,
          receiveTime,
          messageSize,
          messageSizeKB: (messageSize / 1024).toFixed(2)
        });
        
        const message = JSON.parse(event.data);
        const messageType = message.type || 'unknown';
        
        logWithTimestamp('info', '📥 Processing message from backend', {
          connectionId,
          messageType,
          messageId: message.id || 'none',
          hasData: !!message.data,
          receiveTime
        });
        
        // Check for handshake acknowledgment (backend sends 'handshake_ack' type)
        if (messageType === 'handshake_ack' && connectionState.handshakeSent && !connectionState.handshakeAcknowledged) {
          logWithTimestamp('info', '✅ Handshake acknowledged by backend - two-way communication verified', {
            connectionId,
            messageId: message.id || 'handshake_ack',
            success: message.success,
            timestamp: receiveTime
          });
          connectionState.handshakeAcknowledged = true;
          
          // CRITICAL: After successful reconnection, retry any queued responses
          // This ensures responses that were queued during disconnection are sent
          setTimeout(() => {
            retryQueuedResponses();
          }, 500); // Small delay to ensure connection is fully stable
          
          // Don't process handshake_ack as a regular command - it's just an acknowledgment
          return;
        }
        
        await handleDesktopAppMessage(message);
        
        logWithTimestamp('debug', '✅ Message processed successfully', {
          connectionId,
          messageType,
          messageId: message.id || 'none'
        });
      } catch (error) {
        logWithTimestamp('error', '❌ Error handling message from backend', {
          connectionId,
          error: error.message,
          errorStack: error.stack,
          receiveTime,
          rawDataLength: event.data ? event.data.length : 0
        });
      }
    };
    
    wsConnection.onerror = (error) => {
      // Extract error message properly (error might be an Event object)
      let errorMessage = 'Unknown error';
      let errorDetails = null;
      
      if (error instanceof Error) {
        errorMessage = error.message || error.toString();
        errorDetails = error.stack;
      } else if (error && typeof error === 'object') {
        errorMessage = error.message || error.type || JSON.stringify(error);
        errorDetails = error.stack || error.toString();
      } else if (error) {
        errorMessage = String(error);
      }
      
      logWithTimestamp('error', '❌ WebSocket ERROR occurred', {
        connectionId,
        error: errorMessage,
        errorDetails: errorDetails,
        readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
        timestamp: new Date().toISOString()
      });
    };
    
    wsConnection.onclose = (event) => {
      const closeTime = new Date().toISOString();
      connectionState.lastDisconnection = closeTime;
      const wasConnected = wsConnection && wsConnection.readyState === WebSocket.OPEN;
      
      // MVP: Detect Chrome crash scenarios
      const isChromeCrash = event.code === 1006 && !event.wasClean; // Abnormal closure without clean close
      const isBackendCrash = event.code === 1001; // Going away (backend process terminated)
      
      logWithTimestamp('info', '🔌 WebSocket connection CLOSED', {
        connectionId,
        closeCode: event.code,
        closeReason: event.reason || 'none',
        wasClean: event.wasClean,
        wasConnected,
        closeTime,
        possibleChromeCrash: isChromeCrash,
        possibleBackendCrash: isBackendCrash,
        handshakeSent: connectionState.handshakeSent,
        handshakeAcknowledged: connectionState.handshakeAcknowledged,
        messagesSent: connectionState.messageCount.sent,
        messagesReceived: connectionState.messageCount.received
      });
      
      wsConnection = null;
      
      // Stop all vision streams on disconnect
      if (visionStreamingActive) {
        logWithTimestamp('info', '🛑 Stopping all vision streams due to disconnect', {
          connectionId,
          activeStreams: visionStreamCallbacks.size
        });
        visionStreamCallbacks.forEach((_, tabId) => {
          stopVisionStream(tabId);
        });
      }
      
      // MVP: Always reconnect for crashes or unexpected disconnections
      // Only skip reconnection for intentional closures (code 1000 with wasClean=true)
      const shouldReconnect = event.code !== 1000 || wasConnected || isChromeCrash || isBackendCrash;
      
      if (shouldReconnect) {
        // For crashes, reset reconnect attempts to allow recovery
        if (isChromeCrash || isBackendCrash) {
          reconnectAttempts = 0;
          logWithTimestamp('info', '🔄 Crash detected - resetting reconnect attempts', {
            connectionId,
            crashType: isChromeCrash ? 'chrome' : 'backend'
          });
        }
        
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts++;
          const delay = Math.min(2000 * reconnectAttempts, 10000); // Max 10 seconds
          logWithTimestamp('info', `🔄 Scheduling reconnection attempt`, {
            connectionId,
            attempt: reconnectAttempts,
            maxAttempts: MAX_RECONNECT_ATTEMPTS,
            delayMs: delay,
            nextAttemptTime: new Date(Date.now() + delay).toISOString(),
            reason: isChromeCrash ? 'chrome_crash' : isBackendCrash ? 'backend_crash' : 'disconnect'
          });
          setTimeout(connectToDesktopApp, delay);
        } else {
          logWithTimestamp('error', '❌ Max reconnection attempts reached - giving up', {
            connectionId,
            maxAttempts: MAX_RECONNECT_ATTEMPTS,
            lastDisconnection: closeTime
          });
          // MVP: Still try again after longer delay (5 minutes) for recovery
          setTimeout(() => {
            reconnectAttempts = 0; // Reset for recovery attempt
            logWithTimestamp('info', '🔄 Recovery reconnection attempt after max attempts', {
              connectionId
            });
            connectToDesktopApp();
          }, 5 * 60 * 1000); // 5 minutes
        }
      } else {
        logWithTimestamp('info', '✅ Normal closure - not reconnecting', {
          connectionId,
          closeCode: event.code
        });
      }
    };
  } catch (error) {
    logWithTimestamp('error', '❌ Failed to create WebSocket connection', {
      connectionId,
      error: error.message,
      errorStack: error.stack,
      timestamp: new Date().toISOString()
    });
  }
}

// Helper function to get WebSocket state name
function getWebSocketStateName(state) {
  if (state === null || state === undefined) {
    return 'null';
  }
  const states = {
    [WebSocket.CONNECTING]: 'CONNECTING',
    [WebSocket.OPEN]: 'OPEN',
    [WebSocket.CLOSING]: 'CLOSING',
    [WebSocket.CLOSED]: 'CLOSED'
  };
  return states[state] || `UNKNOWN(${state})`;
}

// Helper function to safely get WebSocket ready state
function getWebSocketReadyState() {
  if (!wsConnection) {
    return 'null';
  }
  try {
    return getWebSocketStateName(wsConnection.readyState);
  } catch (e) {
    return 'null';
  }
}

// Send message to desktop app
// Response queue for messages that couldn't be sent due to disconnection
// CRITICAL: Queue responses when WebSocket disconnects during command execution
const pendingResponseQueue = [];

function sendToDesktopApp(message) {
  const sendTime = new Date().toISOString();
  const messageType = message.type || 'unknown';
  const messageId = message.id || 'none';
  const messageStr = JSON.stringify(message);
  const messageSize = messageStr.length;
  
  logWithTimestamp('debug', '📤 Sending message to backend', {
    messageType,
    messageId,
    messageSize,
    messageSizeKB: (messageSize / 1024).toFixed(2),
    sendTime,
    communicationMethod,
    nativeAvailable: nativeMessagingAvailable,
    wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
  });
  
  // ═══════════════════════════════════════════════════════════════════════
  // PRIORITY 1: Try Native Messaging (fastest, ~1-2ms overhead)
  // ═══════════════════════════════════════════════════════════════════════
  if (communicationMethod === 'native_messaging' && nativePort && nativeMessagingAvailable) {
    try {
      nativePort.postMessage(message);
      connectionState.messageCount.sent++;
      
      logWithTimestamp('debug', '✅ Message sent via Native Messaging', {
        messageType,
        messageId,
        messageSize,
        sendTime,
        totalSent: connectionState.messageCount.sent
      });
      
      return true;
    } catch (error) {
      logWithTimestamp('warn', '⚠️ Native Messaging send failed, trying WebSocket', {
        messageType,
        messageId,
        error: error.message
      });
      // Fall through to WebSocket
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // PRIORITY 2: Try WebSocket (fallback, ~5-10ms overhead)
  // ═══════════════════════════════════════════════════════════════════════
  if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
    try {
      wsConnection.send(messageStr);
      connectionState.messageCount.sent++;
      
      logWithTimestamp('debug', '✅ Message sent via WebSocket', {
        messageType,
        messageId,
        messageSize,
        sendTime,
        totalSent: connectionState.messageCount.sent
      });
      
      return true;
    } catch (error) {
      logWithTimestamp('error', '❌ Error sending message via WebSocket', {
        messageType,
        messageId,
        error: error.message,
        errorStack: error.stack,
        sendTime,
        readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
      });
      
      // Queue message for retry if it's a response (not handshake)
      if (messageType === 'response' && messageId !== 'handshake_ack') {
        queueResponseForRetry(message);
      }
      return false;
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════
  // NO CONNECTION AVAILABLE - Queue for retry
  // ═══════════════════════════════════════════════════════════════════════
  if (messageType === 'response' && messageId !== 'handshake_ack') {
    logWithTimestamp('info', '📦 Queueing response for retry after reconnection', {
      messageType,
      messageId,
      communicationMethod,
      nativeAvailable: nativeMessagingAvailable,
      wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
      sendTime,
      queueSize: pendingResponseQueue.length + 1
    });
    queueResponseForRetry(message);
    return false; // Return false but message is queued
  } else {
    logWithTimestamp('warn', '⚠️ Cannot send message - no communication channel available', {
      messageType,
      messageId,
      communicationMethod,
      nativeAvailable: nativeMessagingAvailable,
      wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
      sendTime,
      handshakeSent: connectionState.handshakeSent,
      handshakeAcknowledged: connectionState.handshakeAcknowledged
    });
    return false;
  }
}

function queueResponseForRetry(message) {
  // Add timestamp for tracking
  const queuedMessage = {
    ...message,
    queuedAt: new Date().toISOString(),
    retryCount: 0
  };
  
  // Check if this response is already queued (avoid duplicates)
  const existingIndex = pendingResponseQueue.findIndex(m => m.id === message.id);
  if (existingIndex >= 0) {
    logWithTimestamp('debug', '🔄 Updating existing queued response', {
      messageId: message.id,
      messageType: message.type
    });
    pendingResponseQueue[existingIndex] = queuedMessage;
  } else {
    pendingResponseQueue.push(queuedMessage);
    logWithTimestamp('info', '📦 Response queued for retry', {
      messageId: message.id,
      messageType: message.type,
      queueSize: pendingResponseQueue.length
    });
  }
}

function retryQueuedResponses() {
  if (pendingResponseQueue.length === 0) {
    return;
  }
  
  if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
    logWithTimestamp('debug', '⏳ Cannot retry queued responses - WebSocket not connected', {
      queueSize: pendingResponseQueue.length,
      readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
    });
    return;
  }
  
  logWithTimestamp('info', '🔄 Retrying queued responses after reconnection', {
    queueSize: pendingResponseQueue.length
  });
  
  // Retry all queued responses
  const responsesToRetry = [...pendingResponseQueue];
  pendingResponseQueue.length = 0; // Clear queue
  
  let successCount = 0;
  let failCount = 0;
  
  for (const message of responsesToRetry) {
    message.retryCount = (message.retryCount || 0) + 1;
    const sent = sendToDesktopApp(message);
    
    if (sent) {
      successCount++;
      logWithTimestamp('info', '✅ Retried queued response successfully', {
        messageId: message.id,
        messageType: message.type,
        retryCount: message.retryCount,
        queuedAt: message.queuedAt
      });
    } else {
      failCount++;
      // Re-queue if still failed (connection might have dropped again)
      if (message.retryCount < 3) {
        pendingResponseQueue.push(message);
        logWithTimestamp('warn', '⚠️ Retry failed - re-queuing response', {
          messageId: message.id,
          messageType: message.type,
          retryCount: message.retryCount
        });
      } else {
        logWithTimestamp('error', '❌ Max retries reached - dropping response', {
          messageId: message.id,
          messageType: message.type,
          retryCount: message.retryCount
        });
      }
    }
  }
  
  logWithTimestamp('info', '✅ Finished retrying queued responses', {
    total: responsesToRetry.length,
    success: successCount,
    failed: failCount,
    remainingInQueue: pendingResponseQueue.length
  });
}

// Track active commands to prevent service worker suspension
let activeCommands = new Set();
let keepAliveInterval = null;

// CRITICAL: Keep service worker alive during command execution
// Chrome Manifest V3 suspends service workers during long async operations
// This prevents suspension by creating periodic activity
function startCommandKeepAlive() {
  if (keepAliveInterval) return; // Already running
  
  logWithTimestamp('debug', '🔋 Starting command keep-alive to prevent service worker suspension', {
    activeCommands: activeCommands.size
  });
  
  // CRITICAL: Fire keep-alive every 3 seconds during command execution
  // More frequent than normal keep-alive to prevent suspension during long operations
  // Chrome Manifest V3 suspends service workers after ~30 seconds of inactivity
  keepAliveInterval = setInterval(() => {
    if (activeCommands.size > 0) {
      // Create activity to prevent suspension
      // Use chrome.alarms API to wake up service worker
      chrome.alarms.create('command_keep_alive', { delayInMinutes: 0.05 }); // 3 seconds
      
      // Also send WebSocket ping immediately to keep connection alive
      if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
        try {
          wsConnection.send(JSON.stringify({ type: 'ping', timestamp: Date.now() }));
        } catch (e) {
          // Ignore ping errors
        }
      }
      
      logWithTimestamp('debug', '🔋 Command keep-alive ping', {
        activeCommands: activeCommands.size,
        wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
      });
    } else {
      // No active commands - stop keep-alive
      if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
        keepAliveInterval = null;
        logWithTimestamp('debug', '🔋 Stopped command keep-alive - no active commands');
      }
    }
  }, 3000); // Every 3 seconds (more frequent to prevent disconnection)
}

function stopCommandKeepAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
    keepAliveInterval = null;
    logWithTimestamp('debug', '🔋 Stopped command keep-alive');
  }
}

// Handle messages from desktop app
async function handleDesktopAppMessage(message) {
  const { type, id, ...params } = message;
  const processStartTime = Date.now();
  
  logWithTimestamp('debug', '🔄 Processing command from backend', {
    commandType: type,
    commandId: id,
    hasParams: Object.keys(params).length > 0,
    paramKeys: Object.keys(params)
  });
  
  // CRITICAL: Mark command as active to prevent service worker suspension
  activeCommands.add(id);
  startCommandKeepAlive();
  
  try {
    let result;
    
    switch (type) {
      case 'get_active_tab':
        result = await getActiveTab();
        break;
        
      case 'get_all_tabs':
        result = await getAllTabs();
        break;
        
      case 'navigate':
        // SMART NAVIGATION: Check if we're already on the target page
        // If already on the page, don't create a new tab - just return success
        if (params.url) {
          const targetUrl = params.url.toLowerCase().replace(/\/$/, ''); // Normalize URL
          
          // Check current active tab first
          const currentTab = await getActiveTab();
          let alreadyOnPage = false;
          
          if (currentTab && currentTab.url) {
            const currentUrl = currentTab.url.toLowerCase().replace(/\/$/, '');
            // Check if we're already on the target domain/page
            // Handle cases like "gmail.com" matching "https://mail.google.com"
            const targetDomain = targetUrl.replace(/^https?:\/\//, '').split('/')[0];
            const currentDomain = currentUrl.replace(/^https?:\/\//, '').split('/')[0];
            
            // Already on target URL or domain
            if (currentUrl.includes(targetDomain) || currentDomain.includes(targetDomain.replace('www.', ''))) {
              alreadyOnPage = true;
              logWithTimestamp('info', '✅ Already on target page - no navigation needed', {
                targetUrl: params.url,
                currentUrl: currentTab.url
              });
              result = {
                success: true,
                tab: currentTab,
                tabId: currentTab.id,
                alreadyOnPage: true,
                message: `Already on ${params.url} - no navigation needed`
              };
            }
          }
          
          if (!alreadyOnPage) {
            // Need to navigate - create new tab
            logWithTimestamp('info', '🆕 Creating new tab for navigation', {
              url: params.url,
              note: 'Not currently on target page'
            });
            
            const createResult = await createNewTab(params.url);
            if (createResult.success) {
              result = {
                success: true,
                tab: createResult.tab,
                tabId: createResult.tab.id,
                message: `Created new tab and navigated to ${params.url}`
              };
              logWithTimestamp('info', '✅ New tab created successfully', {
                tabId: createResult.tab.id,
                url: params.url
              });
            } else {
              result = { success: false, error: createResult.error || 'Failed to create new tab' };
              logWithTimestamp('error', '❌ Failed to create new tab', {
                error: createResult.error,
                url: params.url
              });
            }
          }
        } else {
          result = { success: false, error: 'URL is required for navigation' };
        }
        break;
      
      case 'navigate_and_wait':
        // NATIVE PAGE LOAD WAITING - No execute_javascript needed!
        // Uses chrome.tabs.onUpdated to detect page load, avoiding CSP issues
        if (params.url) {
          const currentTab = await getActiveTab();
          if (currentTab) {
            result = await navigateAndWaitNative(currentTab.id, params.url, params.timeout || 10000);
            logWithTimestamp('info', '✅ Native navigate+wait complete', result);
          } else {
            // Create new tab and wait
            const newTab = await chrome.tabs.create({ url: params.url });
            const loadResult = await waitForPageLoad(newTab.id, params.timeout || 10000);
            result = {
              success: loadResult.success,
              tabId: newTab.id,
              url: loadResult.url,
              title: loadResult.title,
              status: loadResult.status,
              loadTime: loadResult.loadTime
            };
          }
        } else {
          result = { success: false, error: 'URL is required for navigate_and_wait' };
        }
        break;
      
      case 'wait_for_page_load':
        // Wait for an existing tab to finish loading
        if (params.tabId) {
          result = await waitForPageLoad(params.tabId, params.timeout || 10000);
        } else {
          const currentTab = await getActiveTab();
          if (currentTab) {
            result = await waitForPageLoad(currentTab.id, params.timeout || 10000);
          } else {
            result = { success: false, error: 'No active tab to wait for' };
          }
        }
        break;
        
      case 'click_element':
        result = await clickElement(params.tabId, params.selector);
        break;
        
      case 'type_text':
        result = await typeText(params.tabId, params.selector, params.text);
        break;
        
      case 'execute_javascript':
        result = await executeJavaScript(params.tabId, params.code);
        break;
        
      case 'get_page_content':
        // CRITICAL: getPageContent can take a long time on large pages (Gmail)
        // Ensure keep-alive is active during this operation
        // System automatically tries Readability first, then full HTML with chunking if needed
        logWithTimestamp('info', '📄 Getting page content (may take time on large pages)', {
          tabId: params.tabId,
          commandId: id,
          note: 'Keep-alive active during operation. Will try Readability first, then full HTML if needed.'
        });
        result = await getPageContent(params.tabId);
        break;
        
      case 'get_accessibility_tree':
        result = await getAccessibilityTree(params.tabId);
        break;
        
      case 'get_interactive_snapshot':
        result = await getInteractiveSnapshot(params.tabId);
        break;
        
      case 'get_interactive_elements':
        result = await getInteractiveElements(params.tabId);
        break;
        
      case 'click_node':
        result = await clickNode(params.tabId, params.nodeId);
        break;
      
      case 'click_node_by_hash':
        // ═══════════════════════════════════════════════════════════════════
        // CLICK BY STABLE HASH - More reliable than nodeId
        // 
        // The stableHash is computed from element attributes and survives
        // DOM changes. If nodeId lookup fails, we search for element by hash.
        // ═══════════════════════════════════════════════════════════════════
        result = await clickNodeByHash(params.tabId, params.stableHash, params.nodeId);
        break;
        
      case 'input_text_node':
        result = await inputTextNode(params.tabId, params.nodeId, params.text);
        break;
      
      case 'find_best_input':
        // BrowserOS-style: Find the best input element for a given purpose
        // purpose can be: 'body', 'title', 'subject', 'search', 'to', 'message'
        result = await findBestInput(params.tabId, params.purpose);
        break;
        
      case 'type_into_focused':
        // BrowserOS-style: Type into the currently focused element
        // Useful for complex editors like Google Docs
        result = await typeIntoFocused(params.tabId, params.text);
        break;
        
      case 'simulate_keyboard':
        // BrowserOS-style: Explicit keyboard simulation for complex editors
        // Simulates real keyboard events character by character
        result = await simulateKeyboard(params.tabId, params.text, params.options);
        break;
        
      case 'press_key':
        // Press a single key (Enter, Tab, Escape, etc.)
        result = await pressKey(params.tabId, params.key, params.modifiers);
        break;
      
      case 'paste_text':
        // CANVAS EDITOR SUPPORT: Copy to clipboard and paste with Cmd+V/Ctrl+V
        // Works with Google Docs, Notion, Figma, and other canvas-based editors
        result = await pasteText(params.tabId, params.text);
        break;
      
      case 'global_type':
        // CANVAS EDITOR SUPPORT: Type by dispatching keyboard events to document
        // For complex editors where type_text fails to find the right element
        result = await globalType(params.tabId, params.text);
        break;
        
      case 'show_highlights':
        // BrowserOS-style: Show bounding boxes around interactive elements
        result = await showInteractiveHighlights(params.tabId, params.showLabels);
        break;
        
      case 'clear_visuals':
        // Clear all visual feedback
        result = await clearAllVisuals(params.tabId);
        break;
      
      // ═══════════════════════════════════════════════════════════════════
      // SMART WAIT COMMANDS - Replace static delays with condition-based waits
      // These provide massive latency improvements for batched tool calls!
      // ═══════════════════════════════════════════════════════════════════
      
      case 'wait_for_dom_stable':
        // Wait for DOM to stop changing (e.g., after click, page is updating)
        // Much smarter than static 150ms delay!
        result = await waitForDomStable(
          params.tabId,
          params.stableMs || 100,   // DOM must be stable for this long
          params.timeoutMs || 3000  // Max wait time
        );
        break;
      
      case 'wait_for_condition':
        // Wait for specific condition (element appears, URL changes, etc.)
        result = await waitForCondition(
          params.tabId,
          params.condition,  // 'element_exists' | 'element_visible' | 'url_contains' | 'url_changed'
          params.selector,   // CSS selector or value to match
          params.timeoutMs || 3000
        );
        break;
        
      case 'take_screenshot':
        result = await takeScreenshot(params.tabId);
        break;
        
      case 'take_full_page_screenshot':
        result = await takeFullPageScreenshot(params.tabId);
        break;
        
      case 'take_element_screenshot':
        result = await takeElementScreenshot(params.tabId, params.selector);
        break;
        
      case 'start_vision_stream':
        result = await startVisionStream(params.tabId, params.interval);
        break;
        
      case 'stop_vision_stream':
        result = await stopVisionStream(params.tabId);
        break;
        
      case 'find_element_by_vision':
        result = await findElementByVision(params.tabId, params.description);
        break;
        
      // ═══════════════════════════════════════════════════════════════════════════
      // LLM-FREE ELEMENT OPERATIONS - For instant pattern execution!
      // ═══════════════════════════════════════════════════════════════════════════
      case 'find_element_by_text':
        // Search current snapshot by text pattern - NO LLM NEEDED!
        result = await findElementByText(params.tabId, params.textPattern, params.options || {});
        break;
        
      case 'click_element_by_text':
        // Find + click in one operation - enables instant cached pattern execution!
        result = await clickElementByText(params.tabId, params.textPattern, params.options || {});
        break;
        
      case 'input_text_by_pattern':
        // Find input + type in one operation - enables instant cached pattern execution!
        result = await inputTextByPattern(params.tabId, params.textPattern, params.text, params.options || {});
        break;
        
      // ═══════════════════════════════════════════════════════════════════════════
      // SMART CLICK/TYPE - Zero-token-bloat element operations!
      // Takes fresh snapshot, filters by description, auto-clicks if unambiguous
      // Reduces 40 elements (3000 tokens) → 0-5 elements (0-375 tokens)
      // ═══════════════════════════════════════════════════════════════════════════
      case 'smart_click':
        // Intent-based click: "click search button" → auto-finds and clicks
        result = await smartClick(params.tabId, params.description, params.options || {});
        break;
        
      case 'smart_type':
        // Intent-based type: "type into search field" → auto-finds and types
        result = await smartType(params.tabId, params.description, params.text, params.options || {});
        break;
        
      case 'get_node_info':
        // Get element info by nodeId - used for enriching cached patterns with descriptors
        result = await getNodeInfo(params.tabId, params.nodeId);
        break;
        
      case 'click_by_coordinates':
        result = await clickByCoordinates(params.tabId, params.x, params.y);
        break;
        
      case 'get_browser_process_info':
        result = await getBrowserProcessInfo(params.tabId);
        break;
        
      case 'get_tab_context':
        result = await getTabContext(params.tabId);
        break;
        
      case 'get_all_profiles':
        result = await getAllProfiles();
        break;
        
      case 'get_all_windows':
        result = await getAllWindows();
        break;
        
      case 'create_new_tab':
        result = await createNewTab(params.url, params.windowId);
        break;
        
      case 'close_tab':
        result = await closeTab(params.tabId);
        break;
        
      case 'monitor_tab_changes':
        result = await monitorTabChanges(params.tabId);
        break;
        
      case 'batch':
        // Handle batch commands (BrowserOS-style optimization)
        // Process multiple commands in parallel for better performance
        result = await handleBatchCommands(params.commands);
        // Send batch response
        sendToDesktopApp({
          type: 'batch_response',
          id: id,
          success: true,
          data: result
        });
        return;  // Don't send regular response for batch
      
      case 'handshake_ack':
        // Backend acknowledged our extension_ready message
        // This confirms two-way communication is working
        logWithTimestamp('info', '✅ Handshake acknowledged by backend - two-way communication verified', {
          connectionId: id,
          messageId: id,
          timestamp: new Date().toISOString()
        });
        // Don't send a response for handshake_ack - it's just an acknowledgment
        return;
      
      // ═══════════════════════════════════════════════════════════════════════
      // READING MODE - Text Extraction for TTS
      // ═══════════════════════════════════════════════════════════════════════
      
      case 'extract_readable_content':
      case 'get_readable_content':
        // Get readable content from the active tab for Reading Mode
        result = await extractReadableContentFromTab(params.tabId);
        break;
        
      case 'get_selected_text':
        // Get currently selected text from the active tab
        result = await getSelectedTextFromTab(params.tabId);
        break;
        
      case 'show_reading_indicator':
        // Show reading mode indicator on the page
        result = await showReadingIndicatorOnTab(params.tabId, params.title, params.progress);
        break;
        
      case 'hide_reading_indicator':
        // Hide reading mode indicator
        result = await hideReadingIndicatorOnTab(params.tabId);
        break;
        
      case 'update_reading_progress':
        // Update reading progress indicator
        result = await updateReadingProgressOnTab(params.tabId, params.progress);
        break;
      
      // ═══════════════════════════════════════════════════════════════════════════
      // CONTEXT & MEMORY COMMANDS
      // ═══════════════════════════════════════════════════════════════════════════
      
      case 'get_tab_context':
        // Get unified context from all tabs
        if (typeof tabContextManager !== 'undefined') {
          result = await tabContextManager.getUnifiedContext();
        } else {
          result = { error: 'TabContextManager not initialized' };
        }
        break;
      
      case 'get_active_tab_context':
        // Get context for active tab only
        if (typeof tabContextManager !== 'undefined') {
          result = await tabContextManager.getActiveTabContext();
        } else {
          result = { error: 'TabContextManager not initialized' };
        }
        break;
      
      case 'store_memory':
        // Store a memory entry
        if (typeof crossTabSync !== 'undefined') {
          const memoryId = await crossTabSync.storeMemory(params.entry);
          result = { success: true, memoryId };
        } else {
          result = { error: 'CrossTabSync not initialized' };
        }
        break;
      
      case 'get_memories':
        // Get recent memories
        if (typeof crossTabSync !== 'undefined') {
          const memories = await crossTabSync.getRecentMemories(
            params.limit || 10,
            params.type || null
          );
          result = { success: true, memories };
        } else {
          result = { error: 'CrossTabSync not initialized' };
        }
        break;
      
      case 'get_memory_context':
        // Get context optimized for LLM
        if (typeof crossTabSync !== 'undefined') {
          result = await crossTabSync.getContextForLLM();
        } else {
          result = { error: 'CrossTabSync not initialized' };
        }
        break;
      
      case 'store_task_execution':
        // Store a task execution result
        if (typeof crossTabSync !== 'undefined') {
          const memoryId = await crossTabSync.storeTaskExecution(
            params.instruction,
            params.success,
            params.toolCalls || [],
            params.durationMs || 0
          );
          result = { success: true, memoryId };
        } else {
          result = { error: 'CrossTabSync not initialized' };
        }
        break;
        
      default:
        result = { error: `Unknown command: ${type}` };
    }
    
    const processDuration = Date.now() - processStartTime;
    
    // NULL SAFETY: Handle null/undefined results from command handlers
    if (result === null || result === undefined) {
      result = { success: false, error: 'Command returned null result' };
    }
    
    logWithTimestamp('info', '✅ Command processed successfully', {
      commandType: type,
      commandId: id,
      durationMs: processDuration,
      hasError: !!(result && result.error),
      success: !(result && result.error)
    });
    
    // BrowserOS-style: Handle chunked responses for large page content
    // If result is chunked, send chunks sequentially to prevent WebSocket disconnection
    // Full context is preserved by sending all chunks and reassembling on backend
    if (result && result.chunked && result.htmlChunks && result.htmlChunks.length > 1) {
      logWithTimestamp('info', '📦 Sending chunked page content (preserving full context)', {
        commandType: type,
        commandId: id,
        totalChunks: result.totalChunks,
        htmlSize: result.htmlSize,
        htmlSizeMB: (result.htmlSize / (1024 * 1024)).toFixed(2)
      });
      
      // Send first chunk with metadata
      const firstChunk = {
        type: 'response',
        id: id,
        success: true,
        chunked: true,
        chunkIndex: 0,
        totalChunks: result.totalChunks,
        htmlSize: result.htmlSize,
        textSize: result.textSize,
        url: result.url,
        title: result.title,
        htmlChunk: result.htmlChunks[0],
        textChunks: result.textChunks, // Text chunks sent with first message (usually smaller)
        isFirstChunk: true
      };
      
      let chunkSent = sendToDesktopApp(firstChunk);
      if (!chunkSent) {
        queueResponseForRetry(firstChunk);
        logWithTimestamp('warn', '⚠️ First chunk queued for retry', {
          commandId: id,
          chunkIndex: 0
        });
      }
      
      // Send remaining HTML chunks sequentially with adaptive delays
      // BrowserOS-style: Delay increases with chunk size to prevent WebSocket buffer overflow
      // CRITICAL: Large delays prevent connection drops during large transfers
      for (let i = 1; i < result.htmlChunks.length; i++) {
        const chunkSize = result.htmlChunks[i]?.length || 0;
        // Adaptive delay: 100ms base + 2ms per 10KB of chunk size
        // For large chunks (135KB), this gives ~370ms delay, preventing buffer overflow
        // Increased from 50ms base to ensure WebSocket has time to process each chunk
        const adaptiveDelay = 100 + Math.floor(chunkSize / 5120);
        
        // Check connection before sending each chunk
        if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
          logWithTimestamp('warn', '⚠️ WebSocket disconnected during chunk sending, queuing remaining chunks', {
            commandId: id,
            chunkIndex: i,
            totalChunks: result.totalChunks,
            wsState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null'
          });
          // Queue remaining chunks for retry after reconnection
          for (let j = i; j < result.htmlChunks.length; j++) {
            const remainingChunk = {
              type: 'response_chunk',
              id: id,
              chunkIndex: j,
              totalChunks: result.totalChunks,
              htmlChunk: result.htmlChunks[j],
              isLastChunk: j === result.htmlChunks.length - 1
            };
            queueResponseForRetry(remainingChunk);
          }
          break; // Stop sending, chunks will be retried after reconnection
        }
        
        await new Promise(resolve => setTimeout(resolve, adaptiveDelay));
        
        const chunk = {
          type: 'response_chunk',
          id: id,
          chunkIndex: i,
          totalChunks: result.totalChunks,
          htmlChunk: result.htmlChunks[i],
          isLastChunk: i === result.htmlChunks.length - 1
        };
        
        chunkSent = sendToDesktopApp(chunk);
        if (!chunkSent) {
          queueResponseForRetry(chunk);
          logWithTimestamp('warn', '⚠️ Chunk queued for retry', {
            commandId: id,
            chunkIndex: i,
            isLastChunk: chunk.isLastChunk
          });
        }
      }
      
      logWithTimestamp('info', '✅ All chunks sent successfully (full context preserved)', {
        commandType: type,
        commandId: id,
        totalChunks: result.totalChunks,
        htmlSizeMB: (result.htmlSize / (1024 * 1024)).toFixed(2)
      });
    } else {
      // Normal (non-chunked) response - send as single message
      const responseSent = sendToDesktopApp({
        type: 'response',
        id: id,
        success: !(result && result.error),
        data: result || { error: 'No result from command' }
      });
      
      if (!responseSent) {
        // Response was queued for retry - this is OK, it will be sent after reconnection
        logWithTimestamp('info', '📦 Response queued for retry (WebSocket disconnected during command execution)', {
          commandType: type,
          commandId: id,
          queueSize: pendingResponseQueue.length,
          note: 'Response will be sent automatically after reconnection'
        });
      }
    }
    
  } catch (error) {
    const processDuration = Date.now() - processStartTime;
    
    // Extract error message properly (handle both Error objects and other types)
    let errorMessage = 'Unknown error';
    let errorStack = null;
    
    if (error instanceof Error) {
      errorMessage = error.message || error.toString();
      errorStack = error.stack || '';
    } else if (error && typeof error === 'object') {
      errorMessage = error.message || error.toString() || JSON.stringify(error);
      errorStack = error.stack || '';
    } else {
      errorMessage = String(error);
      errorStack = '';
    }
    
    logWithTimestamp('error', '❌ Error processing command', {
      commandType: type,
      commandId: id,
      error: errorMessage,
      errorStack: errorStack,
      durationMs: processDuration
    });
    
    const errorResponseSent = sendToDesktopApp({
      type: 'response',
      id: id,
      success: false,
      error: errorMessage,
    });
    
    if (!errorResponseSent) {
      // Error response was queued for retry - this is OK, it will be sent after reconnection
      logWithTimestamp('info', '📦 Error response queued for retry (WebSocket disconnected during command execution)', {
        commandType: type,
        commandId: id,
        error: errorMessage,
        queueSize: pendingResponseQueue.length,
        note: 'Error response will be sent automatically after reconnection'
      });
    }
  } finally {
    // CRITICAL: Remove command from active set when done (success or error)
    activeCommands.delete(id);
    
    // If no more active commands, stop keep-alive
    if (activeCommands.size === 0) {
      stopCommandKeepAlive();
    }
    
    logWithTimestamp('debug', '✅ Command processing complete', {
      commandType: type,
      commandId: id,
      remainingActiveCommands: activeCommands.size
    });
  }
}

// Batch command handler (BrowserOS-style optimization)
async function handleBatchCommands(commands) {
  // Process commands in parallel (like BrowserOS batch processing)
  const results = await Promise.all(
    commands.map(async (cmd) => {
      try {
        const { type, ...params } = cmd;
        let result;
        
        // Route to appropriate handler
        switch (type) {
          case 'get_active_tab':
            result = await getActiveTab();
            break;
          case 'take_screenshot':
            // Handle 'active' tabId reference
            if (params.tabId === 'active') {
              const activeTab = await getActiveTab();
              if (activeTab.error || !activeTab.id) {
                result = { error: activeTab.error || 'No active tab found' };
                break;
              }
              params.tabId = activeTab.id;
            }
            result = await takeScreenshot(params.tabId);
            break;
          case 'click_element':
            result = await clickElement(params.tabId, params.selector);
            break;
          case 'type_text':
            result = await typeText(params.tabId, params.selector, params.text);
            break;
          case 'navigate':
            result = await navigateTab(params.tabId, params.url);
            break;
          case 'get_all_tabs':
            result = await getAllTabs();
            break;
          case 'get_page_content':
            result = await getPageContent(params.tabId);
            break;
          case 'get_accessibility_tree':
            result = await getAccessibilityTree(params.tabId);
            break;
          case 'get_interactive_snapshot':
            result = await getInteractiveSnapshot(params.tabId);
            break;
          case 'get_interactive_elements':
            result = await getInteractiveElements(params.tabId);
            break;
          case 'execute_javascript':
            result = await executeJavaScript(params.tabId, params.code);
            break;
          default:
            result = { error: `Unknown batch command: ${type}` };
        }
        
        return {
          success: !result.error,
          data: result
        };
      } catch (error) {
        return {
          success: false,
          error: error.message
        };
      }
    })
  );
  
  return { results };
}

// Browser Control APIs

async function getActiveTab() {
  // Try to get active tab in current window first
  let tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  
  // Filter out DevTools pages and other special pages that can't be controlled
  if (tabs && tabs.length > 0) {
    tabs = tabs.filter(tab => {
      const url = tab.url || '';
      // Exclude DevTools pages, extension pages, and other special chrome:// pages
      return !url.startsWith('chrome-devtools://') && 
             !url.startsWith('chrome://') &&
             !url.startsWith('chrome-extension://') &&
             url !== 'about:blank' &&
             url.length > 0;
    });
  }
  
  // If no usable tab found in current window, try all windows
  if (!tabs || tabs.length === 0) {
    tabs = await chrome.tabs.query({ active: true });
    if (tabs && tabs.length > 0) {
      tabs = tabs.filter(tab => {
        const url = tab.url || '';
        return !url.startsWith('chrome-devtools://') && 
               !url.startsWith('chrome://') &&
               !url.startsWith('chrome-extension://') &&
               url !== 'about:blank' &&
               url.length > 0;
      });
    }
  }
  
  // If still no usable tab, try getting any regular HTTP/HTTPS tab
  if (!tabs || tabs.length === 0) {
    const allTabs = await chrome.tabs.query({});
    tabs = allTabs.filter(tab => {
      const url = tab.url || '';
      return (url.startsWith('http://') || url.startsWith('https://')) &&
             !url.startsWith('chrome-devtools://') &&
             !url.startsWith('chrome://') &&
             !url.startsWith('chrome-extension://');
    });
    // Sort by active status, then by index (prefer active tabs)
    tabs.sort((a, b) => {
      if (a.active !== b.active) return b.active ? 1 : -1;
      return a.index - b.index;
    });
  }
  
  if (!tabs || tabs.length === 0) {
    return { 
      error: 'No usable tab found (DevTools pages cannot be controlled)',
      success: false
    };
  }
  
  const tab = tabs[0];
  
  // Get profile information (non-blocking, with timeout)
  // Don't wait for profile info - return tab info immediately
  let profileInfo = {};
  try {
    // Try to get profile info but don't block on it
    const profilePromise = getProfileInfo(tab.id);
    const timeoutPromise = new Promise((resolve) => setTimeout(() => resolve({}), 1000));
    profileInfo = await Promise.race([profilePromise, timeoutPromise]);
  } catch (e) {
    // Ignore profile errors - not critical for get_active_tab
    profileInfo = {};
  }
  
  return {
    id: tab.id,
    url: tab.url,
    title: tab.title,
    windowId: tab.windowId,
    index: tab.index,
    pinned: tab.pinned,
    active: tab.active,
    status: tab.status,
    profile: profileInfo
  };
}

async function getProfileInfo(tabId) {
  try {
    // Get cookies for the tab's domain
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url) {
      return { error: 'Tab URL not available' };
    }
    
    const url = new URL(tab.url);
    const domain = url.hostname;
    
    // Get cookies (if accessible)
    let cookies = [];
    try {
      cookies = await chrome.cookies.getAll({ domain: domain });
      // Filter sensitive data, just return count and names
      cookies = cookies.map(c => ({
        name: c.name,
        domain: c.domain,
        secure: c.secure,
        httpOnly: c.httpOnly,
        session: c.session
      }));
    } catch (e) {
      // Cookies API might not be available
    }
    
    // Get storage info
    const storageInfo = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        return {
          localStorageKeys: Object.keys(localStorage || {}).length,
          sessionStorageKeys: Object.keys(sessionStorage || {}).length,
          hasCookies: document.cookie.length > 0
        };
      }
    }).catch(() => ({ result: null }));
    
    return {
      domain: domain,
      cookiesCount: cookies.length,
      cookies: cookies.slice(0, 10), // Limit to first 10
      storage: storageInfo[0]?.result || null,
      isAuthenticated: cookies.length > 0 || (storageInfo[0]?.result?.hasCookies || false)
    };
  } catch (error) {
    return { error: error.message };
  }
}

async function getAllTabs() {
  const tabs = await chrome.tabs.query({});
  
  // Get profile info for all tabs (in parallel, but limited)
  const tabsWithProfile = await Promise.all(
    tabs.slice(0, 20).map(async (tab) => { // Limit to first 20 tabs for performance
      const profileInfo = await getProfileInfo(tab.id).catch(() => ({}));
      return {
        id: tab.id,
        url: tab.url,
        title: tab.title,
        active: tab.active,
        windowId: tab.windowId,
        index: tab.index,
        pinned: tab.pinned,
        status: tab.status,
        profile: profileInfo
      };
    })
  );
  
  // Add remaining tabs without profile info
  const remainingTabs = tabs.slice(20).map(tab => ({
    id: tab.id,
    url: tab.url,
    title: tab.title,
    active: tab.active,
    windowId: tab.windowId
  }));
  
  return [...tabsWithProfile, ...remainingTabs];
}

// ═══════════════════════════════════════════════════════════════════════════
// BROWSEROSS-STYLE VISUALIZATION SYSTEM
// Injects visual feedback directly into the page's MAIN world
// ═══════════════════════════════════════════════════════════════════════════

// Inject visualization functions into a tab's MAIN world
// NOTE: On strict CSP sites like Gmail, this may fail silently - we use desktop notifications as fallback
async function ensureVisualizationsInjected(tabId) {
  try {
    // Check if already injected - use MAIN world for access to page's JS context
    const checkResults = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',  // CRITICAL: Use MAIN world to inject into page context, not isolated world
      func: () => {
        return !!window.__centrisVisualsInjected;
      }
    }).catch(err => {
      logWithTimestamp('warn', `⚠️ Cannot check visualization status (CSP restriction likely): ${err.message}`);
      return [{ result: false }];
    });
    
    if (checkResults[0]?.result) {
      return true; // Already injected
    }
    
    // Inject the visualization system - use MAIN world
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',  // CRITICAL: Use MAIN world so visualization functions are available to page scripts
      func: () => {
        // Mark as injected
        window.__centrisVisualsInjected = true;
        
        // Inject styles
        if (!document.querySelector('#centris-visual-styles-main')) {
          const style = document.createElement('style');
          style.id = 'centris-visual-styles-main';
          style.textContent = `
            /* BrowserOS-style animated cursor */
            @keyframes centris-ripple {
              0% { transform: translate(-50%, -50%) scale(0.3); opacity: 0.8; }
              100% { transform: translate(-50%, -50%) scale(2.5); opacity: 0; }
            }
            
            @keyframes centris-cursor-move {
              0% { transform: translate(var(--from-x), var(--from-y)); }
              100% { transform: translate(var(--to-x), var(--to-y)); }
            }
            
            @keyframes centris-highlight-glow {
              0% { box-shadow: 0 0 0 3px rgba(252, 102, 26, 0.9), 0 0 30px rgba(252, 102, 26, 0.5); }
              50% { box-shadow: 0 0 0 4px rgba(252, 102, 26, 0.7), 0 0 40px rgba(252, 102, 26, 0.3); }
              100% { box-shadow: 0 0 0 3px rgba(252, 102, 26, 0), 0 0 20px rgba(252, 102, 26, 0); }
            }
            
            @keyframes centris-typing-cursor {
              0%, 100% { opacity: 1; }
              50% { opacity: 0; }
            }
            
            @keyframes centris-toast-in {
              0% { opacity: 0; transform: translateX(-50%) translateY(20px); }
              100% { opacity: 1; transform: translateX(-50%) translateY(0); }
            }
            
            @keyframes centris-toast-out {
              0% { opacity: 1; transform: translateX(-50%) translateY(0); }
              100% { opacity: 0; transform: translateX(-50%) translateY(-10px); }
            }
            
            .centris-cursor-indicator {
              position: fixed;
              pointer-events: none;
              z-index: 2147483647;
              transition: transform 280ms cubic-bezier(0.2, 0.8, 0.2, 1);
            }
            
            .centris-cursor {
              width: 0;
              height: 0;
              border-style: solid;
              border-width: 0 10px 20px 10px;
              border-color: transparent transparent #FC661A transparent;
              filter: drop-shadow(0 2px 6px rgba(0,0,0,0.4)) drop-shadow(0 0 10px rgba(252,102,26,0.6));
              transform-origin: 5px 0;
            }
            
            .centris-ripple {
              position: absolute;
              width: 50px;
              height: 50px;
              border-radius: 50%;
              background: radial-gradient(circle, rgba(252,102,26,0.7) 0%, rgba(252,102,26,0) 70%);
              left: 5px;
              top: 20px;
              animation: centris-ripple 500ms ease-out forwards;
            }
            
            .centris-element-highlight {
              position: fixed;
              pointer-events: none;
              z-index: 2147483646;
              border-radius: 6px;
              background: rgba(252, 102, 26, 0.12);
              animation: centris-highlight-glow 2s ease-out forwards;
            }
            
            .centris-typing-indicator {
              position: fixed;
              pointer-events: none;
              z-index: 2147483647;
              background: linear-gradient(135deg, #FC661A 0%, #e55a17 100%);
              color: white;
              padding: 6px 14px;
              border-radius: 6px;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              font-size: 13px;
              font-weight: 500;
              box-shadow: 0 4px 16px rgba(0,0,0,0.25);
              display: flex;
              align-items: center;
              gap: 8px;
            }
            
            .centris-typing-indicator::after {
              content: '|';
              animation: centris-typing-cursor 0.7s infinite;
              font-weight: 300;
            }
            
            .centris-action-toast {
              position: fixed;
              bottom: 80px;
              left: 50%;
              transform: translateX(-50%);
              background: rgba(0, 0, 0, 0.9);
              color: white;
              padding: 14px 28px;
              border-radius: 10px;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              font-size: 14px;
              font-weight: 500;
              z-index: 2147483647;
              pointer-events: none;
              box-shadow: 0 6px 24px rgba(0,0,0,0.35);
              display: flex;
              align-items: center;
              gap: 12px;
              animation: centris-toast-in 0.35s ease-out forwards;
            }
            
            /* BrowserOS-style node highlighting */
            .centris-node-highlight {
              position: fixed;
              pointer-events: none;
              z-index: 2147483645;
              border: 2px solid #FC661A;
              border-radius: 4px;
              background: rgba(252, 102, 26, 0.08);
            }
            
            .centris-node-label {
              position: absolute;
              top: -22px;
              left: 0;
              background: #FC661A;
              color: white;
              padding: 2px 8px;
              border-radius: 4px 4px 0 0;
              font-size: 11px;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace;
              font-weight: 600;
              white-space: nowrap;
            }
          `;
          document.head.appendChild(style);
        }
        
        // Define visualization functions in MAIN world
        window.centrisShowClick = function(x, y, startX = null, startY = null) {
          document.querySelectorAll('.centris-cursor-indicator').forEach(e => e.remove());
          
          const container = document.createElement('div');
          container.className = 'centris-cursor-indicator';
          
          const fromX = startX !== null ? startX : window.innerWidth / 2;
          const fromY = startY !== null ? startY : window.innerHeight / 2;
          
          container.style.left = '0';
          container.style.top = '0';
          container.style.transform = `translate(${fromX}px, ${fromY}px)`;
          
          const cursor = document.createElement('div');
          cursor.className = 'centris-cursor';
          container.appendChild(cursor);
          
          document.body.appendChild(container);
          
          requestAnimationFrame(() => {
            container.style.transform = `translate(${x}px, ${y}px)`;
          });
          
          setTimeout(() => {
            const ripple = document.createElement('div');
            ripple.className = 'centris-ripple';
            container.appendChild(ripple);
            
            setTimeout(() => {
              container.style.transition = 'opacity 350ms ease-out';
              container.style.opacity = '0';
              setTimeout(() => container.remove(), 400);
            }, 400);
          }, 280);
        };
        
        window.centrisHighlightElement = function(x, y, width, height) {
          document.querySelectorAll('.centris-element-highlight').forEach(e => e.remove());
          
          const highlight = document.createElement('div');
          highlight.className = 'centris-element-highlight';
          highlight.style.left = `${x}px`;
          highlight.style.top = `${y}px`;
          highlight.style.width = `${width}px`;
          highlight.style.height = `${height}px`;
          
          document.body.appendChild(highlight);
          setTimeout(() => highlight.remove(), 2000);
        };
        
        window.centrisShowTyping = function(x, y, text) {
          document.querySelectorAll('.centris-typing-indicator').forEach(e => e.remove());
          
          const indicator = document.createElement('div');
          indicator.className = 'centris-typing-indicator';
          indicator.style.left = `${x + 15}px`;
          indicator.style.top = `${y - 35}px`;
          
          const displayText = text.length > 35 ? text.substring(0, 35) + '...' : text;
          indicator.innerHTML = `<span>✏️</span><span>Typing: "${displayText}"</span>`;
          
          document.body.appendChild(indicator);
          
          const typingDuration = Math.min(text.length * 40, 2500);
          setTimeout(() => {
            indicator.style.transition = 'opacity 350ms';
            indicator.style.opacity = '0';
            setTimeout(() => indicator.remove(), 350);
          }, typingDuration);
        };
        
        window.centrisShowActionToast = function(message, icon = '⚡') {
          document.querySelectorAll('.centris-action-toast').forEach(e => e.remove());
          
          const toast = document.createElement('div');
          toast.className = 'centris-action-toast';
          toast.innerHTML = `<span style="font-size: 18px">${icon}</span><span>${message}</span>`;
          
          document.body.appendChild(toast);
          
          setTimeout(() => {
            toast.style.animation = 'centris-toast-out 0.35s ease-in forwards';
            setTimeout(() => toast.remove(), 350);
          }, 2500);
        };
        
        // BrowserOS-style: Show highlights for all interactive nodes
        window.centrisShowNodeHighlights = function(nodes, showLabels = true, persistent = true) {
          document.querySelectorAll('.centris-node-highlight').forEach(e => e.remove());
          
          const colors = {
            typeable: { border: '#10B981', bg: 'rgba(16, 185, 129, 0.12)' },
            clickable: { border: '#3B82F6', bg: 'rgba(59, 130, 246, 0.12)' },
            selectable: { border: '#8B5CF6', bg: 'rgba(139, 92, 246, 0.12)' },
            other: { border: '#FC661A', bg: 'rgba(252, 102, 26, 0.12)' }
          };
          
          nodes.forEach(node => {
            if (!node.bounds) return;
            
            const color = colors[node.type] || colors.other;
            
            const highlight = document.createElement('div');
            highlight.className = 'centris-node-highlight';
            highlight.style.cssText = `
              position: fixed;
              pointer-events: none;
              z-index: 2147483645;
              border: 2px solid ${color.border};
              border-radius: 4px;
              background: ${color.bg};
              left: ${node.bounds.x}px;
              top: ${node.bounds.y}px;
              width: ${node.bounds.width}px;
              height: ${node.bounds.height}px;
              box-shadow: 0 0 0 1px rgba(0,0,0,0.1), 0 2px 8px rgba(0,0,0,0.1);
              transition: all 0.15s ease;
            `;
            
            if (showLabels) {
              const label = document.createElement('div');
              label.className = 'centris-node-label';
              label.style.cssText = `
                position: absolute;
                top: -24px;
                left: -2px;
                background: ${color.border};
                color: white;
                padding: 3px 8px;
                border-radius: 4px 4px 0 0;
                font-size: 10px;
                font-family: -apple-system, BlinkMacSystemFont, 'SF Mono', Monaco, monospace;
                font-weight: 600;
                white-space: nowrap;
                box-shadow: 0 -2px 8px rgba(0,0,0,0.15);
              `;
              
              // Build descriptive label
              const typeIcon = node.type === 'typeable' ? '✏️' : 
                              node.type === 'clickable' ? '👆' : 
                              node.type === 'selectable' ? '📋' : '◉';
              const shortName = node.name ? (node.name.length > 20 ? node.name.substring(0, 20) + '...' : node.name) : '';
              label.textContent = `${typeIcon} #${node.nodeId} ${shortName}`;
              highlight.appendChild(label);
            }
            
            document.body.appendChild(highlight);
          });
          
          // Only auto-remove if not persistent
          if (!persistent) {
            setTimeout(() => {
              document.querySelectorAll('.centris-node-highlight').forEach(e => e.remove());
            }, 5000);
          }
        };
        
        window.centrisClearVisuals = function() {
          document.querySelectorAll('.centris-cursor-indicator').forEach(e => e.remove());
          document.querySelectorAll('.centris-element-highlight').forEach(e => e.remove());
          document.querySelectorAll('.centris-typing-indicator').forEach(e => e.remove());
          document.querySelectorAll('.centris-action-toast').forEach(e => e.remove());
          document.querySelectorAll('.centris-node-highlight').forEach(e => e.remove());
        };
        
        return true;
      }
    });
    
    logWithTimestamp('info', '🎨 Visualization system injected into tab', { tabId });
    return true;
  } catch (e) {
    // CSP or other restrictions prevented injection
    // This is EXPECTED on Gmail, Google Docs, and other strict sites
    // Fall back to using desktop notifications for feedback
    logWithTimestamp('warn', `⚠️ Visualization injection blocked (CSP or security restriction): ${e.message}`, { 
      tabId, 
      note: 'Will use desktop notifications instead' 
    });
    return false;
  }
}

async function navigateTab(tabId, url) {
  // Ensure visuals are injected first
  await ensureVisualizationsInjected(tabId);
  
  // Show navigation toast to user
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (url) => {
        if (window.centrisShowActionToast) {
          const displayUrl = url.length > 40 ? url.substring(0, 40) + '...' : url;
          window.centrisShowActionToast(`Navigating to ${displayUrl}`, '🌐');
        }
      },
      args: [url]
    });
  } catch (e) {
    // Ignore errors (page might not have content script yet)
  }
  
  await chrome.tabs.update(tabId, { url });
  return { success: true };
}

/**
 * NATIVE PAGE LOAD WAITING - No JavaScript execution needed!
 * Uses chrome.tabs.onUpdated to wait for page load, avoiding CSP issues.
 * This is the BrowserOS-style approach without needing custom Chromium.
 * 
 * @param {number} tabId - Tab ID to wait for
 * @param {number} timeoutMs - Maximum wait time (default 10 seconds)
 * @returns {Promise<{success: boolean, status: string, url: string}>}
 */
async function waitForPageLoad(tabId, timeoutMs = 10000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    let resolved = false;
    
    // Handler for tab updates
    const updateHandler = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId !== tabId || resolved) return;
      
      // Check if page is complete
      if (changeInfo.status === 'complete') {
        resolved = true;
        chrome.tabs.onUpdated.removeListener(updateHandler);
        logWithTimestamp('info', '✅ Page load complete (native detection)', { tabId, url: tab.url });
        resolve({ 
          success: true, 
          status: 'complete', 
          url: tab.url,
          title: tab.title,
          loadTime: Date.now() - startTime
        });
      }
    };
    
    // Add listener
    chrome.tabs.onUpdated.addListener(updateHandler);
    
    // Timeout handler
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        chrome.tabs.onUpdated.removeListener(updateHandler);
        logWithTimestamp('warn', '⏰ Page load timeout - continuing anyway', { tabId, timeoutMs });
        // Still resolve successfully - page might be usable
        chrome.tabs.get(tabId).then(tab => {
          resolve({ 
            success: true, 
            status: tab.status || 'timeout',
            url: tab.url,
            title: tab.title,
            loadTime: Date.now() - startTime,
            timedOut: true
          });
        }).catch(() => {
          resolve({ success: false, status: 'error', error: 'Tab not found after timeout' });
        });
      }
    }, timeoutMs);
    
    // Also check current status immediately (might already be complete)
    chrome.tabs.get(tabId).then(tab => {
      if (!resolved && tab.status === 'complete') {
        resolved = true;
        chrome.tabs.onUpdated.removeListener(updateHandler);
        logWithTimestamp('info', '✅ Page already complete', { tabId, url: tab.url });
        resolve({ 
          success: true, 
          status: 'complete', 
          url: tab.url,
          title: tab.title,
          loadTime: 0,
          alreadyComplete: true
        });
      }
    }).catch(() => {});
  });
}

/**
 * Navigate to URL and wait for page load - ALL NATIVE, NO JS EXECUTION!
 * This replaces the Python backend's execute_javascript polling.
 */
async function navigateAndWaitNative(tabId, url, timeoutMs = 10000) {
  logWithTimestamp('info', '🚀 Native navigate+wait starting', { tabId, url });
  
  // Navigate
  await chrome.tabs.update(tabId, { url });
  
  // Wait for page load using native Chrome APIs
  const loadResult = await waitForPageLoad(tabId, timeoutMs);
  
  return {
    success: loadResult.success,
    tabId: tabId,
    url: loadResult.url,
    title: loadResult.title,
    status: loadResult.status,
    loadTime: loadResult.loadTime,
    timedOut: loadResult.timedOut || false
  };
}

async function clickElement(tabId, selector) {
  // PRIORITY 1: Use CDP overlay (works on ALL sites including Gmail)
  // This shows a visual highlight that CSP cannot block
  try {
    // First get element bounds
    const boundsResult = await chrome.scripting.executeScript({
      target: { tabId },
      func: (selector) => {
        const el = document.querySelector(selector);
        if (el) {
          const rect = el.getBoundingClientRect();
          return { 
            x: rect.left, 
            y: rect.top, 
            width: rect.width, 
            height: rect.height,
            centerX: rect.left + rect.width / 2,
            centerY: rect.top + rect.height / 2
          };
        }
        return null;
      },
      args: [selector]
    });
    
    const bounds = boundsResult[0]?.result;
    if (bounds) {
      // Show CDP highlight (works even on Gmail!)
      await cdpHighlightRect(tabId, bounds.x, bounds.y, bounds.width, bounds.height, 1500);
      await cdpShowClickIndicator(tabId, bounds.centerX, bounds.centerY, 800);
    }
  } catch (e) {
    logWithTimestamp('debug', 'CDP highlight attempt failed, continuing with click', { error: e.message });
  }
  
  // PRIORITY 2: Also try JS-based visualization as additional feedback
  const visualsAvailable = await ensureVisualizationsInjected(tabId);
  
  // Execute the actual click
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',  // CRITICAL: Must be MAIN world to access centris* functions
    func: (selector, visualsAvailable) => {
      const element = document.querySelector(selector);
      if (element) {
        // Scroll into view first
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // BROWSERÓS-STYLE VISUAL FEEDBACK: Show click animation (if available)
        const rect = element.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        
        // Only try visualization if we successfully injected
        if (visualsAvailable) {
          // Highlight the element
          if (window.centrisHighlightElement) {
            window.centrisHighlightElement(rect.left, rect.top, rect.width, rect.height);
          }
          
          // Show animated cursor moving to element
          if (window.centrisShowClick) {
            window.centrisShowClick(x, y);
          }
        }
        
        // Wait for visual feedback, then click
        const waitTime = 400;  // Give time for CDP highlight to show
        return new Promise((resolve) => {
          setTimeout(() => {
            // Use native click with change detection
            const beforeUrl = window.location.href;
            const beforeState = document.readyState;
            
            element.click();
            
            // Wait a bit for changes
            setTimeout(() => {
              const afterUrl = window.location.href;
              const afterState = document.readyState;
              const changed = beforeUrl !== afterUrl || beforeState !== afterState;
              resolve({ 
                success: true, 
                element: element.tagName,
                changeDetected: changed
              });
            }, 100);
          }, waitTime);
        });
      }
      return { success: false, error: 'Element not found' };
    },
    args: [selector, visualsAvailable]
  });
  // NULL SAFETY: Script execution can return null if tab context changed
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed - element may not exist' };
  }
  return await results[0].result || { success: false, error: 'No result from click operation' };
}

async function clickNode(tabId, nodeId) {
  // ══════════════════════════════════════════════════════════════════════════
  // BROWSERSOS-STYLE CASCADING CLICK WITH AUTOMATIC FALLBACKS
  // 
  // KEY INSIGHT: When nodeId goes stale, DON'T ask LLM for new snapshot!
  // Instead, use stored fallback data to find and click the element.
  // This prevents the token-burning loop: click_fail → snapshot → click_fail...
  //
  // FALLBACK CASCADE (try each in order until success):
  // 1. htmlId → document.getElementById (most stable)
  // 2. selector → document.querySelector
  // 3. textContent → find by visible text
  // 4. coordinates → elementFromPoint (last resort)
  // ══════════════════════════════════════════════════════════════════════════
  
  const tabMapping = nodeIdMappings.get(tabId);
  if (!tabMapping) {
    return { success: false, error: 'No snapshot data for this tab. Call getInteractiveSnapshot first.', needsSnapshot: true };
  }
  
  const nodeInfo = tabMapping.get(nodeId);
  if (!nodeInfo) {
    return { success: false, error: `Node ID ${nodeId} not found. The page may have changed - call getInteractiveSnapshot to get fresh node IDs.`, needsSnapshot: true };
  }
  
  // Log the click action for visibility
  const elementName = nodeInfo.name || nodeInfo.ariaLabel || nodeInfo.selector || `Node ${nodeId}`;
  const displayName = elementName.length > 50 ? elementName.substring(0, 50) + '...' : elementName;
  logWithTimestamp('info', `👆 CLICKING: "${displayName}"`, { nodeId, bounds: nodeInfo.bounds });
  
  // ══════════════════════════════════════════════════════════════════════════
  // VISUAL FEEDBACK: Show CDP highlight before attempting click
  // ══════════════════════════════════════════════════════════════════════════
  if (nodeInfo.bounds) {
    const bounds = nodeInfo.bounds;
    const centerX = bounds.x + bounds.width / 2;
    const centerY = bounds.y + bounds.height / 2;
    await cdpHighlightRect(tabId, bounds.x, bounds.y, bounds.width, bounds.height, 1500);
    await cdpShowClickIndicator(tabId, centerX, centerY, 800);
  }
  
  // Ensure JS visualizations are available
  await ensureVisualizationsInjected(tabId);
  
  // ══════════════════════════════════════════════════════════════════════════
  // CASCADING CLICK: Try multiple strategies WITHOUT returning to LLM
  // Each strategy returns {success, method, error?}
  // ══════════════════════════════════════════════════════════════════════════
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (nodeInfo, displayName) => {
      const strategies = [];
      const errors = [];
      
      // ════════════════════════════════════════════════════════════════════
      // BROWSEROSS-STYLE CHANGE DETECTION
      // Captures DOM state before/after click to verify action worked
      // This prevents silent failures where click() runs but nothing happens
      // ════════════════════════════════════════════════════════════════════
      function captureDOMState() {
        return {
          url: window.location.href,
          bodyLength: document.body?.innerHTML?.length || 0,
          // Track specific state changes that indicate success
          activeElement: document.activeElement?.tagName,
          activeElementId: document.activeElement?.id,
          dialogCount: document.querySelectorAll('dialog[open], [role="dialog"], .modal.show, .modal.open').length,
          menuCount: document.querySelectorAll('[role="menu"][aria-expanded="true"], .dropdown-menu.show').length,
          formInputs: Array.from(document.querySelectorAll('input, textarea, select')).map(el => ({
            id: el.id,
            value: el.value?.substring(0, 50),
            checked: el.checked
          })).slice(0, 10), // Limit for performance
          timestamp: Date.now()
        };
      }
      
      function detectChanges(before, after) {
        // URL changed (navigation)
        if (before.url !== after.url) {
          return { changed: true, reason: 'navigation' };
        }
        // DOM content changed significantly (>100 chars difference)
        if (Math.abs(before.bodyLength - after.bodyLength) > 100) {
          return { changed: true, reason: 'dom_content' };
        }
        // Focus changed (input focused)
        if (before.activeElement !== after.activeElement || before.activeElementId !== after.activeElementId) {
          return { changed: true, reason: 'focus_changed' };
        }
        // Dialog/modal opened or closed
        if (before.dialogCount !== after.dialogCount) {
          return { changed: true, reason: 'dialog_change' };
        }
        // Dropdown/menu opened or closed
        if (before.menuCount !== after.menuCount) {
          return { changed: true, reason: 'menu_change' };
        }
        // Form values changed
        const inputsChanged = before.formInputs.some((input, i) => {
          const afterInput = after.formInputs[i];
          return afterInput && (input.value !== afterInput.value || input.checked !== afterInput.checked);
        });
        if (inputsChanged) {
          return { changed: true, reason: 'form_input' };
        }
        return { changed: false, reason: 'no_change_detected' };
      }
      
      // Helper: Perform click with visual feedback AND change detection
      function performClick(element, method) {
        try {
          // CAPTURE STATE BEFORE CLICK
          const beforeState = captureDOMState();
          
          element.scrollIntoView({ behavior: 'instant', block: 'center' });
          
          // Visual feedback
          const rect = element.getBoundingClientRect();
          if (window.centrisHighlightElement) {
            window.centrisHighlightElement(rect.left, rect.top, rect.width, rect.height);
          }
          if (window.centrisShowClick) {
            window.centrisShowClick(rect.left + rect.width/2, rect.top + rect.height/2);
          }
          
          // Perform click - try multiple event dispatch methods for reliability
          let clickSucceeded = false;
          
          // Method 1: Native click()
          element.click();
          clickSucceeded = true;
          
          // Method 2: If element has href and click didn't navigate, also dispatch events
          if (element.tagName === 'A' && element.href) {
            const mouseDown = new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window });
            const mouseUp = new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window });
            element.dispatchEvent(mouseDown);
            element.dispatchEvent(mouseUp);
          }
          
          // CAPTURE STATE AFTER CLICK (with small delay for async handlers)
          // Use sync check first, async changes detected on next snapshot
          const afterState = captureDOMState();
          const changeResult = detectChanges(beforeState, afterState);
          
          return { 
            success: true, 
            method: method, 
            changeDetected: changeResult.changed,
            changeReason: changeResult.reason,
            // Include timing for debugging
            clickDuration: afterState.timestamp - beforeState.timestamp
          };
        } catch (e) {
          return { success: false, method: method, error: e.message };
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // STRATEGY 1: htmlId (most stable - IDs rarely change)
      // ════════════════════════════════════════════════════════════════════
      if (nodeInfo.htmlId) {
        strategies.push('htmlId');
        const el = document.getElementById(nodeInfo.htmlId);
        if (el) {
          const result = performClick(el, 'htmlId');
          if (result.success) return result;
          errors.push(`htmlId: ${result.error}`);
        } else {
          errors.push('htmlId: element not found');
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // STRATEGY 2: CSS selector
      // ════════════════════════════════════════════════════════════════════
      if (nodeInfo.selector) {
        strategies.push('selector');
        try {
          const el = document.querySelector(nodeInfo.selector);
          if (el) {
            const result = performClick(el, 'selector');
            if (result.success) return result;
            errors.push(`selector: ${result.error}`);
          } else {
            errors.push('selector: element not found');
          }
        } catch (e) {
          errors.push(`selector: ${e.message}`);
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // STRATEGY 2.5: Stable Hash lookup (NEW - survives DOM changes)
      // Uses multiple element attributes to find the same element even if
      // the page structure changed slightly
      // ════════════════════════════════════════════════════════════════════
      if (nodeInfo.stableHash && nodeInfo.tagName) {
        strategies.push('stableHash');
        
        // Recreate hash generation to find matching elements
        function computeElementHash(element) {
          const components = [];
          components.push(element.tagName?.toLowerCase() || 'unknown');
          if (element.id) components.push(`id:${element.id}`);
          const stableAttrs = ['name', 'data-testid', 'data-test', 'role', 'type', 'href', 'aria-label'];
          for (const attr of stableAttrs) {
            const value = element.getAttribute(attr);
            if (value) components.push(`${attr}:${value.substring(0, 50)}`);
          }
          if (element.className && typeof element.className === 'string') {
            const classes = element.className.split(/\s+/)
              .filter(c => c && c.length > 1 && c.length < 40)
              .filter(c => !/^(is-|has-|ng-|v-|js-|css-|__|\d)/.test(c))
              .sort().slice(0, 5);
            if (classes.length > 0) components.push(`cls:${classes.join('.')}`);
          }
          const landmark = element.closest('[role="main"], [role="navigation"], main, nav, header, footer, aside, form');
          if (landmark && landmark !== element) {
            const siblings = Array.from(landmark.querySelectorAll(element.tagName?.toLowerCase() || '*'));
            const index = siblings.indexOf(element);
            if (index > -1) {
              const landmarkId = landmark.id || landmark.getAttribute('role') || landmark.tagName.toLowerCase();
              components.push(`pos:${landmarkId}[${index}]`);
            }
          }
          const text = (element.textContent || '').trim().substring(0, 30);
          if (text && text.length > 2) {
            let textHash = 0;
            for (let i = 0; i < text.length; i++) {
              textHash = ((textHash << 5) - textHash) + text.charCodeAt(i);
              textHash = textHash & textHash;
            }
            components.push(`txt:${Math.abs(textHash).toString(36).substring(0, 6)}`);
          }
          const fingerprint = components.join('|');
          let hash = 0;
          for (let i = 0; i < fingerprint.length; i++) {
            hash = ((hash << 5) - hash) + fingerprint.charCodeAt(i);
            hash = hash & hash;
          }
          return Math.abs(hash).toString(36);
        }
        
        // Search for elements with matching hash
        const targetTag = nodeInfo.tagName.toLowerCase();
        const candidates = document.querySelectorAll(targetTag);
        for (const el of candidates) {
          if (computeElementHash(el) === nodeInfo.stableHash) {
            const rect = el.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
              const result = performClick(el, 'stableHash');
              if (result.success) return result;
              errors.push(`stableHash: ${result.error}`);
              break; // Only try the first match
            }
          }
        }
        if (!errors.some(e => e.startsWith('stableHash'))) {
          errors.push('stableHash: no matching element found');
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // STRATEGY 3: Text content matching (resilient to DOM changes)
      // ════════════════════════════════════════════════════════════════════
      const textToMatch = nodeInfo.textContent || nodeInfo.name || nodeInfo.ariaLabel;
      if (textToMatch && textToMatch.length > 2) {
        strategies.push('text');
        const normalizedText = textToMatch.toLowerCase().trim();
        
        // Search for elements with matching text
        const candidates = [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null, false);
        let node;
        while (node = walker.nextNode()) {
          // Check text content
          const nodeText = (node.textContent || '').toLowerCase().trim();
          const ariaLabel = (node.getAttribute('aria-label') || '').toLowerCase().trim();
          
          if (nodeText === normalizedText || ariaLabel === normalizedText ||
              (nodeText.includes(normalizedText) && nodeText.length < normalizedText.length * 3)) {
            // Verify it's visible and clickable
            const rect = node.getBoundingClientRect();
            const style = window.getComputedStyle(node);
            if (rect.width > 0 && rect.height > 0 && 
                style.display !== 'none' && style.visibility !== 'hidden') {
              candidates.push({ el: node, exactMatch: nodeText === normalizedText || ariaLabel === normalizedText });
            }
          }
        }
        
        // Prefer exact matches
        candidates.sort((a, b) => (b.exactMatch ? 1 : 0) - (a.exactMatch ? 1 : 0));
        
        if (candidates.length > 0) {
          const result = performClick(candidates[0].el, 'text');
          if (result.success) return result;
          errors.push(`text: ${result.error}`);
        } else {
          errors.push('text: no matching element found');
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // STRATEGY 4: Coordinates (last resort - may click wrong element)
      // ════════════════════════════════════════════════════════════════════
      if (nodeInfo.bounds || nodeInfo.coordinates) {
        strategies.push('coordinates');
        const coords = nodeInfo.coordinates || {
          x: nodeInfo.bounds.x + nodeInfo.bounds.width / 2,
          y: nodeInfo.bounds.y + nodeInfo.bounds.height / 2
        };
        
        const el = document.elementFromPoint(coords.x, coords.y);
        if (el && el.tagName !== 'HTML' && el.tagName !== 'BODY') {
          const result = performClick(el, 'coordinates');
          if (result.success) return result;
          errors.push(`coordinates: ${result.error}`);
        } else {
          errors.push('coordinates: no element at point');
        }
      }
      
      // ════════════════════════════════════════════════════════════════════
      // ALL STRATEGIES FAILED
      // ════════════════════════════════════════════════════════════════════
      return {
        success: false,
        error: `All click strategies failed. Tried: ${strategies.join(', ')}. Errors: ${errors.join('; ')}`,
        strategiesTried: strategies,
        needsSnapshot: true  // Only NOW do we tell LLM to get fresh snapshot
      };
    },
    args: [nodeInfo, displayName]
  });
  
  // NULL SAFETY: Script execution can return null if tab context changed
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed - tab may have navigated', needsSnapshot: true };
  }
  
  const result = results[0].result;
  
  // Log which strategy succeeded and change detection result
  if (result.success) {
    const changeInfo = result.changeDetected 
      ? `(change: ${result.changeReason})` 
      : '(no immediate change detected - may be async)';
    logWithTimestamp('info', `✅ Click SUCCESS via ${result.method}: "${displayName}" ${changeInfo}`);
    
    // ASYNC CHANGE DETECTION: Wait briefly and check for delayed changes
    // This catches AJAX responses, animations, etc.
    if (!result.changeDetected) {
      try {
        await new Promise(resolve => setTimeout(resolve, 300));
        const asyncCheckResult = await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          func: () => {
            // Check for common async change indicators
            return {
              url: window.location.href,
              hasLoader: !!document.querySelector('.loading, .spinner, [aria-busy="true"]'),
              pendingXHR: window.performance?.getEntriesByType?.('resource')?.filter(
                e => e.initiatorType === 'xmlhttprequest' && Date.now() - e.responseEnd < 500
              ).length > 0
            };
          }
        });
        
        if (asyncCheckResult?.[0]?.result) {
          const asyncState = asyncCheckResult[0].result;
          if (asyncState.hasLoader || asyncState.pendingXHR) {
            result.asyncChangeDetected = true;
            result.asyncChangeReason = asyncState.hasLoader ? 'loader_visible' : 'xhr_pending';
            logWithTimestamp('info', `  └─ Async activity detected: ${result.asyncChangeReason}`);
          }
        }
      } catch (e) {
        // Async check failed, continue anyway
      }
    }
  } else {
    logWithTimestamp('warn', `❌ Click FAILED after all fallbacks: "${displayName}"`, { error: result.error });
  }
  
  return result;
}

async function typeText(tabId, selector, text) {
  // Ensure visualizations are available
  await ensureVisualizationsInjected(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (selector, text) => {
      // BrowserOS-STYLE: Try multiple ways to find the element
      let element = document.querySelector(selector);
      
      // If not found, try in shadow DOM
      if (!element) {
        const allElements = document.querySelectorAll('*');
        for (const el of allElements) {
          if (el.shadowRoot) {
            element = el.shadowRoot.querySelector(selector);
            if (element) break;
          }
        }
      }
      
      // If still not found, try in iframes
      if (!element) {
        const iframes = document.querySelectorAll('iframe');
        for (const iframe of iframes) {
          try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
            if (iframeDoc) {
              element = iframeDoc.querySelector(selector);
              if (element) break;
            }
          } catch (e) {
            // Cross-origin, skip
          }
        }
      }
      
      if (!element) {
        return { success: false, error: `Element not found: ${selector}` };
      }
      
      // Scroll into view
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      // BROWSERÓS-STYLE VISUAL FEEDBACK: Show typing indicator
      const rect = element.getBoundingClientRect();
      if (window.centrisHighlightElement) {
        window.centrisHighlightElement(rect.left, rect.top, rect.width, rect.height);
      }
      if (window.centrisShowTyping) {
        window.centrisShowTyping(rect.left, rect.top, text);
      }
      
      // Focus the element
      element.focus();
      
      // Small delay for focus to establish
      await new Promise(resolve => setTimeout(resolve, 50));
      
      // BrowserOS-STYLE: Try multiple typing methods with change detection
      const beforeContent = getElementContent(element);
      
      // METHOD 1: Try keyboard simulation first (most reliable for complex editors)
      const keyboardResult = await simulateKeyboardTyping(element, text);
      if (keyboardResult.success) {
        const afterContent = getElementContent(element);
        if (afterContent.includes(text.substring(0, Math.min(20, text.length)))) {
          return { success: true, changeDetected: true, type: 'keyboard-simulation' };
        }
      }
      
      // METHOD 2: Check if this is a contenteditable element (Google Docs, Gmail compose, etc.)
      if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
        // Clear and use execCommand
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
        
        try {
          const inserted = document.execCommand('insertText', false, text);
          if (inserted) {
            element.dispatchEvent(new Event('input', { bubbles: true }));
            const afterContent = getElementContent(element);
            if (afterContent !== beforeContent) {
              return { success: true, changeDetected: true, type: 'execCommand' };
            }
          }
        } catch (e) {
          // execCommand failed
        }
        
        // Fallback for contenteditable: direct setting
        element.textContent = text;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        return { success: true, changeDetected: true, type: 'contenteditable-direct' };
      }
      
      // METHOD 3: Standard input/textarea handling
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        element.value = text;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        return { success: true, changeDetected: true, type: 'input-value' };
      }
      
      // METHOD 4: Fallback for other elements
      if (element.textContent !== undefined) {
        element.textContent = text;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        return { success: true, changeDetected: true, type: 'fallback-textContent' };
      }
      
      return { success: false, error: 'Could not type into element' };
      
      // Helper: Get element content
      function getElementContent(el) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          return el.value || '';
        }
        return el.textContent || el.innerText || '';
      }
      
      // BrowserOS-STYLE: Simulate keyboard typing
      async function simulateKeyboardTyping(el, text) {
        return new Promise((resolve) => {
          let charIndex = 0;
          
          function typeNextChar() {
            if (charIndex >= text.length) {
              resolve({ success: true });
              return;
            }
            
            const char = text[charIndex];
            const keyCode = char.charCodeAt(0);
            
            // Dispatch keyboard events
            el.dispatchEvent(new KeyboardEvent('keydown', {
              key: char, code: `Key${char.toUpperCase()}`,
              keyCode: keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
            
            el.dispatchEvent(new KeyboardEvent('keypress', {
              key: char, code: `Key${char.toUpperCase()}`,
              keyCode: keyCode, charCode: keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
            
            // Insert character
            if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
              document.execCommand('insertText', false, char);
            } else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
              const start = el.selectionStart || el.value.length;
              el.value = el.value.substring(0, start) + char + el.value.substring(start);
              el.selectionStart = el.selectionEnd = start + 1;
            }
            
            el.dispatchEvent(new InputEvent('input', {
              data: char, inputType: 'insertText',
              bubbles: true, cancelable: true
            }));
            
            el.dispatchEvent(new KeyboardEvent('keyup', {
              key: char, code: `Key${char.toUpperCase()}`,
              keyCode: keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
            
            charIndex++;
            // Faster typing for longer text
            const delay = text.length > 50 ? 1 : (text.length > 20 ? 5 : 10);
            setTimeout(typeNextChar, delay);
          }
          
          typeNextChar();
        });
      }
    },
    args: [selector, text]
  });
  // NULL SAFETY: Handle script execution failures
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed during typing' };
  }
  return results[0].result || { success: false, error: 'No result from type operation' };
}

// ═══════════════════════════════════════════════════════════════════════════════
// PASTE TEXT - Copy to clipboard and paste with Cmd+V/Ctrl+V
// BEST FOR CANVAS EDITORS: Google Docs, Notion, Figma, etc.
// These editors don't have standard input elements but DO handle paste events
// ═══════════════════════════════════════════════════════════════════════════════
async function pasteText(tabId, text) {
  logWithTimestamp('info', `📋 Pasting text: "${text.substring(0, 50)}..." via clipboard`);
  
  await ensureVisualizationsInjected(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (text) => {
      // Step 1: Copy text to clipboard
      try {
        await navigator.clipboard.writeText(text);
      } catch (clipboardError) {
        // Clipboard API might fail in some contexts - try fallback
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        textArea.style.top = '-9999px';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      
      // Visual feedback
      if (window.centrisShowActionToast) {
        const displayText = text.length > 25 ? text.substring(0, 25) + '...' : text;
        window.centrisShowActionToast(`Pasting: "${displayText}"`, '📋');
      }
      
      // Step 2: Simulate paste (Cmd+V / Ctrl+V)
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const modifier = isMac ? 'metaKey' : 'ctrlKey';
      
      // Dispatch paste keyboard event to the active element or document
      const target = document.activeElement || document.body;
      
      // keydown with modifier
      target.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'v',
        code: 'KeyV',
        keyCode: 86,
        [modifier]: true,
        bubbles: true,
        cancelable: true
      }));
      
      // Create and dispatch a ClipboardEvent for paste
      try {
        const dt = new DataTransfer();
        dt.setData('text/plain', text);
        const pasteEvent = new ClipboardEvent('paste', {
          clipboardData: dt,
          bubbles: true,
          cancelable: true
        });
        target.dispatchEvent(pasteEvent);
      } catch (e) {
        // ClipboardEvent might not work in all contexts
        // The keyboard shortcut should still trigger native paste
      }
      
      // keyup
      target.dispatchEvent(new KeyboardEvent('keyup', {
        key: 'v',
        code: 'KeyV',
        keyCode: 86,
        [modifier]: true,
        bubbles: true,
        cancelable: true
      }));
      
      // Small delay for paste to process
      await new Promise(r => setTimeout(r, 100));
      
      // Also try document.execCommand paste
      try {
        document.execCommand('paste');
      } catch (e) {
        // execCommand paste often fails for security
      }
      
      return { success: true, method: 'clipboard-paste' };
    },
    args: [text]
  });
  
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed during paste' };
  }
  return results[0].result || { success: false, error: 'No result from paste operation' };
}

// ═══════════════════════════════════════════════════════════════════════════════
// GLOBAL TYPE - Type by dispatching keyboard events to document
// For complex editors where type_text fails to find the right element
// Google Docs, Notion, and similar editors listen for keyboard events globally
// ═══════════════════════════════════════════════════════════════════════════════
async function globalType(tabId, text) {
  logWithTimestamp('info', `⌨️ Global typing: "${text.substring(0, 50)}..." to document`);
  
  await ensureVisualizationsInjected(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (text) => {
      // Visual feedback
      if (window.centrisShowActionToast) {
        const displayText = text.length > 25 ? text.substring(0, 25) + '...' : text;
        window.centrisShowActionToast(`Typing: "${displayText}"`, '⌨️');
      }
      
      // Type character by character to the document/active element
      const target = document.activeElement || document.body;
      
      return new Promise((resolve) => {
        let charIndex = 0;
        
        function typeNextChar() {
          if (charIndex >= text.length) {
            resolve({ success: true, typed: text.length, method: 'global-keyboard' });
            return;
          }
          
          const char = text[charIndex];
          const keyCode = char.charCodeAt(0);
          
          // Create proper key code
          let key = char;
          let code = 'Key' + char.toUpperCase();
          if (char === ' ') { key = ' '; code = 'Space'; }
          else if (char === '\n') { key = 'Enter'; code = 'Enter'; }
          else if (char === '\t') { key = 'Tab'; code = 'Tab'; }
          
          // Dispatch to both activeElement and document for maximum compatibility
          [target, document].forEach(t => {
            // keydown
            t.dispatchEvent(new KeyboardEvent('keydown', {
              key, code, keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
            
            // keypress (deprecated but still used by some apps)
            t.dispatchEvent(new KeyboardEvent('keypress', {
              key, code, keyCode, charCode: keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
            
            // input event
            t.dispatchEvent(new InputEvent('input', {
              data: char, inputType: 'insertText',
              bubbles: true, cancelable: true
            }));
            
            // Also try beforeinput for newer apps
            t.dispatchEvent(new InputEvent('beforeinput', {
              data: char, inputType: 'insertText',
              bubbles: true, cancelable: true
            }));
            
            // keyup
            t.dispatchEvent(new KeyboardEvent('keyup', {
              key, code, keyCode, which: keyCode,
              bubbles: true, cancelable: true
            }));
          });
          
          // Also try execCommand insertText on active element
          if (target.isContentEditable || target !== document.body) {
            try {
              document.execCommand('insertText', false, char);
            } catch (e) {}
          }
          
          charIndex++;
          // Fast typing for longer text (1ms delay), slower for short text (5ms)
          const delay = text.length > 50 ? 1 : 5;
          setTimeout(typeNextChar, delay);
        }
        
        typeNextChar();
      });
    },
    args: [text]
  });
  
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed during global typing' };
  }
  return results[0].result || { success: false, error: 'No result from global type operation' };
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLICK BY STABLE HASH - More reliable than nodeId
// 
// The stableHash is computed from element attributes and survives DOM changes.
// This function first tries to find the element by stableHash, then falls back
// to nodeId if hash lookup fails.
// ═══════════════════════════════════════════════════════════════════════════════
async function clickNodeByHash(tabId, stableHash, nodeIdFallback) {
  // Get current tab mapping
  const tabMapping = nodeIdMappings.get(tabId);
  
  if (!tabMapping) {
    return { 
      success: false, 
      error: 'No snapshot data for this tab. Call getInteractiveSnapshot first.',
      needsSnapshot: true 
    };
  }
  
  // First, try to find element by stableHash in the current mapping
  let nodeId = null;
  let nodeInfo = null;
  
  for (const [id, info] of tabMapping.entries()) {
    if (info.stableHash === stableHash) {
      nodeId = id;
      nodeInfo = info;
      break;
    }
  }
  
  // If hash lookup succeeded, use standard clickNode
  if (nodeId !== null) {
    logWithTimestamp('info', `✅ Found element by stableHash: ${stableHash} → nodeId ${nodeId}`);
    return clickNode(tabId, nodeId);
  }
  
  // Hash lookup failed - try nodeIdFallback if provided
  if (nodeIdFallback !== null && nodeIdFallback !== undefined) {
    logWithTimestamp('info', `⚠️ stableHash ${stableHash} not found, trying nodeId fallback: ${nodeIdFallback}`);
    return clickNode(tabId, nodeIdFallback);
  }
  
  // Both failed - need fresh snapshot
  return {
    success: false,
    error: `Element with stableHash "${stableHash}" not found. The page may have changed significantly - call getInteractiveSnapshot to get fresh element data.`,
    needsSnapshot: true
  };
}

async function inputTextNode(tabId, nodeId, text) {
  // BrowserOS-style node-based text input with VISUAL FEEDBACK and MULTIPLE FALLBACK METHODS
  const tabMapping = nodeIdMappings.get(tabId);
  if (!tabMapping) {
    return { success: false, error: 'No snapshot data for this tab. Call getInteractiveSnapshot first.' };
  }
  
  const nodeInfo = tabMapping.get(nodeId);
  if (!nodeInfo) {
    return { success: false, error: `Node ID ${nodeId} not found` };
  }
  
  // Get a descriptive name for the field
  const fieldName = nodeInfo.ariaLabel || nodeInfo.placeholder || nodeInfo.name || `Node ${nodeId}`;
  const displayField = fieldName.length > 30 ? fieldName.substring(0, 30) + '...' : fieldName;
  const displayText = text.length > 25 ? text.substring(0, 25) + '...' : text;
  
  // Log comprehensive node info for debugging (using semantic attributes)
  logWithTimestamp('info', `⌨️ TYPING: "${displayText}" into "${displayField}"`, { nodeId });
  logWithTimestamp('info', `📝 inputTextNode: Targeting node ${nodeId}`, {
    type: nodeInfo.type,
    ariaLabel: nodeInfo.ariaLabel || 'none',
    placeholder: nodeInfo.placeholder || 'none',
    role: nodeInfo.role || 'none',
    area: nodeInfo.area || 0,
    isContentEditable: nodeInfo.isContentEditable || false,
    isInDialog: nodeInfo.isInDialog || false,
    selector: nodeInfo.selector,
    name: nodeInfo.name?.substring(0, 50) || 'none'
  });
  
  // VALIDATION: Warn if trying to type into a small field with long text (might be title vs body confusion)
  // Generic size-based warning - works for any site
  if (nodeInfo.area && nodeInfo.area < 10000 && text.length > 100) {
    logWithTimestamp('warn', `⚠️ WARNING: Typing ${text.length} chars into small field (area: ${nodeInfo.area}). ` +
      `This might be a title/subject field. Consider using a larger input field for long content.`);
  }
  
  // ══════════════════════════════════════════════════════════════════════════
  // PRIORITY 1: CDP OVERLAY - Works on ALL sites including Gmail!
  // The debugger banner also serves as visual indicator that AI is controlling
  // ══════════════════════════════════════════════════════════════════════════
  if (nodeInfo.bounds) {
    const bounds = nodeInfo.bounds;
    // Show CDP highlight on the input field (this will work even on Gmail!)
    await cdpHighlightRect(tabId, bounds.x, bounds.y, bounds.width, bounds.height, 2000);
  }
  
  // PRIORITY 2: Also try JS-based visualization
  await ensureVisualizationsInjected(tabId);
  
  // Try to show typing toast (may be blocked by CSP)
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (displayField, displayText) => {
        if (window.centrisShowActionToast) {
          window.centrisShowActionToast(`Typing "${displayText}" into ${displayField}`, '⌨️');
        }
      },
      args: [displayField, displayText]
    });
  } catch (e) {
    // CSP may block this - CDP overlay is the fallback
    logWithTimestamp('debug', `Toast blocked by CSP, CDP overlay shown instead`);
  }
  
  // If node is typeable and has a selector, use direct approach
  if (nodeInfo.type === 'typeable' && nodeInfo.selector) {
    return await typeText(tabId, nodeInfo.selector, text);
  }
  
  // FALLBACK: Click to focus, then type into focused element
  // This handles complex editors and non-typeable nodes
  logWithTimestamp('info', `📝 Using click-then-type approach for node ${nodeId} (type: ${nodeInfo.type}, area: ${nodeInfo.area || 0})`);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (bounds, text, nodeType, nodeName) => {
      const x = bounds.x + bounds.width / 2;
      const y = bounds.y + bounds.height / 2;
      
      const element = document.elementFromPoint(x, y);
      if (!element) {
        return { success: false, error: 'No element found at coordinates' };
      }
      
      // BROWSERÓS-STYLE VISUAL FEEDBACK
      if (window.centrisHighlightElement) {
        window.centrisHighlightElement(bounds.x, bounds.y, bounds.width, bounds.height);
      }
      if (window.centrisShowTyping) {
        window.centrisShowTyping(bounds.x, bounds.y, text);
      }
      
      // Show action toast
      if (window.centrisShowActionToast) {
        const displayText = text.length > 25 ? text.substring(0, 25) + '...' : text;
        window.centrisShowActionToast(`Typing: "${displayText}"`, '✏️');
      }
      
      // Step 1: Click the element to focus it (BrowserOS approach)
      element.click();
      element.focus();
      
      // Give the click time to register and focus to be established
      return new Promise((resolve) => {
        setTimeout(async () => {
          // Step 2: After focus, try multiple methods to type
          const focused = document.activeElement;
          
          // Check if we have a focusable element
          if (!focused || focused === document.body) {
            // Try to find editable elements inside or around the clicked element
            const editable = findEditableElement(element);
            if (editable) {
              editable.focus();
              const result = await tryAllTypingMethods(editable, text);
              resolve(result);
              return;
            }
            resolve({ success: false, error: 'No focusable element found after click' });
            return;
          }
          
          const result = await tryAllTypingMethods(focused, text);
          resolve(result);
        }, 100); // 100ms delay for focus to establish (BrowserOS uses this)
      });
      
      // BrowserOS-style: Find the best editable element in the area
      function findEditableElement(startElement) {
        // Try direct contenteditable
        if (startElement.isContentEditable || startElement.getAttribute('contenteditable') === 'true') {
          return startElement;
        }
        
        // Try finding inside the element
        const insideEditable = startElement.querySelector('[contenteditable="true"], input, textarea, [role="textbox"]');
        if (insideEditable) return insideEditable;
        
        // Try finding in parent chain
        const parentEditable = startElement.closest('[contenteditable="true"], [role="textbox"]');
        if (parentEditable) return parentEditable;
        
        // Try shadow DOM
        if (startElement.shadowRoot) {
          const shadowEditable = startElement.shadowRoot.querySelector('[contenteditable="true"], input, textarea');
          if (shadowEditable) return shadowEditable;
        }
        
        // Walk up and look in siblings (for complex layouts)
        let parent = startElement.parentElement;
        let depth = 0;
        while (parent && depth < 5) {
          const siblingEditable = parent.querySelector('[contenteditable="true"], input, textarea');
          if (siblingEditable && siblingEditable !== startElement) {
            return siblingEditable;
          }
          parent = parent.parentElement;
          depth++;
        }
        
        return null;
      }
      
      // BrowserOS-STYLE: Try multiple typing methods with change detection
      async function tryAllTypingMethods(el, text) {
        const beforeContent = getElementContent(el);
        let method = '';
        
        // METHOD 1: Try keyboard event simulation (most like real typing)
        try {
          const keyboardResult = await simulateKeyboardTyping(el, text);
          if (keyboardResult.success) {
            const afterContent = getElementContent(el);
            if (afterContent !== beforeContent || afterContent.includes(text.substring(0, 20))) {
              return { success: true, changeDetected: true, type: 'keyboard-simulation', method: 'keyboard' };
            }
          }
        } catch (e) {
          // Keyboard simulation failed, try next method
        }
        
        // METHOD 2: Try execCommand insertText (works for many rich editors)
        try {
          if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
            // Clear existing and insert new
            const selection = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(el);
            selection.removeAllRanges();
            selection.addRange(range);
            
            const inserted = document.execCommand('insertText', false, text);
            if (inserted) {
              el.dispatchEvent(new Event('input', { bubbles: true }));
              const afterContent = getElementContent(el);
              if (afterContent !== beforeContent) {
                return { success: true, changeDetected: true, type: 'execCommand', method: 'insertText' };
              }
            }
          }
        } catch (e) {
          // execCommand failed, try next
        }
        
        // METHOD 3: Try setting value/textContent directly
        try {
          if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.value = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            return { success: true, changeDetected: true, type: 'value', method: 'direct-value' };
          } else if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
            el.textContent = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            return { success: true, changeDetected: true, type: 'textContent', method: 'direct-textContent' };
          }
        } catch (e) {
          // Direct setting failed
        }
        
        // METHOD 4: Find nested editable and recurse
        const nestedEditable = el.querySelector('input, textarea, [contenteditable="true"]');
        if (nestedEditable && nestedEditable !== el) {
          nestedEditable.focus();
          return tryAllTypingMethods(nestedEditable, text);
        }
        
        // METHOD 5: Fallback - try innerText for contenteditable-like elements
        try {
          if (el.innerText !== undefined) {
            el.innerText = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            return { success: true, changeDetected: true, type: 'innerText', method: 'fallback-innerText' };
          }
        } catch (e) {
          // Last resort failed
        }
        
        return { success: false, error: `All typing methods failed for element (tag: ${el.tagName})` };
      }
      
      // Get element content for change detection
      function getElementContent(el) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          return el.value || '';
        }
        return el.textContent || el.innerText || '';
      }
      
      // BrowserOS-STYLE: Simulate keyboard typing character by character
      async function simulateKeyboardTyping(el, text) {
        return new Promise((resolve) => {
          let typed = '';
          let charIndex = 0;
          
          function typeNextChar() {
            if (charIndex >= text.length) {
              resolve({ success: true, typed: typed });
              return;
            }
            
            const char = text[charIndex];
            const keyCode = char.charCodeAt(0);
            
            // Create and dispatch keydown event
            const keydownEvent = new KeyboardEvent('keydown', {
              key: char,
              code: `Key${char.toUpperCase()}`,
              keyCode: keyCode,
              which: keyCode,
              bubbles: true,
              cancelable: true
            });
            el.dispatchEvent(keydownEvent);
            
            // Create and dispatch keypress event
            const keypressEvent = new KeyboardEvent('keypress', {
              key: char,
              code: `Key${char.toUpperCase()}`,
              keyCode: keyCode,
              charCode: keyCode,
              which: keyCode,
              bubbles: true,
              cancelable: true
            });
            el.dispatchEvent(keypressEvent);
            
            // For contenteditable, we need to insert the character
            if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
              try {
                document.execCommand('insertText', false, char);
              } catch (e) {
                // If execCommand fails, try direct insertion
                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                  const range = selection.getRangeAt(0);
                  range.deleteContents();
                  range.insertNode(document.createTextNode(char));
                  range.collapse(false);
                  selection.removeAllRanges();
                  selection.addRange(range);
                }
              }
            } else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
              // For input/textarea, append to value
              const start = el.selectionStart || el.value.length;
              const end = el.selectionEnd || el.value.length;
              el.value = el.value.substring(0, start) + char + el.value.substring(end);
              el.selectionStart = el.selectionEnd = start + 1;
            }
            
            // Create and dispatch input event
            el.dispatchEvent(new InputEvent('input', {
              data: char,
              inputType: 'insertText',
              bubbles: true,
              cancelable: true
            }));
            
            // Create and dispatch keyup event
            const keyupEvent = new KeyboardEvent('keyup', {
              key: char,
              code: `Key${char.toUpperCase()}`,
              keyCode: keyCode,
              which: keyCode,
              bubbles: true,
              cancelable: true
            });
            el.dispatchEvent(keyupEvent);
            
            typed += char;
            charIndex++;
            
            // Small delay between characters (faster for longer text)
            const delay = text.length > 50 ? 1 : (text.length > 20 ? 5 : 10);
            setTimeout(typeNextChar, delay);
          }
          
          typeNextChar();
        });
      }
    },
    args: [nodeInfo.bounds, text, nodeInfo.type, nodeInfo.name || '']
  });
  
  // NULL SAFETY: Handle script execution failures
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed during input' };
  }
  return results[0].result || { success: false, error: 'No result from input operation' };
}

// BrowserOS-STYLE: Find the best input element for a specific purpose
// Uses GENERIC semantic matching - no site-specific hardcoding
// purpose: describes what you're looking for (e.g., 'main text area', 'search', 'title')
async function findBestInput(tabId, purpose) {
  logWithTimestamp('info', `🔍 findBestInput: Looking for '${purpose}' input on tab ${tabId}`);
  
  // First, get the current snapshot to ensure we have fresh data
  const snapshot = await getInteractiveSnapshot(tabId);
  if (!snapshot || !snapshot.interactiveNodes) {
    return { success: false, error: 'Failed to get interactive snapshot' };
  }
  
  const typeableNodes = snapshot.interactiveNodes.filter(n => n.type === 'typeable');
  if (typeableNodes.length === 0) {
    return { success: false, error: 'No typeable elements found on page' };
  }
  
  const purposeLower = purpose.toLowerCase();
  let bestMatch = null;
  let bestScore = -1;
  
  for (const node of typeableNodes) {
    let score = 0;
    
    // GENERIC semantic matching based on element attributes
    const textToCheck = `${node.name || ''} ${node.ariaLabel || ''} ${node.placeholder || ''} ${node.role || ''}`.toLowerCase();
    
    // Direct text match with purpose
    if (textToCheck.includes(purposeLower)) {
      score += 100;
    }
    
    // Common semantic patterns (generic, works for any site)
    const wantsLargeArea = purposeLower.includes('body') || purposeLower.includes('content') || 
                          purposeLower.includes('message') || purposeLower.includes('post') ||
                          purposeLower.includes('compose') || purposeLower.includes('editor');
    const wantsSmallArea = purposeLower.includes('title') || purposeLower.includes('subject') ||
                          purposeLower.includes('search') || purposeLower.includes('to') ||
                          purposeLower.includes('name') || purposeLower.includes('email');
    
    // Score based on area - larger elements are typically main content areas
    if (wantsLargeArea) {
      score += Math.min(node.area / 1000, 50);  // Up to 50 bonus for larger areas
      if (node.area > 30000) score += 30;  // Bonus for very large areas
    } else if (wantsSmallArea) {
      if (node.area < 15000) score += 40;  // Prefer smaller areas
    }
    
    // Prefer contenteditable for body/content (rich text editors)
    if (wantsLargeArea && node.isContentEditable) {
      score += 30;
    }
    
    // Context matching
    if (node.isInDialog && purposeLower.includes('dialog')) {
      score += 20;
    }
    if (node.role === 'textbox' && (wantsLargeArea || textToCheck.includes('editor'))) {
      score += 20;
    }
    if (node.role === 'searchbox' && purposeLower.includes('search')) {
      score += 50;
    }
    
    if (score > bestScore) {
      bestScore = score;
      bestMatch = node;
    }
  }
  
  if (bestMatch && bestScore > 0) {
    logWithTimestamp('info', `✅ Found best match for '${purpose}': nodeId=${bestMatch.nodeId}, area=${bestMatch.area}, score=${bestScore}`);
    return {
      success: true,
      nodeId: bestMatch.nodeId,
      node: {
        nodeId: bestMatch.nodeId,
        type: bestMatch.type,
        name: bestMatch.name?.substring(0, 50) || '',
        area: bestMatch.area,
        ariaLabel: bestMatch.ariaLabel || '',
        role: bestMatch.role || '',
        isContentEditable: bestMatch.isContentEditable,
        bounds: bestMatch.bounds
      },
      score: bestScore,
      message: `Found input matching '${purpose}': nodeId=${bestMatch.nodeId}, area=${bestMatch.area}`
    };
  }
  
  // No good match found - use area-based fallback
  const sortedByArea = [...typeableNodes].sort((a, b) => (b.area || 0) - (a.area || 0));
  const wantsLarge = purposeLower.includes('body') || purposeLower.includes('content') || purposeLower.includes('message');
  const fallback = wantsLarge ? sortedByArea[0] : sortedByArea[sortedByArea.length - 1];
  
  if (fallback) {
    logWithTimestamp('info', `⚠️ No semantic match for '${purpose}', using area-based fallback: nodeId=${fallback.nodeId}`);
    return {
      success: true,
      nodeId: fallback.nodeId,
      node: {
        nodeId: fallback.nodeId,
        type: fallback.type,
        name: fallback.name?.substring(0, 50) || '',
        area: fallback.area,
        ariaLabel: fallback.ariaLabel || '',
        role: fallback.role || '',
        bounds: fallback.bounds
      },
      score: 0,
      isFallback: true,
      message: `Using ${wantsLarge ? 'largest' : 'smallest'} typeable element as fallback for '${purpose}'`
    };
  }
  
  return { success: false, error: `No suitable input found for purpose: ${purpose}` };
}

// BrowserOS-STYLE: Type into the currently focused element
// This is useful for complex editors like Google Docs where finding the right node is tricky
async function typeIntoFocused(tabId, text) {
  logWithTimestamp('info', `📝 typeIntoFocused: Typing into focused element on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  // Ensure visualizations are available
  await ensureVisualizationsInjected(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (text) => {
      let focused = document.activeElement;
      
      // Show visual feedback for typing
      if (focused && focused !== document.body) {
        const rect = focused.getBoundingClientRect();
        if (window.centrisHighlightElement) {
          window.centrisHighlightElement(rect.left, rect.top, rect.width, rect.height);
        }
        if (window.centrisShowTyping) {
          window.centrisShowTyping(rect.left, rect.top, text);
        }
      }
      
      // BrowserOS-STYLE: Deep search for editable elements if none focused
      if (!focused || focused === document.body || focused === document.documentElement) {
        // Try to find any editable element on the page
        focused = findBestEditableElement();
        if (!focused) {
          return { success: false, error: 'No focused or editable element found. Click on an input field first.' };
        }
        focused.focus();
      }
      
      // BrowserOS-style: Find the best editable element
      function findBestEditableElement() {
        // Priority 1: Visible contenteditable elements
        const editables = document.querySelectorAll('[contenteditable="true"]');
        for (const el of editables) {
          const rect = el.getBoundingClientRect();
          const style = window.getComputedStyle(el);
          if (rect.width > 0 && rect.height > 0 && 
              style.display !== 'none' && style.visibility !== 'hidden') {
            return el;
          }
        }
        
        // Priority 2: Textbox role elements
        const textboxes = document.querySelectorAll('[role="textbox"]');
        for (const el of textboxes) {
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            return el;
          }
        }
        
        // Priority 3: Regular inputs/textareas
        const inputs = document.querySelectorAll('input:not([type="hidden"]), textarea');
        for (const el of inputs) {
          const rect = el.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0 && !el.disabled && !el.readOnly) {
            return el;
          }
        }
        
        // Priority 4: Check shadow DOMs
        const elementsWithShadow = document.querySelectorAll('*');
        for (const el of elementsWithShadow) {
          if (el.shadowRoot) {
            const shadowEditable = el.shadowRoot.querySelector('[contenteditable="true"], input, textarea');
            if (shadowEditable) {
              return shadowEditable;
            }
          }
        }
        
        // Priority 5: Check iframes (same-origin)
        const iframes = document.querySelectorAll('iframe');
        for (const iframe of iframes) {
          try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
            if (iframeDoc) {
              const iframeEditable = iframeDoc.querySelector('[contenteditable="true"], input, textarea');
              if (iframeEditable) {
                return iframeEditable;
              }
            }
          } catch (e) {
            // Cross-origin iframe, skip
          }
        }
        
        return null;
      }
      
      return typeIntoElement(focused, text);
      
      function typeIntoElement(el, text) {
        // Handle contenteditable elements (Google Docs, Gmail compose, etc.)
        if (el.isContentEditable || el.getAttribute('contenteditable') === 'true') {
          try {
            // For Google Docs and similar: place cursor at end, then insert
            const selection = window.getSelection();
            const range = document.createRange();
            
            // Try to place cursor at end
            if (el.lastChild) {
              range.selectNodeContents(el);
              range.collapse(false);
              selection.removeAllRanges();
              selection.addRange(range);
            }
            
            // Try execCommand first (most reliable for rich editors)
            const inserted = document.execCommand('insertText', false, text);
            if (!inserted) {
              // Fallback to direct content setting
              el.textContent = (el.textContent || '') + text;
            }
          } catch (e) {
            // Fallback to direct content setting
            el.textContent = (el.textContent || '') + text;
          }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          return { success: true, changeDetected: true, type: 'contenteditable' };
        }
        
        // Handle standard input/textarea
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          el.value = (el.value || '') + text;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { success: true, changeDetected: true, type: 'input' };
        }
        
        // Check for shadow DOM (some complex editors use this)
        if (el.shadowRoot) {
          const shadowInput = el.shadowRoot.querySelector('input, textarea, [contenteditable="true"]');
          if (shadowInput) {
            shadowInput.focus();
            return typeIntoElement(shadowInput, text);
          }
        }
        
        // Last resort: Try to find a nested editable element
        const nestedEditable = el.querySelector('input, textarea, [contenteditable="true"]');
        if (nestedEditable) {
          nestedEditable.focus();
          return typeIntoElement(nestedEditable, text);
        }
        
        return { success: false, error: `Focused element is not editable (tag: ${el.tagName})` };
      }
    },
    args: [text]
  });
  
  // NULL SAFETY: Handle script execution failures
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed - no focused element' };
  }
  return results[0].result || { success: false, error: 'No result from typing into focused element' };
}

// BrowserOS-STYLE: Show bounding boxes around all interactive nodes
async function showInteractiveHighlights(tabId, showLabels = true) {
  logWithTimestamp('info', `🎨 showInteractiveHighlights: Showing highlights on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  // Ensure visualizations are available
  await ensureVisualizationsInjected(tabId);
  
  // Get the current interactive nodes for this tab
  const tabMapping = nodeIdMappings.get(tabId);
  if (!tabMapping || tabMapping.size === 0) {
    return { success: false, error: 'No interactive nodes found. Call get_interactive_snapshot first.' };
  }
  
  // Convert Map to array of nodes
  const nodes = Array.from(tabMapping.values());
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (nodes, showLabels) => {
      if (window.centrisShowNodeHighlights) {
        // Always persistent when called from popup/API
        window.centrisShowNodeHighlights(nodes, showLabels, true);
        return { success: true, nodesHighlighted: nodes.length };
      }
      return { success: false, error: 'Visualization system not loaded' };
    },
    args: [nodes, showLabels]
  });
  
  // NULL SAFETY: Handle script execution failures
  if (!results || !results[0] || results[0].result === undefined) {
    return { success: false, error: 'Script execution failed - could not show highlights' };
  }
  return results[0].result || { success: false, error: 'No result from highlight operation' };
}

// Clear all visual feedback from a tab
async function clearAllVisuals(tabId) {
  logWithTimestamp('info', `🧹 clearAllVisuals: Clearing visuals on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        if (window.centrisClearVisuals) {
          window.centrisClearVisuals();
          return { success: true };
        }
        // Manual cleanup if function not available
        document.querySelectorAll('.centris-cursor-indicator').forEach(e => e.remove());
        document.querySelectorAll('.centris-element-highlight').forEach(e => e.remove());
        document.querySelectorAll('.centris-typing-indicator').forEach(e => e.remove());
        document.querySelectorAll('.centris-action-toast').forEach(e => e.remove());
        document.querySelectorAll('.centris-node-highlight').forEach(e => e.remove());
        return { success: true };
      }
    });
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SMART WAIT FUNCTIONS - Replace static delays with condition-based waits
// These provide MASSIVE latency improvements for batched tool calls!
//
// Instead of: await sleep(150) // Fixed 150ms after every click
// Now:        await waitForDomStable() // Waits only as long as needed
//
// Benefits:
// - Fast pages: ~20-50ms wait instead of 150ms
// - Slow pages: Waits until ready instead of timing out
// - SPA navigation: Detects when new content loads
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Wait for DOM to stabilize (no mutations for N milliseconds)
 * MUCH smarter than static delays!
 * 
 * @param {number} tabId - Tab to wait on
 * @param {number} stableMs - How long DOM must be stable (default 100ms)
 * @param {number} timeoutMs - Maximum wait time (default 3000ms)
 * @returns {Promise<{success: boolean, stable: boolean, mutations: number, waitedMs: number}>}
 */
async function waitForDomStable(tabId, stableMs = 100, timeoutMs = 3000) {
  logWithTimestamp('info', `⏱️ waitForDomStable: Waiting for DOM to stabilize on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (stableMs, timeoutMs) => {
        // Check if content script function is available
        if (window.centrisWaitForDomStable) {
          return window.centrisWaitForDomStable(stableMs, timeoutMs);
        }
        
        // Fallback: inline implementation if content script not loaded
        return new Promise((resolve) => {
          const startTime = Date.now();
          let mutationCount = 0;
          let lastMutationTime = Date.now();
          
          const observer = new MutationObserver((mutations) => {
            mutationCount += mutations.length;
            lastMutationTime = Date.now();
          });
          
          if (document.body) {
            observer.observe(document.body, {
              childList: true,
              subtree: true,
              attributes: true
            });
          }
          
          const interval = setInterval(() => {
            const now = Date.now();
            const elapsed = now - startTime;
            const timeSinceLastMutation = now - lastMutationTime;
            
            if (timeSinceLastMutation >= stableMs) {
              observer.disconnect();
              clearInterval(interval);
              resolve({ stable: true, mutations: mutationCount, waitedMs: elapsed });
              return;
            }
            
            if (elapsed >= timeoutMs) {
              observer.disconnect();
              clearInterval(interval);
              resolve({ stable: false, mutations: mutationCount, waitedMs: elapsed, timeout: true });
              return;
            }
          }, 20);
        });
      },
      args: [stableMs, timeoutMs]
    });
    
    const result = results[0]?.result;
    if (result) {
      logWithTimestamp('info', `⏱️ waitForDomStable: ${result.stable ? 'Stable' : 'Timeout'} after ${result.waitedMs}ms (${result.mutations} mutations)`);
      return { success: true, ...result };
    }
    
    return { success: false, error: 'No result from script' };
  } catch (e) {
    logWithTimestamp('warn', `⏱️ waitForDomStable error: ${e.message}`);
    return { success: false, error: e.message };
  }
}

/**
 * Wait for a specific condition (element appears, URL changes, etc.)
 * 
 * @param {number} tabId - Tab to wait on
 * @param {string} condition - 'element_exists' | 'element_visible' | 'url_contains' | 'url_changed'
 * @param {string} selector - CSS selector or value to match
 * @param {number} timeoutMs - Maximum wait time (default 3000ms)
 * @returns {Promise<{success: boolean, found: boolean, waitedMs: number}>}
 */
async function waitForCondition(tabId, condition, selector, timeoutMs = 3000) {
  logWithTimestamp('info', `⏱️ waitForCondition: Waiting for '${condition}' on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (condition, selector, timeoutMs) => {
        // Check if content script function is available
        if (window.centrisWaitForCondition) {
          return window.centrisWaitForCondition(condition, selector, timeoutMs);
        }
        
        // Fallback: inline implementation
        return new Promise((resolve) => {
          const startTime = Date.now();
          
          const checkCondition = () => {
            const elapsed = Date.now() - startTime;
            let found = false;
            
            switch (condition) {
              case 'element_exists':
                found = !!document.querySelector(selector);
                break;
              case 'element_visible':
                const el = document.querySelector(selector);
                if (el) {
                  const rect = el.getBoundingClientRect();
                  found = rect.width > 0 && rect.height > 0;
                }
                break;
              case 'url_contains':
                found = window.location.href.includes(selector);
                break;
              case 'url_changed':
                found = window.location.href !== selector;
                break;
            }
            
            if (found) {
              resolve({ found: true, waitedMs: elapsed });
              return true;
            }
            
            if (elapsed >= timeoutMs) {
              resolve({ found: false, waitedMs: elapsed, timeout: true });
              return true;
            }
            
            return false;
          };
          
          if (checkCondition()) return;
          
          const interval = setInterval(() => {
            if (checkCondition()) {
              clearInterval(interval);
            }
          }, 50);
        });
      },
      args: [condition, selector, timeoutMs]
    });
    
    const result = results[0]?.result;
    if (result) {
      logWithTimestamp('info', `⏱️ waitForCondition: ${result.found ? 'Found' : 'Timeout'} after ${result.waitedMs}ms`);
      return { success: true, ...result };
    }
    
    return { success: false, error: 'No result from script' };
  } catch (e) {
    logWithTimestamp('warn', `⏱️ waitForCondition error: ${e.message}`);
    return { success: false, error: e.message };
  }
}

async function executeJavaScript(tabId, code) {
  try {
    // Validate tabId
    if (!tabId || typeof tabId !== 'number') {
      return { success: false, error: 'Invalid tab ID' };
    }
    
    // Check if tab exists and is scriptable
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (tabError) {
      return { success: false, error: `Tab not found: ${tabError.message}` };
    }
    
    // Check for restricted URLs
    const url = tab.url || '';
    if (url.startsWith('chrome://') || 
        url.startsWith('chrome-extension://') || 
        url.startsWith('edge://') ||
        url.startsWith('about:') ||
        url.startsWith('moz-extension://') ||
        url === '' || 
        url === 'about:blank') {
      return { 
        success: false, 
        error: `Cannot execute JavaScript on restricted page: ${url.substring(0, 50)}` 
      };
    }
    
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (code) => {
        try {
          const result = eval(code);
          return { success: true, result: result };
        } catch (error) {
          return { success: false, error: error.message || 'Script execution error' };
        }
      },
      args: [code]
    });
    
    // Validate results - NULL SAFETY
    if (!results || !Array.isArray(results) || results.length === 0 || !results[0]) {
      return { success: false, error: 'No result from script execution' };
    }
    
    const result = results[0].result;
    if (result === undefined || result === null) {
      return { success: false, error: 'Empty result from script execution' };
    }
    
    return result;
  } catch (error) {
    logWithTimestamp('error', 'executeJavaScript failed:', { tabId, error: error.message });
    return { 
      success: false, 
      error: error.message || 'Failed to execute JavaScript'
    };
  }
}

// BrowserOS-style: Clean extracted content to remove navigation/fluff
// Filters out common UI elements while preserving meaningful article content
// Works for any webpage, with site-specific optimizations
function cleanExtractedContent(text, url) {
  if (!text || typeof text !== 'string') return text;
  
  // ═══════════════════════════════════════════════════════════════════
  // TOKEN REDUCTION: Strip unicode spam first
  // Gmail and many sites inject zero-width characters that LLMs tokenize
  // ═══════════════════════════════════════════════════════════════════
  text = text.replace(/[\u200b\u200c\u200d\u200e\u200f\u034f\ufeff\u00a0]+/g, ' ');
  
  // Site-specific detection
  const isWikipedia = url && url.includes('wikipedia.org');
  const isGmail = url && url.includes('mail.google.com');
  const isNewsSite = url && (url.includes('news') || url.includes('article') || url.includes('blog'));
  
  // Common navigation patterns to remove (works for any website)
  const navigationPatterns = [
    // Universal navigation elements
    /Jump to content/gi,
    /Skip to (main )?content/gi,
    /Skip navigation/gi,
    /Main menu/gi,
    /Navigation menu/gi,
    /move to sidebar/gi,
    /hide Navigation/gi,
    /Show Navigation/gi,
    /Toggle navigation/gi,
    /Search Search/gi,
    /Search\.\.\./gi,
    /Donate/gi,
    /Create account/gi,
    /Sign up/gi,
    /Sign in/gi,
    /Log in/gi,
    /Log out/gi,
    /Login/gi,
    /Logout/gi,
    /Register/gi,
    /Subscribe/gi,
    /Personal tools/gi,
    /User menu/gi,
    /Account menu/gi,
    /Profile/gi,
    /Settings/gi,
    /Preferences/gi,
    /Appearance/gi,
    /Theme/gi,
    /Dark mode/gi,
    /Light mode/gi,
    /Color.*beta/gi,
    /Mobile view/gi,
    /Desktop view/gi,
    /Print\/export/gi,
    /Print this page/gi,
    /Download as PDF/gi,
    /Printable version/gi,
    /Share this page/gi,
    /Share on/gi,
    /Follow us on/gi,
    /Social media/gi,
    /Related articles/gi,
    /Related content/gi,
    /You may also like/gi,
    /Recommended for you/gi,
    /Trending now/gi,
    /Popular articles/gi,
    /Most read/gi,
    /Most viewed/gi,
    /Newsletter/gi,
    /Subscribe to newsletter/gi,
    /Email newsletter/gi,
    /Cookie consent/gi,
    /Cookie policy/gi,
    /Accept (all )?cookies/gi,
    /Reject (all )?cookies/gi,
    /Manage cookies/gi,
    /Cookie settings/gi,
    /Privacy policy/gi,
    /Terms of (service|use)/gi,
    /Terms and conditions/gi,
    /Legal/gi,
    /Disclaimer/gi,
    /Disclaimers/gi,
    /About us/gi,
    /About this site/gi,
    /Contact us/gi,
    /Contact/gi,
    /Help/gi,
    /Support/gi,
    /FAQ/gi,
    /Frequently asked questions/gi,
    /Feedback/gi,
    /Report (an )?issue/gi,
    /Report a problem/gi,
    /Copyright/gi,
    /All rights reserved/gi,
    /© \d{4}/gi,
    /Last updated/gi,
    /Last modified/gi,
    /Page last updated/gi,
    /This page was last/gi,
    /Published on/gi,
    /Updated on/gi,
    /Back to top/gi,
    /Scroll to top/gi,
    /Return to top/gi,
    /Footer/gi,
    /Header/gi,
    /Sidebar/gi,
    /Advertisement/gi,
    /Advertisements/gi,
    /Sponsored content/gi,
    /Sponsored/gi,
    /Promoted/gi,
    /Advertisement/gi,
    /Ad\s*$/gi,
    // Common footer patterns
    /^[\s]*Home[\s]*$/gim,
    /^[\s]*About[\s]*$/gim,
    /^[\s]*Contact[\s]*$/gim,
    /^[\s]*Privacy[\s]*$/gim,
    /^[\s]*Terms[\s]*$/gim,
    /^[\s]*Legal[\s]*$/gim,
    /^[\s]*Sitemap[\s]*$/gim,
    // Common UI button/link text
    /^[\s]*Skip to[\s]*$/gim,
    /^[\s]*Menu[\s]*$/gim,
    /^[\s]*Close[\s]*$/gim,
    /^[\s]*Open[\s]*$/gim,
    /^[\s]*More[\s]*$/gim,
    /^[\s]*Less[\s]*$/gim,
    /^[\s]*Show more[\s]*$/gim,
    /^[\s]*Show less[\s]*$/gim,
    /^[\s]*Read more[\s]*$/gim,
    /^[\s]*Read less[\s]*$/gim,
    /^[\s]*Load more[\s]*$/gim,
    /^[\s]*See more[\s]*$/gim,
    /^[\s]*See all[\s]*$/gim,
    /^[\s]*View all[\s]*$/gim,
    /^[\s]*Next[\s]*$/gim,
    /^[\s]*Previous[\s]*$/gim,
    /^[\s]*Back[\s]*$/gim,
    /^[\s]*Forward[\s]*$/gim,
    /^[\s]*Cookie[\s]*$/gim,
    /^[\s]*Accept[\s]*$/gim,
    /^[\s]*Decline[\s]*$/gim,
    /^[\s]*Got it[\s]*$/gim,
    /^[\s]*OK[\s]*$/gim,
    /^[\s]*Yes[\s]*$/gim,
    /^[\s]*No[\s]*$/gim,
    // Wikipedia-specific (only applied if Wikipedia)
    ...(isWikipedia ? [
      /Main pageContents/gi,
      /Current events/gi,
      /Random article/gi,
      /About Wikipedia/gi,
      /Contribute/gi,
      /HelpLearn to edit/gi,
      /Community portal/gi,
      /Recent changes/gi,
      /Upload file/gi,
      /Special pages/gi,
      /Contents move to sidebar/gi,
      /Toggle.*subsection/gi,
      /Edit links/gi,
      /ArticleTalk/gi,
      /ReadView source/gi,
      /View history/gi,
      /Tools Tools/gi,
      /Actions Read/gi,
      /What links here/gi,
      /Related changes/gi,
      /Permanent link/gi,
      /Page information/gi,
      /Cite this page/gi,
      /Get shortened URL/gi,
      /Download QR code/gi,
      /Expand all/gi,
      /Edit interlanguage links/gi,
      /In other projects/gi,
      /Wikimedia Commons/gi,
      /Wikinews/gi,
      /Wikiquote/gi,
      /Wikiversity/gi,
      /Wikivoyage/gi,
      /Wikidata item/gi,
      /This page always uses/gi,
      /small font size/gi,
      /WidthStandard/gi,
      /WideThe content is as wide/gi,
      /From Wikipedia, the free encyclopedia/gi,
      /Text is available under/gi,
      /Creative Commons Attribution/gi,
      /ShareAlike.*License/gi,
      /Wikipedia® is a registered trademark/gi,
      /Wikimedia Foundation/gi,
      /This page was last edited on/gi,
      /Contact Wikipedia/gi,
      /Code of Conduct/gi,
      /Developers/gi,
      /Statistics/gi,
      /Cookie statement/gi,
      /Edit preview settings/gi,
      /Powered by MediaWiki/gi,
      /^\s*\d+\s+languages\s*$/gim,
    ] : []),
  ];
  
  // Remove navigation patterns
  let cleaned = text;
  for (const pattern of navigationPatterns) {
    cleaned = cleaned.replace(pattern, '');
  }
  
  // Remove lines that are mostly navigation
  const lines = cleaned.split('\n');
  const cleanedLines = lines.filter(line => {
    const trimmed = line.trim();
    
    // Skip very short lines
    if (trimmed.length < 3) return false;
    
    // Skip lines that are mostly symbols or numbers
    if (/^[\d\s\-\(\)\.]+$/.test(trimmed)) return false;
    if (/^[^\w\s]+$/.test(trimmed)) return false;
    
    // Skip common UI words/phrases (universal)
    const uiWords = [
      'skip', 'next', 'previous', 'menu', 'close', 'open', 'more', 'less',
      'cookie', 'privacy', 'terms', 'accept', 'decline', 'search', 'donate',
      'subscribe', 'sign up', 'sign in', 'log in', 'log out', 'register',
      'home', 'about', 'contact', 'help', 'support', 'faq', 'feedback',
      'back to top', 'scroll to top', 'return to top', 'back', 'forward',
      'show more', 'show less', 'read more', 'read less', 'load more',
      'see more', 'see all', 'view all', 'got it', 'ok', 'yes', 'no',
      'follow', 'share', 'like', 'comment', 'subscribe', 'newsletter',
      'advertisement', 'ad', 'sponsored', 'promoted', 'trending', 'popular'
    ];
    const lowerTrimmed = trimmed.toLowerCase();
    if (uiWords.some(word => {
      const wordPattern = new RegExp(`^${word.replace(/\s+/g, '\\s+')}(\\s|$|:|\\.)`, 'i');
      return wordPattern.test(lowerTrimmed) || lowerTrimmed === word;
    })) {
      return false;
    }
    
    // Skip lines that are just navigation links (common patterns)
    if (/^(Home|About|Contact|Privacy|Terms|Legal|Sitemap|Help|Support|FAQ)$/i.test(trimmed)) {
      return false;
    }
    
    // For Wikipedia: Skip language link lines (usually single words in foreign scripts)
    if (isWikipedia) {
      // Skip lines that look like language names (very short, no spaces, foreign characters)
      if (trimmed.length < 20 && !trimmed.includes(' ') && /[^\x00-\x7F]/.test(trimmed)) {
        return false;
      }
    }
    
    // Skip lines that are just social media links or share buttons
    if (/^(Facebook|Twitter|LinkedIn|Instagram|YouTube|TikTok|Reddit|Pinterest|Share on)/i.test(trimmed)) {
      return false;
    }
    
    // Skip lines that are just dates/timestamps without context
    if (/^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}$/.test(trimmed) || 
        /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(trimmed) ||
        /^\d{1,2}:\d{2}(:\d{2})?( AM| PM)?$/.test(trimmed)) {
      return false;
    }
    
    return true;
  });
  
  cleaned = cleanedLines.join('\n');
  
  // Remove excessive whitespace
  cleaned = cleaned
    .replace(/\n{3,}/g, '\n\n')  // Max 2 consecutive newlines
    .replace(/[ \t]{2,}/g, ' ')  // Multiple spaces to single space
    .trim();
  
  // Remove duplicate consecutive lines
  const finalLines = [];
  let lastLine = '';
  for (const line of cleaned.split('\n')) {
    const trimmed = line.trim();
    if (trimmed && trimmed !== lastLine) {
      finalLines.push(trimmed);
      lastLine = trimmed;
    }
  }
  
  return finalLines.join('\n');
}

async function getPageContent(tabId) {
  // CRITICAL: Validate tab exists before executing
  try {
    if (!tabId || tabId === undefined) {
      // No tabId provided - get active tab
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return {
          success: false,
          error: `No active tab found. Please navigate to a page first using navigate_browser.`
        };
      }
      tabId = activeTab.id;
      logWithTimestamp('info', '📋 Using active tab for get_page_content', {
        tabId: tabId,
        url: activeTab.url
      });
    } else {
      // Validate tab exists
      try {
        const tab = await chrome.tabs.get(tabId);
        if (!tab) {
          return {
            success: false,
            error: `Tab ${tabId} does not exist. Please navigate to a page first using navigate_browser.`
          };
        }
      } catch (e) {
        return {
          success: false,
          error: `Tab ${tabId} does not exist or is invalid: ${e.message}. Please navigate to a page first using navigate_browser.`
        };
      }
    }
  } catch (e) {
    logWithTimestamp('error', '❌ Error validating tab for get_page_content', {
      tabId: tabId,
      error: e.message
    });
    return {
      success: false,
      error: `Failed to validate tab: ${e.message}. Please navigate to a page first using navigate_browser.`
    };
  }
  
  // BrowserOS-inspired content extraction: Multi-strategy approach
  // 1. Try Readability for article content
  // 2. Use intelligent DOM traversal (accessibility-tree-like) for better extraction
  // 3. Fallback to full HTML with chunking for complex pages
  try {
    // First, inject Readability.js into the page
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['Readability.js']
    });
    
    // Wait a bit for dynamic content to load (BrowserOS-style: ensure content is ready)
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Then execute the improved extraction logic
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        // BrowserOS-inspired: Intelligent content extraction function
        function extractContentIntelligently() {
          const content = {
            text: '',
            html: '',
            links: [],
            images: [],
            headings: [],
            metadata: {}
          };
          
          // Helper to check if element is visible
          function isVisible(element) {
            if (!element) return false;
            const style = window.getComputedStyle(element);
            if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
              return false;
            }
            const rect = element.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
          }
          
          // Helper to extract text from element (BrowserOS-style)
          function extractTextFromElement(element) {
            if (!element || !isVisible(element)) return '';
            
            // Skip script and style tags
            if (element.tagName === 'SCRIPT' || element.tagName === 'STYLE' || 
                element.tagName === 'NOSCRIPT' || element.tagName === 'META') {
              return '';
            }
            
            // Get text content
            let text = '';
            
            // For input elements, get value or placeholder
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
              text = element.value || element.placeholder || '';
              if (element.type === 'button' || element.type === 'submit') {
                text = element.value || element.getAttribute('aria-label') || element.title || '';
              }
            }
            // For images, get alt text
            else if (element.tagName === 'IMG') {
              text = element.alt || element.title || '';
            }
            // For links, get link text
            else if (element.tagName === 'A') {
              text = element.textContent?.trim() || element.getAttribute('aria-label') || '';
            }
            // For other elements, get text content but filter out noise
            else {
              // Clone to avoid modifying original
              const clone = element.cloneNode(true);
              // Remove script, style, and other non-content elements
              clone.querySelectorAll('script, style, noscript, iframe, embed, object').forEach(el => el.remove());
              text = clone.textContent?.trim() || '';
            }
            
            return text;
          }
          
          // BrowserOS-style: Traverse DOM intelligently
          function traverseDOM(node, depth = 0) {
            if (depth > 50) return; // Prevent infinite recursion
            
            if (!node || node.nodeType === Node.COMMENT_NODE) return;
            
            // Process text nodes
            if (node.nodeType === Node.TEXT_NODE) {
              const text = node.textContent?.trim();
              if (text && text.length > 0) {
                content.text += text + ' ';
              }
              return;
            }
            
            // Skip invisible elements
            if (node.nodeType === Node.ELEMENT_NODE && !isVisible(node)) {
              return;
            }
            
            // Extract content based on element type
            if (node.nodeType === Node.ELEMENT_NODE) {
              const tagName = node.tagName?.toLowerCase();
              
              // Extract headings
              if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tagName)) {
                const headingText = extractTextFromElement(node);
                if (headingText) {
                  content.headings.push({ level: parseInt(tagName[1]), text: headingText });
                  content.text += '\n' + headingText + '\n';
                }
              }
              // Extract links
              else if (tagName === 'a' && node.href) {
                const linkText = extractTextFromElement(node);
                if (linkText || node.href) {
                  content.links.push({
                    text: linkText,
                    url: node.href,
                    title: node.title || ''
                  });
                  if (linkText) {
                    content.text += linkText + ' ';
                  }
                }
              }
              // Extract images
              else if (tagName === 'img' && node.src) {
                const altText = node.alt || node.title || '';
                content.images.push({
                  src: node.src,
                  alt: altText,
                  title: node.title || ''
                });
                if (altText) {
                  content.text += altText + ' ';
                }
              }
              // Extract text from other elements
              else {
                const elementText = extractTextFromElement(node);
                if (elementText && elementText.length > 10) { // Only meaningful text
                  content.text += elementText + ' ';
                }
              }
            }
            
            // Process children (including shadow DOM)
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Check for shadow DOM
              if (node.shadowRoot) {
                traverseDOM(node.shadowRoot, depth + 1);
              }
              
              // Process regular children
              for (const child of Array.from(node.childNodes)) {
                traverseDOM(child, depth + 1);
              }
            }
          }
          
          // Start traversal from body
          if (document.body) {
            traverseDOM(document.body);
          }
          
          // Also extract from iframes (BrowserOS-style: comprehensive extraction)
          try {
            const iframes = document.querySelectorAll('iframe');
            for (const iframe of iframes) {
              try {
                // Try to access iframe content (may fail due to CORS)
                const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                if (iframeDoc && iframeDoc.body) {
                  const iframeText = extractTextFromElement(iframeDoc.body);
                  if (iframeText && iframeText.length > 50) {
                    content.text += '\n[Iframe Content]\n' + iframeText + '\n';
                  }
                }
              } catch (e) {
                // CORS or other security restriction - skip this iframe
                // Add iframe src as fallback
                if (iframe.src) {
                  content.text += `\n[Iframe: ${iframe.src}]\n`;
                }
              }
            }
          } catch (e) {
            // Ignore iframe extraction errors
          }
          
          // Clean up text (BrowserOS-style: intelligent filtering)
          // ═══════════════════════════════════════════════════════════════════
          // TOKEN REDUCTION: Strip unicode spam that inflates token count
          // Gmail and many sites inject zero-width characters that LLMs tokenize
          // These patterns match: \u200c \u200b \u034f \ufeff \u00a0 etc.
          // ═══════════════════════════════════════════════════════════════════
          content.text = content.text
            .replace(/[\u200b\u200c\u200d\u200e\u200f\u034f\ufeff\u00a0]+/g, ' ')  // Zero-width chars → space
            .replace(/\s+/g, ' ') // Normalize whitespace
            .replace(/\n\s*\n/g, '\n') // Remove empty lines
            .replace(/[ \t]+/g, ' ') // Remove excessive spaces/tabs
            .split('\n')
            .map(line => line.trim())
            .filter(line => {
              // Filter out noise: very short lines, common UI elements, etc.
              if (line.length < 3) return false;
              // Filter common UI noise
              const noisePatterns = [
                /^(skip|next|previous|menu|close|open|more|less)$/i,
                /^(cookie|privacy|terms|accept|decline)$/i,
                /^[\d\s\-\(\)]+$/, // Only numbers/punctuation
                /^[^\w\s]+$/, // Only symbols
              ];
              return !noisePatterns.some(pattern => pattern.test(line));
            })
            .join('\n')
            .trim();
          
          // Remove duplicate consecutive lines
          const lines = content.text.split('\n');
          const deduplicatedLines = [];
          let lastLine = '';
          for (const line of lines) {
            if (line !== lastLine) {
              deduplicatedLines.push(line);
              lastLine = line;
            }
          }
          content.text = deduplicatedLines.join('\n').trim();
          
          // Extract metadata
          content.metadata = {
            title: document.title || '',
            description: document.querySelector('meta[name="description"]')?.content || '',
            keywords: document.querySelector('meta[name="keywords"]')?.content || '',
            ogTitle: document.querySelector('meta[property="og:title"]')?.content || '',
            ogDescription: document.querySelector('meta[property="og:description"]')?.content || ''
          };
          
          return content;
        }
        
        // BrowserOS-style: Try Readability first for clean article extraction
        let readabilityResult = null;
        try {
          if (typeof Readability !== 'undefined') {
            const documentClone = document.cloneNode(true);
            const reader = new Readability(documentClone);
            const article = reader.parse();
            
            if (article && article.content && article.textContent && article.textContent.length > 500) {
              readabilityResult = {
                success: true,
                title: article.title || document.title,
                content: article.content,
                textContent: article.textContent,
                excerpt: article.excerpt,
                byline: article.byline,
                siteName: article.siteName,
                length: article.length,
                url: window.location.href
              };
            }
          }
        } catch (e) {
          console.log('Readability extraction failed:', e.message);
        }
        
        // Always extract intelligent content (BrowserOS-style)
        const intelligentContent = extractContentIntelligently();
        
        // Get full HTML as fallback
        const fullHTML = document.documentElement.outerHTML;
        const fullText = document.body?.innerText || intelligentContent.text;
        const htmlSize = new Blob([fullHTML]).size;
        const textSize = new Blob([fullText]).size;
        
        return {
          readability: readabilityResult,
          intelligentContent: intelligentContent,
          fullHTML: fullHTML,
          fullText: fullText,
          htmlSize: htmlSize,
          textSize: textSize,
          url: window.location.href,
          title: document.title
        };
      }
    });
    
    // NULL SAFETY: Handle script execution failures
    if (!results || !results[0] || results[0].result === undefined) {
      return { success: false, error: 'Script execution failed - could not extract page content' };
    }
    const result = results[0].result;
    if (!result) {
      return { success: false, error: 'Empty result from content extraction' };
    }
    
    // BrowserOS-style: Multi-strategy content selection
    // Priority: Readability > Intelligent Extraction > Full HTML
    const htmlSize = result.htmlSize || 0;
    const chunkSize = 500 * 1024; // 500KB threshold
    const intelligentContent = result.intelligentContent || {};
    
    // Strategy 1: Use Readability if available and good quality
    if (result.readability && result.readability.success && htmlSize <= chunkSize) {
      // BrowserOS-style: Clean Readability content too (removes any remaining navigation)
      let cleanedReadabilityText = cleanExtractedContent(result.readability.textContent, result.readability.url);
      
      logWithTimestamp('info', '✅ Using Readability-extracted content (BrowserOS-style)', {
        tabId: tabId,
        title: result.readability.title,
        contentLength: result.readability.length,
        contentSizeKB: Math.round(result.readability.content.length / 1024),
        fullHtmlSizeKB: Math.round(htmlSize / 1024),
        cleanedTextSize: cleanedReadabilityText.length,
        originalTextSize: result.readability.textContent.length,
        note: 'Clean article content extracted and cleaned'
      });
      
      return {
        success: true,
        readability: true,
        html: result.readability.content,
        text: cleanedReadabilityText, // Cleaned text
        url: result.readability.url,
        title: result.readability.title,
        excerpt: result.readability.excerpt,
        byline: result.readability.byline,
        siteName: result.readability.siteName,
        htmlSize: result.readability.content.length,
        textSize: cleanedReadabilityText.length, // Updated size after cleaning
        extractionMethod: 'readability'
      };
    }
    
    // Strategy 2: Use intelligent extraction if it produced good content
    let intelligentText = intelligentContent.text || '';
    const intelligentTextSize = intelligentText.length;
    const hasGoodIntelligentContent = intelligentTextSize > 500 && 
                                      intelligentTextSize < htmlSize * 0.8; // At least 20% smaller than full HTML
    
    if (hasGoodIntelligentContent && htmlSize <= chunkSize) {
      // BrowserOS-style: Clean intelligent extraction content too
      intelligentText = cleanExtractedContent(intelligentText, result.url);
      
      logWithTimestamp('info', '✅ Using intelligent content extraction (BrowserOS-style)', {
        tabId: tabId,
        textSize: intelligentText.length,
        originalTextSize: intelligentTextSize,
        linksFound: intelligentContent.links?.length || 0,
        imagesFound: intelligentContent.images?.length || 0,
        headingsFound: intelligentContent.headings?.length || 0,
        htmlSizeKB: Math.round(htmlSize / 1024),
        note: 'Intelligent DOM traversal extracted clean content and cleaned'
      });
      
      // Build HTML from intelligent content
      let intelligentHTML = '';
      if (intelligentContent.headings && intelligentContent.headings.length > 0) {
        intelligentHTML += '<div class="headings">';
        intelligentContent.headings.forEach(h => {
          intelligentHTML += `<h${h.level}>${h.text}</h${h.level}>`;
        });
        intelligentHTML += '</div>';
      }
      intelligentHTML += `<div class="content">${intelligentText}</div>`;
      
      return {
        success: true,
        readability: false,
        intelligentExtraction: true,
        html: intelligentHTML,
        text: intelligentText, // Cleaned text
        links: intelligentContent.links || [],
        images: intelligentContent.images || [],
        headings: intelligentContent.headings || [],
        metadata: intelligentContent.metadata || {},
        url: result.url,
        title: result.title || intelligentContent.metadata?.title || '',
        htmlSize: intelligentHTML.length,
        textSize: intelligentText.length, // Updated size after cleaning
        extractionMethod: 'intelligent'
      };
    }
    
    // Strategy 3: Fallback to full HTML (with intelligent text as bonus)
    const reason = htmlSize > chunkSize 
      ? 'Full HTML is very large - using full HTML with chunking to preserve complete context'
      : intelligentTextSize > 0
        ? 'Using full HTML with intelligent extraction as fallback text'
        : 'Readability unavailable and intelligent extraction insufficient - using full HTML';
    
    logWithTimestamp('info', '📄 Using full HTML extraction', {
      tabId: tabId,
      htmlSize: htmlSize,
      htmlSizeMB: (htmlSize / (1024 * 1024)).toFixed(2),
      intelligentTextSize: intelligentTextSize,
      readabilitySucceeded: result.readability && result.readability.success,
      reason: reason,
      note: 'Will chunk if > 500KB'
    });
    
    // If HTML is large, chunk it for reliable transfer
    if (htmlSize > chunkSize) {
      logWithTimestamp('info', '📦 Page content is large - chunking for reliable transfer', {
        tabId: tabId,
        htmlSize: htmlSize,
        chunkSize: chunkSize,
        estimatedChunks: Math.ceil(htmlSize / chunkSize),
        note: 'Full context preserved via chunking'
      });
      
      // Chunk the HTML
      const htmlChunks = [];
      const html = result.fullHTML;
      for (let i = 0; i < html.length; i += chunkSize) {
        htmlChunks.push(html.slice(i, i + chunkSize));
      }
      
      // Use intelligent text if available, otherwise use full text
      let textToChunk = intelligentTextSize > 500 ? intelligentText : result.fullText;
      
      // BrowserOS-style: Clean content to remove navigation/fluff
      // This filters out common navigation elements while preserving article content
      textToChunk = cleanExtractedContent(textToChunk, result.url);
      
      const textChunks = [];
      const textChunkSize = 500 * 1024; // 500KB text chunks
      if (textToChunk.length > textChunkSize) {
        for (let i = 0; i < textToChunk.length; i += textChunkSize) {
          textChunks.push(textToChunk.slice(i, i + textChunkSize));
        }
      } else {
        textChunks.push(textToChunk);
      }
      
      return {
        success: true,
        chunked: true,
        readability: false,
        intelligentExtraction: intelligentTextSize > 500,
        htmlChunks: htmlChunks,
        textChunks: textChunks,
        htmlSize: htmlSize,
        textSize: textToChunk.length, // Updated after cleaning
        url: result.url,
        title: result.title,
        totalChunks: htmlChunks.length,
        textChunkCount: textChunks.length,
        links: intelligentContent.links || [],
        images: intelligentContent.images || [],
        headings: intelligentContent.headings || [],
        extractionMethod: 'full_html_chunked'
      };
    } else {
      // Small enough to send in one message
      // Prefer intelligent text if available and good
      let finalText = intelligentTextSize > 500 ? intelligentText : result.fullText;
      
      // BrowserOS-style: Clean content to remove navigation/fluff
      finalText = cleanExtractedContent(finalText, result.url);
      
      return {
        success: true,
        chunked: false,
        readability: false,
        intelligentExtraction: intelligentTextSize > 500,
        html: result.fullHTML,
        text: finalText,
        url: result.url,
        title: result.title,
        htmlSize: htmlSize,
        textSize: finalText.length, // Updated after cleaning
        links: intelligentContent.links || [],
        images: intelligentContent.images || [],
        headings: intelligentContent.headings || [],
        metadata: intelligentContent.metadata || {},
        extractionMethod: 'full_html'
      };
    }
  } catch (error) {
    logWithTimestamp('error', '❌ Error executing getPageContent script', {
      tabId: tabId,
      error: error.message,
      errorStack: error.stack
    });
    return {
      success: false,
      error: `Failed to get page content: ${error.message}`
    };
  }
}

// Node ID mapping for BrowserOS-style node-based interactions
let nodeIdMappings = new Map(); // tabId -> Map<nodeId, elementInfo>

async function getAccessibilityTree(tabId) {
  // Get full accessibility tree using Chrome's accessibility API
  // BrowserOS-style: Full AX tree with all properties
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      // Build comprehensive accessibility tree
      function buildAXTree(node, id = 0, parentId = null) {
        const nodeId = id++;
        const tree = {
          id: nodeId,
          role: node.tagName?.toLowerCase() || node.role || 'generic',
          name: node.getAttribute('aria-label') || 
                node.getAttribute('title') || 
                node.textContent?.trim().substring(0, 100) || '',
          value: node.value || node.textContent?.trim().substring(0, 100) || '',
          parentId: parentId,
          attributes: {},
          children: []
        };
        
        // Get all attributes
        if (node.id) tree.attributes.id = node.id;
        if (node.className) tree.attributes.class = node.className;
        if (node.type) tree.attributes.type = node.type;
        if (node.name) tree.attributes.name = node.name;
        if (node.href) tree.attributes.href = node.href;
        if (node.src) tree.attributes.src = node.src;
        
        // Get bounds
        const rect = node.getBoundingClientRect();
        tree.bounds = {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        };
        
        // Get states
        tree.states = [];
        if (node.disabled) tree.states.push('disabled');
        if (node.checked !== undefined) tree.states.push('checked');
        if (node.selected) tree.states.push('selected');
        if (node.hidden || node.style.display === 'none') tree.states.push('hidden');
        
        // Get actions
        tree.actions = [];
        if (node.onclick || node.getAttribute('onclick')) tree.actions.push('click');
        if (node.tagName === 'INPUT' || node.tagName === 'TEXTAREA') tree.actions.push('type');
        if (node.tagName === 'A' || node.href) tree.actions.push('navigate');
        
        // Process children
        for (const child of Array.from(node.children || [])) {
          const [childTree, newId] = buildAXTree(child, id, nodeId);
          tree.children.push(childTree);
          id = newId;
        }
        
        return [tree, id];
      }
      
      const [tree] = buildAXTree(document.body);
      return {
        rootId: tree.id,
        nodes: flattenTree(tree),
        treeData: {
          url: window.location.href,
          title: document.title,
          loaded: document.readyState === 'complete'
        }
      };
      
      function flattenTree(node, nodes = {}) {
        nodes[node.id] = {
          id: node.id,
          role: node.role,
          name: node.name,
          value: node.value,
          parentId: node.parentId,
          attributes: node.attributes,
          bounds: node.bounds,
          states: node.states,
          actions: node.actions,
          childIds: node.children.map(c => c.id)
        };
        
        for (const child of node.children) {
          flattenTree(child, nodes);
        }
        
        return nodes;
      }
    }
  });
  return results[0].result;
}

async function getInteractiveSnapshot(tabId) {
  // CRITICAL: Validate tab exists before executing
  try {
    if (!tabId || tabId === undefined) {
      // No tabId provided - get active tab
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return {
          success: false,
          error: `No active tab found. Please navigate to a page first using navigate_browser.`
        };
      }
      tabId = activeTab.id;
      logWithTimestamp('info', '📋 Using active tab for get_interactive_snapshot', {
        tabId: tabId,
        url: activeTab.url
      });
    } else {
      // Validate tab exists
      try {
        const tab = await chrome.tabs.get(tabId);
        if (!tab) {
          return {
            success: false,
            error: `Tab ${tabId} does not exist. Please navigate to a page first using navigate_browser.`
          };
        }
      } catch (e) {
        return {
          success: false,
          error: `Tab ${tabId} does not exist or is invalid: ${e.message}. Please navigate to a page first using navigate_browser.`
        };
      }
    }
  } catch (e) {
    logWithTimestamp('error', '❌ Error validating tab for get_interactive_snapshot', {
      tabId: tabId,
      error: e.message
    });
    return {
      success: false,
      error: `Failed to validate tab: ${e.message}. Please navigate to a page first using navigate_browser.`
    };
  }
  
  // Check for restricted URLs (chrome://, chrome-extension://, etc.)
  // Chrome security prevents script injection on these pages
  try {
    const tab = await chrome.tabs.get(tabId);
    const url = tab.url || '';
    
    if (url.startsWith('chrome://') || 
        url.startsWith('chrome-extension://') ||
        url.startsWith('edge://') ||
        url.startsWith('about:') ||
        url.startsWith('devtools://') ||
        url === '' || 
        url === 'about:blank') {
      
      logWithTimestamp('warn', '⚠️ Cannot access restricted page for interactive snapshot', {
        tabId: tabId,
        url: url
      });
      
      return {
        success: false,
        error: `Cannot get interactive elements on "${url}". This is a protected browser page. Chrome security prevents script access to chrome:// and other internal pages.`,
        restrictedPage: true,
        suggestion: 'Use navigate_browser to go to a website (http:// or https://) first.',
        // Return empty snapshot structure so callers don't break
        snapshotId: Date.now(),
        timestamp: Date.now(),
        interactiveNodes: [],
        metadata: {
          totalProcessed: 0,
          filteredCount: 0,
          url: url,
          restrictedPage: true
        }
      };
    }
  } catch (e) {
    // Tab might have been closed
    logWithTimestamp('error', '❌ Failed to check tab URL', { error: e.message });
  }
  
  // BrowserOS-style interactive snapshot: Processed AX tree with interactive nodes
  const axTree = await getAccessibilityTree(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (viewportExpansion = 0) => {
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS-STYLE DOM EXTRACTION WITH FULL OPTIMIZATIONS
      // Based on BrowserOS buildDomTree.js - identical filtering techniques
      // Key optimizations: WeakMap caching, early pruning, top element detection
      // ═══════════════════════════════════════════════════════════════════════════
      
      // Get all interactive elements with DEEP DOM TRAVERSAL
      const interactiveElements = [];
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS OPTIMIZATION 1: WeakMap Caching
      // Cache getBoundingClientRect() and getComputedStyle() results
      // Eliminates redundant DOM queries - HUGE performance gain
      // ═══════════════════════════════════════════════════════════════════════════
      const rectCache = new WeakMap();
      const styleCache = new WeakMap();
      
      function getCachedRect(element) {
        if (!element) return null;
        if (rectCache.has(element)) return rectCache.get(element);
        const rect = element.getBoundingClientRect();
        rectCache.set(element, rect);
        return rect;
      }
      
      function getCachedStyle(element) {
        if (!element) return null;
        if (styleCache.has(element)) return styleCache.get(element);
        const style = window.getComputedStyle(element);
        styleCache.set(element, style);
        return style;
      }
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS OPTIMIZATION 2: Early Tag Pruning
      // Skip non-interactive tags BEFORE any processing
      // Reduces iteration count significantly
      // ═══════════════════════════════════════════════════════════════════════════
      const SKIP_TAGS = new Set([
        'SVG', 'SCRIPT', 'STYLE', 'LINK', 'META', 'NOSCRIPT', 'TEMPLATE',
        'HEAD', 'BR', 'HR', 'WBR', 'COL', 'COLGROUP', 'BASE', 'EMBED',
        'PARAM', 'SOURCE', 'TRACK', 'AREA', 'MAP'
      ]);
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS OPTIMIZATION 3: checkVisibility() API
      // Modern, single-call visibility check (faster than 3 separate checks)
      // ═══════════════════════════════════════════════════════════════════════════
      function isElementVisible(element) {
        if (!element) return false;
        
        // Try modern checkVisibility API first (fastest)
        try {
          if (typeof element.checkVisibility === 'function') {
            return element.checkVisibility({ 
              checkOpacity: true, 
              checkVisibilityCSS: true 
            });
          }
        } catch (e) {
          // Fallback for browsers without checkVisibility
        }
        
        // Fallback: Manual visibility checks
        const style = getCachedStyle(element);
        if (!style) return false;
        return style.display !== 'none' && 
               style.visibility !== 'hidden' && 
               parseFloat(style.opacity) !== 0;
      }
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS OPTIMIZATION 4: Top Element Detection (IMPROVED)
      // THE BIGGEST TOKEN SAVER - Filter occluded elements using elementFromPoint()
      // Eliminates hidden menus, dropdowns, overlapped elements
      //
      // IMPROVEMENTS over original:
      // 1. Multi-point sampling (corners + center) for better accuracy
      // 2. Transparent overlay detection (pointer-events: none, opacity < 0.1)
      // 3. Better shadow DOM boundary handling
      // 4. Small element protection (checkboxes, radio buttons)
      // ═══════════════════════════════════════════════════════════════════════════
      function isTopElement(element, rect, frameOffset = { x: 0, y: 0 }) {
        if (!element || !rect) return false;
        
        // Skip check for elements not in viewport expansion zone
        if (viewportExpansion === -1) return true; // -1 means skip top element check
        
        // IMPROVEMENT 1: Protect small interactive elements (checkboxes, radios, small buttons)
        // These are often occluded at center by labels but still clickable at edges
        const isSmallInteractive = rect.width <= 30 && rect.height <= 30 && (
          element.tagName === 'INPUT' && ['checkbox', 'radio', 'submit'].includes(element.type) ||
          element.tagName === 'BUTTON' ||
          element.getAttribute('role') === 'checkbox' ||
          element.getAttribute('role') === 'radio' ||
          element.getAttribute('role') === 'switch'
        );
        
        // Calculate sample points: center + 4 corners (inset by 2px)
        const inset = 2;
        const samplePoints = [
          { x: rect.left + rect.width / 2 + frameOffset.x, y: rect.top + rect.height / 2 + frameOffset.y }, // center
          { x: rect.left + inset + frameOffset.x, y: rect.top + inset + frameOffset.y }, // top-left
          { x: rect.right - inset + frameOffset.x, y: rect.top + inset + frameOffset.y }, // top-right
          { x: rect.left + inset + frameOffset.x, y: rect.bottom - inset + frameOffset.y }, // bottom-left
          { x: rect.right - inset + frameOffset.x, y: rect.bottom - inset + frameOffset.y } // bottom-right
        ];
        
        // For small elements, only check center to avoid edge detection issues
        const pointsToCheck = isSmallInteractive ? [samplePoints[0]] : samplePoints;
        
        // Helper: check if element at point is related to our element
        function checkPointForElement(x, y) {
          if (x < 0 || x > window.innerWidth || y < 0 || y > window.innerHeight) {
            return false; // Point outside viewport
          }
          
          try {
            // Handle shadow DOM - use shadowRoot's elementFromPoint if available
            const rootNode = element.getRootNode();
            let topEl;
            
            if (rootNode instanceof ShadowRoot) {
              topEl = rootNode.elementFromPoint(x, y);
            } else {
              topEl = document.elementFromPoint(x, y);
            }
            
            if (!topEl) return false;
            
            // IMPROVEMENT 2: Check if top element is a transparent overlay
            // These overlays visually block but shouldn't prevent clicking
            const topStyle = getCachedStyle(topEl);
            if (topStyle) {
              const isTransparent = 
                topStyle.pointerEvents === 'none' ||
                parseFloat(topStyle.opacity) < 0.1 ||
                (topStyle.backgroundColor === 'transparent' && topStyle.backgroundImage === 'none' && 
                 !topEl.textContent?.trim());
              
              if (isTransparent && topEl !== element) {
                // This is a transparent overlay - keep checking underneath
                // Try to get the element behind it by temporarily hiding
                return true; // Assume element is clickable through transparent overlay
              }
            }
            
            // Element is "top" if:
            // 1. It IS the element at this point
            // 2. It CONTAINS the element at this point (parent of what's clicked)
            // 3. The element at this point CONTAINS it (child elements are ok)
            // 4. They share a common interactive ancestor (labels wrapping inputs)
            if (topEl === element || element.contains(topEl) || topEl.contains(element)) {
              return true;
            }
            
            // IMPROVEMENT 3: Check for label-input relationships
            // Labels often cover inputs but clicking label triggers input
            if (topEl.tagName === 'LABEL') {
              const forAttr = topEl.getAttribute('for');
              if (forAttr && element.id === forAttr) return true;
              if (topEl.contains(element)) return true;
            }
            if (element.tagName === 'LABEL') {
              const forAttr = element.getAttribute('for');
              if (forAttr && topEl.id === forAttr) return true;
            }
            
            return false;
          } catch (e) {
            // If elementFromPoint fails, assume point is valid
            return true;
          }
        }
        
        // IMPROVEMENT 4: Multi-point sampling - element is top if ANY point passes
        // This handles cases where center is occluded but edges are accessible
        let passedPoints = 0;
        for (const point of pointsToCheck) {
          if (checkPointForElement(point.x, point.y)) {
            passedPoints++;
          }
        }
        
        // For small elements: need center to pass
        // For normal elements: need at least 1 point to pass (more lenient)
        if (isSmallInteractive) {
          return passedPoints > 0;
        }
        return passedPoints >= 1; // At least one point must be accessible
      }
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS OPTIMIZATION 5: Viewport Expansion
      // Include elements slightly outside viewport (about to scroll into view)
      // Configurable via viewportExpansion parameter
      // ═══════════════════════════════════════════════════════════════════════════
      function isInExpandedViewport(rect, frameOffset = { x: 0, y: 0 }) {
        if (!rect) return false;
        if (viewportExpansion === -1) return true; // -1 means include all
        
        const adjustedX = rect.x + frameOffset.x;
        const adjustedY = rect.y + frameOffset.y;
        const expansion = viewportExpansion || 0;
        
        return !(
          (adjustedY + rect.height) < -expansion ||
          adjustedY > window.innerHeight + expansion ||
          (adjustedX + rect.width) < -expansion ||
          adjustedX > window.innerWidth + expansion
        );
      }
      
      // BrowserOS-STYLE: GENERIC selectors for ALL interactive element types
      // NO SITE-SPECIFIC HARDCODING - uses only standard HTML/ARIA patterns
      // Categorized by BrowserOS node types: clickable, typeable, selectable
      const selectors = [
        // === STANDARD HTML FORM ELEMENTS ===
        'button', 'a[href]', 'input', 'textarea', 'select', 'option',
        
        // === ARIA ROLES - CLICKABLE ===
        '[role="button"]', '[role="link"]', '[role="menuitem"]',
        '[role="treeitem"]', '[role="gridcell"]',
        
        // === ARIA ROLES - TYPEABLE (text input) ===
        '[role="textbox"]', '[role="searchbox"]', '[role="spinbutton"]',
        '[role="combobox"][aria-autocomplete]', // Editable comboboxes
        
        // === ARIA ROLES - SELECTABLE ===
        '[role="combobox"]', '[role="listbox"]', '[role="option"]',
        '[role="menuitemcheckbox"]', '[role="menuitemradio"]',
        '[role="tab"]', '[role="checkbox"]', '[role="radio"]', '[role="switch"]',
        '[role="slider"]', '[role="treeitem"]',
        
        // === CONTENTEDITABLE - GENERIC (works for ANY rich text editor) ===
        '[contenteditable="true"]', '[contenteditable=""]',
        '[aria-multiline="true"]', // Multi-line text fields (standard ARIA)
        
        // === INTERACTIVE ATTRIBUTES - GENERIC ===
        '[onclick]', '[tabindex]:not([tabindex="-1"])',
        '[aria-haspopup]', // Elements that open menus/dialogs
        
        // === DOCUMENT EDITING MODE - GENERIC ===
        '[role="document"][contenteditable]' // Any document in editing mode
      ];
      
      // ═══════════════════════════════════════════════════════════════════
      // NODE ID ASSIGNMENT: Hash-based for stability across snapshots
      // 
      // OLD: Sequential (nodeId = 0, 1, 2...) - IDs shifted when DOM changed
      // NEW: Hash-based - same element gets same ID across snapshots
      //
      // This prevents iteration loops where LLM's cached node_id becomes stale
      // ═══════════════════════════════════════════════════════════════════
      let nodeIdCounter = 0;  // Fallback counter for hash collisions
      const usedNodeIds = new Set();  // Track used IDs to avoid collisions
      const nodeMap = new Map();
      const processedElements = new Set(); // Avoid duplicates
      
      // Generate stable node ID from element's stableHash
      function getStableNodeId(stableHash) {
        if (!stableHash) return nodeIdCounter++;
        
        // Convert hash to number (use first 8 chars of base36 hash)
        let hashNum = parseInt(stableHash.substring(0, 8), 36);
        if (isNaN(hashNum)) hashNum = nodeIdCounter++;
        
        // Modulo to keep IDs reasonable (0-9999)
        let nodeId = hashNum % 10000;
        
        // Handle collisions by incrementing
        while (usedNodeIds.has(nodeId)) {
          nodeId = (nodeId + 1) % 10000;
        }
        usedNodeIds.add(nodeId);
        return nodeId;
      }
      
      // ═══════════════════════════════════════════════════════════════════════════
      // STABLE NODE ID GENERATION (BROWSEROSS IMPROVEMENT)
      // Generate a stable hash for elements that persists across page changes
      // Used as secondary identifier when auto-increment nodeId becomes stale
      // ═══════════════════════════════════════════════════════════════════════════
      function generateStableHash(element) {
        // Build a fingerprint from stable element properties
        const components = [];
        
        // 1. Tag name (very stable)
        components.push(element.tagName?.toLowerCase() || 'unknown');
        
        // 2. ID (extremely stable when present)
        if (element.id) {
          components.push(`id:${element.id}`);
        }
        
        // 3. Stable attributes (sorted for consistency)
        const stableAttrs = ['name', 'data-testid', 'data-test', 'role', 'type', 'href', 'aria-label'];
        for (const attr of stableAttrs) {
          const value = element.getAttribute(attr);
          if (value) {
            // Truncate long values (URLs, etc)
            components.push(`${attr}:${value.substring(0, 50)}`);
          }
        }
        
        // 4. Class names (sorted, filtered for non-random ones)
        if (element.className && typeof element.className === 'string') {
          const classes = element.className.split(/\s+/)
            .filter(c => c && c.length > 1 && c.length < 40)
            .filter(c => !/^(is-|has-|ng-|v-|js-|css-|__|\d)/.test(c)) // Skip dynamic classes
            .sort()
            .slice(0, 5); // Limit to avoid hash instability
          if (classes.length > 0) {
            components.push(`cls:${classes.join('.')}`);
          }
        }
        
        // 5. DOM position (path from nearest landmark or body)
        const landmark = element.closest('[role="main"], [role="navigation"], main, nav, header, footer, aside, form');
        if (landmark && landmark !== element) {
          // Get index among siblings of same tag
          const siblings = Array.from(landmark.querySelectorAll(element.tagName?.toLowerCase() || '*'));
          const index = siblings.indexOf(element);
          if (index > -1) {
            const landmarkId = landmark.id || landmark.getAttribute('role') || landmark.tagName.toLowerCase();
            components.push(`pos:${landmarkId}[${index}]`);
          }
        } else {
          // Fallback: use nth-child position
          const parent = element.parentElement;
          if (parent) {
            const siblings = Array.from(parent.children);
            const index = siblings.indexOf(element);
            components.push(`nth:${index}`);
          }
        }
        
        // 6. Text content fingerprint (for disambiguation of similar elements)
        const text = (element.textContent || '').trim().substring(0, 30);
        if (text && text.length > 2) {
          // Simple hash of text to avoid exposing content
          let textHash = 0;
          for (let i = 0; i < text.length; i++) {
            textHash = ((textHash << 5) - textHash) + text.charCodeAt(i);
            textHash = textHash & textHash; // Convert to 32-bit int
          }
          components.push(`txt:${Math.abs(textHash).toString(36).substring(0, 6)}`);
        }
        
        // Create final hash from components
        const fingerprint = components.join('|');
        let hash = 0;
        for (let i = 0; i < fingerprint.length; i++) {
          hash = ((hash << 5) - hash) + fingerprint.charCodeAt(i);
          hash = hash & hash;
        }
        
        // Return both the hash (for comparison) and readable fingerprint (for debugging)
        return {
          hash: Math.abs(hash).toString(36),
          fingerprint: fingerprint.substring(0, 100) // Truncate for storage
        };
      }
      
      // BrowserOS-STYLE DEEP DOM TRAVERSAL: Traverse iframes and shadow DOM
      function collectElementsDeep(root, frameOffset = { x: 0, y: 0 }) {
        const elements = [];
        
        // Collect from main selectors
        selectors.forEach(selector => {
          try {
            root.querySelectorAll(selector).forEach((el) => {
              // EARLY TAG PRUNING - Skip non-interactive tags immediately
              if (SKIP_TAGS.has(el.tagName?.toUpperCase())) return;
              
              if (!processedElements.has(el)) {
                processedElements.add(el);
                elements.push({ element: el, frameOffset });
              }
            });
          } catch (e) {
            // Selector might not be valid in this context
          }
        });
        
        // TRAVERSE SHADOW DOM - look for elements with shadow roots
        const elementsWithShadow = root.querySelectorAll('*');
        elementsWithShadow.forEach(el => {
          if (el.shadowRoot) {
            // Recursively search shadow DOM
            const shadowElements = collectElementsDeep(el.shadowRoot, frameOffset);
            elements.push(...shadowElements);
          }
        });
        
        // TRAVERSE SAME-ORIGIN IFRAMES
        const iframes = root.querySelectorAll('iframe');
        iframes.forEach(iframe => {
          try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
            if (iframeDoc && iframeDoc.body) {
              // Calculate iframe offset for correct bounds
              const iframeRect = getCachedRect(iframe);
              const newOffset = {
                x: frameOffset.x + iframeRect.x,
                y: frameOffset.y + iframeRect.y
              };
              const iframeElements = collectElementsDeep(iframeDoc, newOffset);
              elements.push(...iframeElements);
            }
          } catch (e) {
            // Cross-origin iframe - can't access, skip
          }
        });
        
        // SPECIAL HANDLING: Find ALL text input elements using GENERIC patterns
        // NO SITE-SPECIFIC HARDCODING - works for ANY webpage
        // BrowserOS uses IsNonAtomicTextField() which knows about rich editors natively
        // We replicate this using generic HTML/ARIA patterns
        try {
          // 1. ALL contenteditable elements (using standard HTML attribute)
          const allEditables = root.querySelectorAll(
            '[contenteditable], [contenteditable="true"], [contenteditable=""], ' +
            '[role="textbox"], [role="searchbox"], [aria-multiline="true"]'
          );
          allEditables.forEach(el => {
            if (!processedElements.has(el)) {
              processedElements.add(el);
              elements.push({ element: el, frameOffset });
            }
          });
          
          // 2. Find elements that INHERIT contenteditable (key for rich editors!)
          // The isContentEditable property returns true even if the attribute is on a parent
          // This catches elements inside contenteditable containers (ANY rich text editor)
          const allElements = root.querySelectorAll('*');
          allElements.forEach(el => {
            // EARLY TAG PRUNING
            if (SKIP_TAGS.has(el.tagName?.toUpperCase())) return;
            
            if (el.isContentEditable && !processedElements.has(el)) {
              // Only add leaf editable elements (not containers)
              const hasEditableChild = Array.from(el.children).some(child => child.isContentEditable);
              if (!hasEditableChild) {
                processedElements.add(el);
                elements.push({ element: el, frameOffset });
              }
            }
          });
          
          // 3. Find elements with designMode='on' (another way to enable editing)
          // This is a document-level property but we check iframes
          const allIframes = root.querySelectorAll('iframe');
          allIframes.forEach(iframe => {
            try {
              const iframeDoc = iframe.contentDocument;
              if (iframeDoc && iframeDoc.designMode === 'on') {
                // The entire iframe body is editable
                if (iframeDoc.body && !processedElements.has(iframeDoc.body)) {
                  processedElements.add(iframeDoc.body);
                  const iframeRect = getCachedRect(iframe);
                  elements.push({ 
                    element: iframeDoc.body, 
                    frameOffset: { x: frameOffset.x + iframeRect.x, y: frameOffset.y + iframeRect.y }
                  });
                }
              }
              // Also check for contenteditable body in iframe
              if (iframeDoc?.body?.isContentEditable && !processedElements.has(iframeDoc.body)) {
                processedElements.add(iframeDoc.body);
                const iframeRect = getCachedRect(iframe);
                elements.push({ 
                  element: iframeDoc.body, 
                  frameOffset: { x: frameOffset.x + iframeRect.x, y: frameOffset.y + iframeRect.y }
                });
              }
            } catch (e) {
              // Cross-origin iframe - can't access
            }
          });
          
          // 4. Find elements with data attributes commonly used by editors (GENERIC patterns)
          // These are standard patterns used by many libraries, not site-specific
          const genericEditorAttributes = [
            '[data-editor]',              // Generic editor data attribute
            '[data-text-editor]',         // Generic text editor
            '[data-rich-text]',           // Rich text indicator
            '[data-editable]',            // Editable indicator
            '[data-input]',               // Input data attribute
          ];
          
          genericEditorAttributes.forEach(selector => {
            try {
              root.querySelectorAll(selector).forEach(el => {
                if (!processedElements.has(el)) {
                  processedElements.add(el);
                  elements.push({ element: el, frameOffset });
                }
              });
            } catch (e) {
              // Selector might not work
            }
          });
          
        } catch (e) {
          // Ignore errors in special handling
        }
        
        return elements;
      }
      
      // Start deep collection from document
      const allElements = collectElementsDeep(document);
      
      // CANVAS-BASED EDITOR DETECTION: Check if page has large canvas elements
      // This helps identify pages like Google Docs that use canvas for rendering
      const hasLargeCanvas = Array.from(document.querySelectorAll('canvas')).some(canvas => {
        const rect = getCachedRect(canvas);
        return rect.width > 300 && rect.height > 200;
      });
      
      // Track filtering stats for debugging
      let filterStats = {
        total: allElements.length,
        skippedByTag: 0,
        skippedByVisibility: 0,
        skippedBySize: 0,
        skippedByDisabled: 0,
        skippedByViewport: 0,
        skippedByOcclusion: 0, // NEW: Top element detection
        passed: 0
      };
      
      // ═══════════════════════════════════════════════════════════════════════════
      // BROWSERSOS-STYLE COMPREHENSIVE FILTERING
      // All optimizations applied: caching, early pruning, visibility, occlusion
      // ═══════════════════════════════════════════════════════════════════════════
      const filteredElements = allElements.filter(({ element: el, frameOffset }) => {
        const tagName = el.tagName?.toUpperCase();
        
        // OPTIMIZATION 2: Early tag pruning (already done during collection, but double-check)
        if (SKIP_TAGS.has(tagName)) {
          filterStats.skippedByTag++;
          return false;
        }
        
        // Use cached rect and style
        const rect = getCachedRect(el);
        const style = getCachedStyle(el);
        
        // SPECIAL CASE: Preserve hidden INPUT-CAPTURE elements for canvas-based editors
        // These are textareas/inputs styled to be invisible but still receive keyboard input
        // Common in Google Docs, Figma, and other canvas-based applications
        const isInputCaptureElement = (
          (tagName === 'TEXTAREA' || tagName === 'INPUT') &&
          (style.opacity === '0' || parseFloat(style.opacity) < 0.1 ||
           style.position === 'fixed' || style.position === 'absolute') &&
          // Check if it can still receive focus (not truly hidden)
          style.display !== 'none' && 
          !el.disabled
        );
        
        if (isInputCaptureElement && hasLargeCanvas) {
          // Mark this element as an input-capture element (will be handled specially)
          el._isInputCapture = true;
          filterStats.passed++;
          return true; // Keep this element even though it appears hidden
        }
        
        // OPTIMIZATION 3: Use checkVisibility() or fallback
        if (!isElementVisible(el)) {
          filterStats.skippedByVisibility++;
          return false;
        }
        
        // Skip zero-size elements (but not input-capture elements which might be zero-size)
        if (rect.width === 0 || rect.height === 0) {
          filterStats.skippedBySize++;
          return false;
        }
        
        // Skip disabled elements (BrowserOS-style)
        if (el.disabled || el.getAttribute('aria-disabled') === 'true') {
          filterStats.skippedByDisabled++;
          return false;
        }
        
        // OPTIMIZATION 5: Viewport expansion check
        if (!isInExpandedViewport(rect, frameOffset)) {
          filterStats.skippedByViewport++;
          return false;
        }
        
        // ═══════════════════════════════════════════════════════════════════════
        // OPTIMIZATION 4: TOP ELEMENT DETECTION (THE BIG TOKEN SAVER!)
        // Filter elements that are covered by other elements
        // This eliminates: hidden dropdowns, off-screen menus, overlapped elements
        // ═══════════════════════════════════════════════════════════════════════
        if (!isTopElement(el, rect, frameOffset)) {
          filterStats.skippedByOcclusion++;
          return false;
        }
        
        filterStats.passed++;
        return true;
      });
      
      // Process filtered elements
      filteredElements.forEach(({ element: el, frameOffset }) => {
        const rect = el.getBoundingClientRect();
        
        // BrowserOS-STYLE: Extract comprehensive metadata for element disambiguation
        const ariaLabel = el.getAttribute('aria-label') || '';
        const title = el.getAttribute('title') || '';
        const placeholder = el.getAttribute('placeholder') || '';
        const role = el.getAttribute('role') || '';
        const dataTestId = el.getAttribute('data-testid') || el.getAttribute('data-test') || '';
        const tagName = el.tagName?.toUpperCase();
        const inputType = el.type?.toLowerCase();
        const ariaMultiline = el.getAttribute('aria-multiline');
        
        // Build a descriptive name with context
        const name = ariaLabel || title || placeholder ||
                    el.textContent?.trim().substring(0, 50) || '';
        
        // BrowserOS-STYLE: Determine node type using comprehensive checks
        // Matches BrowserOS's GetInteractiveNodeType() logic
        let nodeType = 'other';
        
        // Helper: Check if it's a typing-capable input type
        const isTypingInput = ['text', 'password', 'email', 'search', 'tel', 'url', 'number', '', undefined, null].includes(inputType);
        
        // 1. TYPEABLE - Text inputs, textareas, contenteditable, rich editors
        // BrowserOS uses: IsTextField(), IsNonAtomicTextField(), IsAtomicTextField()
        if (
          tagName === 'TEXTAREA' ||
          (tagName === 'INPUT' && isTypingInput) ||
          el.isContentEditable ||  // Handles inherited contenteditable (Google Docs!)
          el.getAttribute('contenteditable') === 'true' ||
          el.getAttribute('contenteditable') === '' ||
          ['textbox', 'searchbox', 'spinbutton'].includes(role) ||
          ariaMultiline === 'true' ||
          el.classList?.contains('ProseMirror') ||  // Popular editor
          el.classList?.contains('ql-editor') ||    // Quill editor
          el.hasAttribute('data-slate-editor') ||   // Slate editor
          el.hasAttribute('data-lexical-editor')    // Lexical editor
        ) {
          nodeType = 'typeable';
        }
        // 2. SELECTABLE - Dropdowns, checkboxes, radios, menus, tabs
        // BrowserOS uses: IsSelectable(), plus role checks
        else if (
          tagName === 'SELECT' ||
          tagName === 'OPTION' ||
          inputType === 'checkbox' ||
          inputType === 'radio' ||
          ['combobox', 'listbox', 'option', 'menuitemcheckbox', 
           'menuitemradio', 'tab', 'checkbox', 'radio', 
           'switch', 'slider', 'treeitem'].includes(role)
        ) {
          nodeType = 'selectable';
        }
        // 3. CLICKABLE - Buttons, links, menu items, anything with click handler
        // BrowserOS uses: IsClickable()
        else if (
          tagName === 'BUTTON' ||
          tagName === 'A' ||
          inputType === 'button' ||
          inputType === 'submit' ||
          inputType === 'reset' ||
          inputType === 'image' ||
          ['button', 'link', 'menuitem', 'gridcell', 'row'].includes(role) ||
          el.onclick ||
          el.getAttribute('onclick') ||
          el.getAttribute('aria-haspopup')
        ) {
          nodeType = 'clickable';
        }
        // 4. Check if focusable (implicit clickable)
        else {
          const tabindex = el.getAttribute('tabindex');
          if (tabindex !== null && tabindex !== '-1') {
            nodeType = 'clickable';
          }
        }
        
        // Calculate adjusted bounds for iframe elements
        const adjustedBounds = {
          x: Math.round(rect.x + frameOffset.x),
          y: Math.round(rect.y + frameOffset.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        };
        
        // BrowserOS-STYLE: Calculate area to help distinguish title (small) vs body (large)
        const area = adjustedBounds.width * adjustedBounds.height;
        
        // BrowserOS-STYLE: Expose raw semantic attributes - NO site-specific hardcoding
        // Let the LLM understand context from these generic attributes
        // This works for ANY website, not just specific ones
        
        // Check if element is inside a dialog/modal (generic detection)
        const isInDialog = !!el.closest('[role="dialog"]') || !!el.closest('[role="alertdialog"]') || !!el.closest('dialog');
        
        // Get the closest landmark role for context
        const closestLandmark = el.closest('[role="main"]') || el.closest('[role="navigation"]') || 
                               el.closest('[role="form"]') || el.closest('[role="search"]') ||
                               el.closest('main') || el.closest('nav') || el.closest('form');
        const landmarkRole = closestLandmark?.getAttribute('role') || closestLandmark?.tagName?.toLowerCase() || '';
        
        // BrowserOS-STYLE: Check if this is a rich text editor using GENERIC patterns
        // No site-specific hardcoding - detects based on standard HTML patterns
        // Rich editors typically: have contenteditable, aria-multiline, or are inside an editable container
        const isRichEditor = !!(
          // Element itself is editable but NOT a standard input/textarea
          (el.isContentEditable && tagName !== 'INPUT' && tagName !== 'TEXTAREA') ||
          // Has aria-multiline (standard ARIA for multi-line text)
          ariaMultiline === 'true' ||
          // Has role="document" with editing capability
          (role === 'document' && el.isContentEditable) ||
          // Inside a designMode iframe
          (el.ownerDocument?.designMode === 'on') ||
          // Has generic editor data attributes
          el.hasAttribute('data-editor') ||
          el.hasAttribute('data-text-editor') ||
          el.hasAttribute('data-rich-text')
        );
        
        // BrowserOS-STYLE: Expose raw semantic data - let LLM figure out context
        // FALLBACK ATTRIBUTES: Store explicit id/class for resilient clicking
        const htmlId = el.id || null;
        const className = (typeof el.className === 'string' && el.className.trim()) ? el.className.trim() : null;
        
        // Generate stable hash for this element (persists across page changes)
        const stableId = generateStableHash(el);
        
        // Use hash-based nodeId for stability across snapshots
        const assignedNodeId = getStableNodeId(stableId.hash);
        
        const nodeInfo = {
          nodeId: assignedNodeId,
          stableHash: stableId.hash,  // Stable identifier for resilient element lookup
          type: nodeType,
          name: name,
          bounds: adjustedBounds,
          selector: getSelector(el),
          // ═══════════════════════════════════════════════════════════════════
          // BROWSERSOS-STYLE FALLBACK ATTRIBUTES
          // These enable cascading click strategies if nodeId becomes stale:
          // 1. nodeId (fastest) → 2. htmlId → 3. selector → 4. text → 5. coordinates
          // ═══════════════════════════════════════════════════════════════════
          htmlId: htmlId,           // Direct element ID (most stable)
          className: className,      // CSS classes for selector fallback
          textContent: name?.substring(0, 100) || null,  // Text for search fallback (truncated)
          coordinates: adjustedBounds ? {  // Center coordinates for last-resort click
            x: Math.round(adjustedBounds.x + adjustedBounds.width / 2),
            y: Math.round(adjustedBounds.y + adjustedBounds.height / 2)
          } : null,
          // Core element properties
          tagName: tagName?.toLowerCase(),
          isContentEditable: el.isContentEditable || el.getAttribute('contenteditable') === 'true' || el.getAttribute('contenteditable') === '',
          isInheritedEditable: el.isContentEditable && el.getAttribute('contenteditable') === null, // Inherited from parent
          inIframe: frameOffset.x !== 0 || frameOffset.y !== 0,
          hasShadowRoot: !!el.shadowRoot,
          // Input capture detection (for canvas-based editors)
          isInputCapture: el._isInputCapture || false,  // Hidden input that captures keyboard for canvas editors
          // Semantic attributes (generic, works for ANY site)
          placeholder: placeholder,
          ariaLabel: ariaLabel,
          role: role,  // ARIA role
          ariaMultiline: ariaMultiline === 'true',  // Multi-line text field (like Google Docs)
          area: area,  // Element area in pixels (larger = likely body/content)
          // Context information
          isInDialog: isInDialog,  // Is this inside a modal/dialog?
          landmarkRole: landmarkRole,  // Closest landmark (main, nav, form, search)
          inputType: inputType || '',  // For INPUT elements (use already defined variable)
          isRichEditor: isRichEditor,  // Is this a known rich text editor?
          dataTestId: dataTestId
        };
        
        nodeMap.set(nodeInfo.nodeId, el);
        interactiveElements.push(nodeInfo);
      });
      
      // Store node mapping globally for this tab
      window.__centrisNodeMap = nodeMap;
      
      // ═══════════════════════════════════════════════════════════════════
      // ═══════════════════════════════════════════════════════════════════
      // GULLI PATTERN: TASK-CONTEXT-AWARE FILTERING
      // 
      // When backend passes taskContext, we can filter more aggressively:
      // - email tasks: prioritize inbox, compose, subject elements
      // - search tasks: prioritize search input, result links
      // - generic: keep all types proportionally
      //
      // This reduces tokens at SOURCE (extension) instead of backend
      // ═══════════════════════════════════════════════════════════════════
      const url = window.location.href.toLowerCase();
      const hostname = window.location.hostname.toLowerCase();
      
      // Detect task domain from URL and optional taskContext param
      let taskDomain = 'generic';
      if (hostname.includes('mail.google.com') || hostname.includes('outlook') || 
          url.includes('mail') || url.includes('inbox')) {
        taskDomain = 'email';
      } else if (hostname.includes('google.com/search') || url.includes('/search') ||
                 hostname.includes('bing.com') || hostname.includes('duckduckgo')) {
        taskDomain = 'search';
      } else if (hostname.includes('twitter') || hostname.includes('x.com') || 
                 hostname.includes('facebook') || hostname.includes('linkedin') ||
                 hostname.includes('instagram')) {
        taskDomain = 'social';
      } else if (hostname.includes('docs.google.com') || hostname.includes('notion.so') ||
                 hostname.includes('drive.google.com')) {
        taskDomain = 'docs';
      }
      
      // GULLI: Task-domain-specific element prioritization
      // Score elements by relevance to detected task domain
      const TASK_RELEVANCE_KEYWORDS = {
        email: ['inbox', 'compose', 'send', 'reply', 'forward', 'subject', 'from', 'to', 
                'attachment', 'draft', 'archive', 'delete', 'starred', 'important', 'unread'],
        search: ['search', 'result', 'link', 'next', 'page', 'filter', 'sort'],
        social: ['post', 'tweet', 'like', 'share', 'comment', 'follow', 'message', 'dm'],
        docs: ['edit', 'save', 'insert', 'format', 'file', 'share', 'comment']
      };
      
      // Score each element by task relevance
      const relevanceKeywords = TASK_RELEVANCE_KEYWORDS[taskDomain] || [];
      if (relevanceKeywords.length > 0) {
        interactiveElements.forEach(el => {
          const text = ((el.name || '') + ' ' + (el.ariaLabel || '') + ' ' + (el.role || '')).toLowerCase();
          const relevanceScore = relevanceKeywords.reduce((score, kw) => 
            score + (text.includes(kw) ? 2 : 0), 0);
          el._taskRelevance = relevanceScore;
        });
      }
      
      // ═══════════════════════════════════════════════════════════════════
      // ELEMENT LIMIT: 30-50 elements based on task domain
      // 
      // AGGRESSIVE TOKEN OPTIMIZATION (Jan 2026):
      // - Previous: 50-75 elements → ~6-8K chars per snapshot
      // - New: 30-50 elements → ~3-5K chars per snapshot
      // - With task-aware filtering, fewer elements = same effectiveness
      // - Each snapshot in conversation costs tokens PER ITERATION
      // ═══════════════════════════════════════════════════════════════════
      let MAX_ELEMENTS = 50;  // DEFAULT: Reduced from 75 for token efficiency
      
      // Domain-specific limits (all reduced by ~33%)
      if (hostname.includes('docs.google.com') || hostname.includes('notion.so')) {
        MAX_ELEMENTS = 25;  // Docs: fewer interactive elements, mostly one editor
      } else if (taskDomain === 'search') {
        MAX_ELEMENTS = 35;  // Search: results + some controls
      } else if (taskDomain === 'email') {
        MAX_ELEMENTS = 40;  // Email: need to see email list but with smart filtering
      }
      const originalCount = interactiveElements.length;
      
      // ═══════════════════════════════════════════════════════════════════
      // GULLI PATTERN: Task-relevance-aware sorting
      // Elements relevant to the detected task domain get higher priority
      // ═══════════════════════════════════════════════════════════════════
      const typePriority = { typeable: 0, clickable: 1, selectable: 2, other: 3 };
      interactiveElements.sort((a, b) => {
        // GULLI: Task relevance first (if task domain detected)
        const aRelevance = a._taskRelevance || 0;
        const bRelevance = b._taskRelevance || 0;
        if (aRelevance !== bRelevance) return bRelevance - aRelevance;  // Higher relevance first
        
        // Type priority next
        const typeDiff = (typePriority[a.type] || 3) - (typePriority[b.type] || 3);
        if (typeDiff !== 0) return typeDiff;
        
        // Prefer elements with semantic info (ariaLabel or meaningful name)
        const aHasLabel = (a.ariaLabel || a.name?.length > 3) ? 1 : 0;
        const bHasLabel = (b.ariaLabel || b.name?.length > 3) ? 1 : 0;
        if (bHasLabel !== aHasLabel) return bHasLabel - aHasLabel;
        
        // Then by area (larger = likely main content)
        return (b.area || 0) - (a.area || 0);
      });
      
      // Limit to MAX_ELEMENTS
      const truncatedElements = interactiveElements.slice(0, MAX_ELEMENTS);
      
      // ═══════════════════════════════════════════════════════════════════
      // TOKEN-OPTIMIZED OUTPUT: Abbreviated keys for LLM token savings
      // Format: {id, t, n, r?} where t values: cl/ty/se
      // Legend is in system prompt - LLM knows how to interpret
      // Saves ~100 tokens per snapshot (~37% reduction on element data)
      // ═══════════════════════════════════════════════════════════════════
      const TYPE_ABBREV = {
        'clickable': 'cl',
        'typeable': 'ty', 
        'selectable': 'se',
        'other': 'ot'
      };
      
      const slimElements = truncatedElements.map(el => {
        // Prefer ariaLabel over name (more semantic), truncate aggressively
        const label = (el.ariaLabel || el.name || el.placeholder || '').substring(0, 35);
        
        return {
          id: el.nodeId,                          // Abbreviated: nodeId → id
          h: el.stableHash || undefined,          // NEW: Stable hash that survives DOM changes (for reliable clicks)
          t: TYPE_ABBREV[el.type] || 'ot',        // Abbreviated: type → t, values: cl/ty/se/ot
          n: label || el.tagName,                 // Abbreviated: name → n (max 35 chars)
          r: el.role || undefined                 // Abbreviated: role → r
        };
      });
      
      // Count node types for quick summary (use abbreviated type values)
      const typeCount = { ty: 0, cl: 0, se: 0, ot: 0 };
      slimElements.forEach(el => {
        typeCount[el.t] = (typeCount[el.t] || 0) + 1;
      });
      
      // Check for rich editors on page (use original array before slimming)
      const hasRichEditor = truncatedElements.some(el => el.isRichEditor || el.ariaMultiline);
      const hasContentEditable = truncatedElements.some(el => el.isContentEditable);
      
      // Detect canvas-based editor (generic detection - not site-specific)
      // These editors render on canvas but use hidden textareas for input
      const hasInputCapture = truncatedElements.some(el => el.isInputCapture);
      const hasCanvasEditor = hasLargeCanvas && (hasInputCapture || !hasContentEditable);
      
      return {
        snapshotId: Date.now(),
        timestamp: Date.now(),
        interactiveNodes: slimElements,  // Abbreviated for LLM token savings
        // Full element data for internal use (visualization, click lookup)
        // NOT sent to LLM - only used by extension internals
        _internalNodes: truncatedElements,
        // Canvas editor hint for the LLM
        hasCanvasEditor: hasCanvasEditor,
        hasInputCapture: hasInputCapture,
        // Include metadata about DOM traversal
        metadata: {
          totalProcessed: processedElements.size,
          filteredCount: filteredElements.length,
          hasIframes: document.querySelectorAll('iframe').length > 0,
          hasShadowDOM: Array.from(document.querySelectorAll('*')).some(el => el.shadowRoot),
          url: url,
          // Generic context: are we in a modal/dialog context?
          hasOpenDialog: !!document.querySelector('[role="dialog"]') || !!document.querySelector('dialog[open]'),
          // BrowserOS-STYLE: Node type summary
          typeCount: typeCount,
          hasRichEditor: hasRichEditor,
          hasContentEditable: hasContentEditable,
          // Detection hints for debugging
          pageType: hasRichEditor ? 'rich_editor' : 
                   hasContentEditable ? 'contenteditable' : 
                   typeCount.typeable > 0 ? 'form' : 'interactive',
          // GULLI: Task domain detected for this page
          taskDomain: taskDomain,
          // ═══════════════════════════════════════════════════════════════════
          // BROWSERSOS-STYLE: Filtering Statistics
          // Shows exactly how many elements were filtered at each stage
          // Use this to verify token reduction is working!
          // ═══════════════════════════════════════════════════════════════════
          filterStats: filterStats,
          tokenReduction: {
            before: filterStats.total,
            after: filterStats.passed,
            percentReduced: filterStats.total > 0 
              ? Math.round((1 - filterStats.passed / filterStats.total) * 100) 
              : 0,
            // Breakdown by filter type
            byVisibility: filterStats.skippedByVisibility,
            byOcclusion: filterStats.skippedByOcclusion,  // THE BIG ONE!
            byViewport: filterStats.skippedByViewport,
            bySize: filterStats.skippedBySize,
            byDisabled: filterStats.skippedByDisabled
          },
          // Element truncation stats (new token saving!)
          elementTruncation: {
            originalCount: originalCount,
            truncatedTo: slimElements.length,
            truncated: originalCount > MAX_ELEMENTS,
            maxLimit: MAX_ELEMENTS
          }
        }
      };
      
      function getSelector(el) {
        if (el.id) return `#${el.id}`;
        if (el.className && typeof el.className === 'string') {
          const classes = el.className.split(' ').filter(c => c && !c.includes(':')).join('.');
          if (classes) return `${el.tagName.toLowerCase()}.${classes}`;
        }
        return el.tagName?.toLowerCase() || 'unknown';
      }
    },
    // ═══════════════════════════════════════════════════════════════════════════
    // BROWSERSOS-STYLE: Viewport Expansion Parameter
    // 0 = strict viewport only (default, best for token reduction)
    // 50-100 = include elements slightly outside viewport (good for scrolling)
    // -1 = include all elements (no viewport filtering, for debugging)
    // ═══════════════════════════════════════════════════════════════════════════
    args: [0]  // Default: strict viewport filtering for maximum token reduction
  });
  
  const snapshot = results[0].result;
  
  // Store node mappings for this tab (use full element data for internal use)
  if (!nodeIdMappings.has(tabId)) {
    nodeIdMappings.set(tabId, new Map());
  }
  const tabMapping = nodeIdMappings.get(tabId);
  
  // Store FULL element data from _internalNodes (for visualization, click lookup)
  // This includes bounds, full type names, etc. needed by internal functions
  const internalNodes = snapshot._internalNodes || snapshot.interactiveNodes;
  internalNodes.forEach(node => {
    tabMapping.set(node.nodeId, node);
  });
  
  // Remove _internalNodes before returning to caller (LLM doesn't need it)
  delete snapshot._internalNodes;
  
  return snapshot;
}

async function getInteractiveElements(tabId) {
  // Get interactive elements (compatible with existing API)
  // This is a simplified version - use getInteractiveSnapshot for BrowserOS-style API
  // Note: Returns abbreviated format (id, t, n, r) for token efficiency
  const snapshot = await getInteractiveSnapshot(tabId);
  
  // Map abbreviated keys to legacy format for backwards compatibility
  return snapshot.interactiveNodes.map(node => ({
    node_id: node.id,      // id = nodeId
    type: node.t === 'cl' ? 'clickable' : node.t === 'ty' ? 'typeable' : node.t === 'se' ? 'selectable' : 'other',
    name: node.n,          // n = name
    role: node.r           // r = role
  }));
}

// BrowserOS-STYLE: Explicit keyboard simulation for complex editors like Google Docs
// This function simulates real keyboard events character by character
// Enhanced for canvas-based editors that use hidden input-capture textareas
async function simulateKeyboard(tabId, text, options = {}) {
  logWithTimestamp('info', `⌨️ simulateKeyboard: Simulating keyboard for ${text.length} characters on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  // Ensure visualizations are available
  await ensureVisualizationsInjected(tabId);
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (text, options) => {
      const { charDelay = 10, clearFirst = false, forceDocumentLevel = false } = options;
      
      // CANVAS-BASED EDITOR DETECTION: Find hidden input-capture elements
      // These are textareas/inputs that are styled invisible but capture keyboard input
      // Used by Google Docs, Figma, and other canvas-based applications
      function findInputCaptureElement() {
        // Look for hidden textareas (common pattern in canvas editors)
        const allTextareas = document.querySelectorAll('textarea');
        for (const ta of allTextareas) {
          const style = window.getComputedStyle(ta);
          // Input capture elements are often: opacity 0, very small, or positioned off-screen
          // But they're NOT display:none (so they can still receive focus)
          if ((parseFloat(style.opacity) < 0.1 || 
               parseInt(style.width) < 10 || parseInt(style.height) < 10 ||
               style.position === 'fixed' || style.position === 'absolute') &&
              style.display !== 'none' && !ta.disabled) {
            return ta;
          }
        }
        
        // Check inside iframes (many editors use an iframe for input capture)
        const iframes = document.querySelectorAll('iframe');
        for (const iframe of iframes) {
          try {
            const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
            if (iframeDoc) {
              const iframeTa = iframeDoc.querySelector('textarea:not([disabled])');
              if (iframeTa) return iframeTa;
              const iframeInput = iframeDoc.querySelector('input:not([disabled]):not([type="hidden"])');
              if (iframeInput) return iframeInput;
            }
          } catch (e) {
            // Cross-origin iframe, can't access
          }
        }
        return null;
      }
      
      // Get the currently focused element or find one
      let target = document.activeElement;
      let usedInputCapture = false;
      
      // For canvas-based editors, try to find the hidden input capture element
      const hasLargeCanvas = Array.from(document.querySelectorAll('canvas')).some(c => {
        const rect = c.getBoundingClientRect();
        return rect.width > 300 && rect.height > 200;
      });
      
      if (hasLargeCanvas || forceDocumentLevel) {
        // Try to find input capture element first
        const inputCapture = findInputCaptureElement();
        if (inputCapture) {
          target = inputCapture;
          target.focus();
          usedInputCapture = true;
          await new Promise(r => setTimeout(r, 100)); // Extra delay for focus
        }
      }
      
      if (!target || target === document.body || target === document.documentElement) {
        // Try to find an editable element
        target = document.querySelector('[contenteditable="true"]') ||
                document.querySelector('input:focus, textarea:focus') ||
                document.querySelector('input:not([type="hidden"]), textarea');
        
        if (target) {
          target.focus();
          await new Promise(r => setTimeout(r, 50));
        } else {
          return { success: false, error: 'No editable element found or focused. Try clicking on the document canvas first.' };
        }
      }
      
      // Show visual feedback
      const rect = target.getBoundingClientRect();
      if (window.centrisHighlightElement) {
        window.centrisHighlightElement(rect.left, rect.top, rect.width, rect.height);
      }
      if (window.centrisShowTyping) {
        window.centrisShowTyping(rect.left, rect.top, text);
      }
      
      // Clear first if requested
      if (clearFirst) {
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
          target.value = '';
        } else if (target.isContentEditable) {
          target.textContent = '';
        }
      }
      
      // Simulate typing character by character
      let typedCount = 0;
      for (const char of text) {
        const keyCode = char.charCodeAt(0);
        const key = char;
        const code = char.match(/[a-zA-Z]/) ? `Key${char.toUpperCase()}` : 
                    char.match(/[0-9]/) ? `Digit${char}` : 
                    char === ' ' ? 'Space' : 
                    char === '\n' ? 'Enter' : `Key${char}`;
        
        // KeyDown event
        target.dispatchEvent(new KeyboardEvent('keydown', {
          key, code, keyCode, which: keyCode,
          bubbles: true, cancelable: true, composed: true
        }));
        
        // KeyPress event (deprecated but some apps still use it)
        target.dispatchEvent(new KeyboardEvent('keypress', {
          key, code, keyCode, charCode: keyCode, which: keyCode,
          bubbles: true, cancelable: true, composed: true
        }));
        
        // BeforeInput event (for modern editors)
        target.dispatchEvent(new InputEvent('beforeinput', {
          data: char,
          inputType: 'insertText',
          bubbles: true,
          cancelable: true,
          composed: true
        }));
        
        // Actually insert the character
        if (target.isContentEditable || target.getAttribute('contenteditable') === 'true') {
          // For contenteditable
          try {
            document.execCommand('insertText', false, char);
          } catch (e) {
            // Fallback: direct insertion at selection
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
              const range = selection.getRangeAt(0);
              range.deleteContents();
              range.insertNode(document.createTextNode(char));
              range.collapse(false);
              selection.removeAllRanges();
              selection.addRange(range);
            }
          }
        } else if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
          // For input/textarea
          const start = target.selectionStart || target.value.length;
          const end = target.selectionEnd || target.value.length;
          target.value = target.value.substring(0, start) + char + target.value.substring(end);
          target.selectionStart = target.selectionEnd = start + 1;
        }
        
        // Input event (main event for most frameworks)
        target.dispatchEvent(new InputEvent('input', {
          data: char,
          inputType: 'insertText',
          bubbles: true,
          cancelable: false,
          composed: true
        }));
        
        // KeyUp event
        target.dispatchEvent(new KeyboardEvent('keyup', {
          key, code, keyCode, which: keyCode,
          bubbles: true, cancelable: true, composed: true
        }));
        
        typedCount++;
        
        // Delay between characters
        if (charDelay > 0) {
          await new Promise(r => setTimeout(r, charDelay));
        }
      }
      
      // Dispatch change event at the end
      target.dispatchEvent(new Event('change', { bubbles: true }));
      
      return { 
        success: true, 
        typedCount,
        targetTag: target.tagName,
        isContentEditable: target.isContentEditable,
        usedInputCapture: usedInputCapture,  // True if we found and used a hidden input-capture element
        method: usedInputCapture ? 'canvas-editor-input-capture' : 'direct-element'
      };
    },
    args: [text, options]
  });
  
  return results[0].result;
}

// BrowserOS-STYLE: Press a specific key (Enter, Tab, Escape, Backspace, etc.)
async function pressKey(tabId, key, modifiers = {}) {
  logWithTimestamp('info', `⌨️ pressKey: Pressing ${key} on tab ${tabId}`);
  
  // Validate tab
  if (!tabId) {
    try {
      const activeTab = await getActiveTab();
      if (!activeTab.success || !activeTab.id) {
        return { success: false, error: 'No active tab found' };
      }
      tabId = activeTab.id;
    } catch (e) {
      return { success: false, error: `Failed to get active tab: ${e.message}` };
    }
  }
  
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (key, modifiers) => {
      const { ctrl = false, alt = false, shift = false, meta = false } = modifiers;
      
      // Map key names to key codes
      const keyMap = {
        'Enter': { code: 'Enter', keyCode: 13 },
        'Tab': { code: 'Tab', keyCode: 9 },
        'Escape': { code: 'Escape', keyCode: 27 },
        'Backspace': { code: 'Backspace', keyCode: 8 },
        'Delete': { code: 'Delete', keyCode: 46 },
        'ArrowUp': { code: 'ArrowUp', keyCode: 38 },
        'ArrowDown': { code: 'ArrowDown', keyCode: 40 },
        'ArrowLeft': { code: 'ArrowLeft', keyCode: 37 },
        'ArrowRight': { code: 'ArrowRight', keyCode: 39 },
        'Home': { code: 'Home', keyCode: 36 },
        'End': { code: 'End', keyCode: 35 },
        'PageUp': { code: 'PageUp', keyCode: 33 },
        'PageDown': { code: 'PageDown', keyCode: 34 },
        'Space': { code: 'Space', keyCode: 32 },
        ' ': { code: 'Space', keyCode: 32 }
      };
      
      const keyInfo = keyMap[key] || { code: `Key${key.toUpperCase()}`, keyCode: key.charCodeAt(0) };
      
      const target = document.activeElement || document.body;
      
      // Build modifier flags
      const modifierFlags = 
        (ctrl ? 1 : 0) |
        (shift ? 2 : 0) |
        (alt ? 4 : 0) |
        (meta ? 8 : 0);
      
      // KeyDown
      const keydownEvent = new KeyboardEvent('keydown', {
        key: key,
        code: keyInfo.code,
        keyCode: keyInfo.keyCode,
        which: keyInfo.keyCode,
        ctrlKey: ctrl,
        altKey: alt,
        shiftKey: shift,
        metaKey: meta,
        bubbles: true,
        cancelable: true,
        composed: true
      });
      const keydownResult = target.dispatchEvent(keydownEvent);
      
      // For special keys like Enter, Tab, also handle special behavior
      if (key === 'Enter' && target.tagName === 'TEXTAREA') {
        // Insert newline
        const start = target.selectionStart || target.value.length;
        target.value = target.value.substring(0, start) + '\n' + target.value.substring(start);
        target.selectionStart = target.selectionEnd = start + 1;
      } else if (key === 'Backspace') {
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
          const start = target.selectionStart || 0;
          if (start > 0) {
            target.value = target.value.substring(0, start - 1) + target.value.substring(start);
            target.selectionStart = target.selectionEnd = start - 1;
          }
        } else if (target.isContentEditable) {
          document.execCommand('delete', false, null);
        }
      }
      
      // Input event if text changed
      if (key === 'Enter' || key === 'Backspace' || key === 'Delete') {
        target.dispatchEvent(new InputEvent('input', {
          inputType: key === 'Backspace' ? 'deleteContentBackward' : 
                    key === 'Delete' ? 'deleteContentForward' : 'insertLineBreak',
          bubbles: true
        }));
      }
      
      // KeyUp
      const keyupEvent = new KeyboardEvent('keyup', {
        key: key,
        code: keyInfo.code,
        keyCode: keyInfo.keyCode,
        which: keyInfo.keyCode,
        ctrlKey: ctrl,
        altKey: alt,
        shiftKey: shift,
        metaKey: meta,
        bubbles: true,
        cancelable: true,
        composed: true
      });
      target.dispatchEvent(keyupEvent);
      
      return { 
        success: true, 
        key,
        modifiers: { ctrl, alt, shift, meta },
        targetTag: target.tagName
      };
    },
    args: [key, modifiers]
  });
  
  return results[0].result;
}

async function takeScreenshot(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab) {
      return { success: false, error: 'Tab not found' };
    }
    
    const window = await chrome.windows.get(tab.windowId);
    if (!window) {
      return { success: false, error: 'Window not found' };
    }
    
    // BrowserOS-style: Optimized screenshot with timeout protection
    // Use JPEG compression (70% smaller than PNG)
    // Inspired by BrowserOS thumbnail optimization - reduces bandwidth significantly
    const screenshotPromise = chrome.tabs.captureVisibleTab(window.id, {
      format: 'jpeg',  // JPEG instead of PNG for compression
      quality: 85  // High quality but compressed (BrowserOS uses similar approach)
    });
    
    // Add timeout to prevent hanging (BrowserOS-style)
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Screenshot timeout after 30 seconds')), 30000)
    );
    
    const dataUrl = await Promise.race([screenshotPromise, timeoutPromise]);
    
    // Get tab context (profile, URL, title) - but don't block on it
    // BrowserOS-style: Return immediately with screenshot, profile info is optional
    const profileInfoPromise = getProfileInfo(tabId).catch(() => ({}));
    const profileTimeoutPromise = new Promise((resolve) => setTimeout(() => resolve({}), 2000));
    const profileInfo = await Promise.race([profileInfoPromise, profileTimeoutPromise]);
    
    return { 
      success: true, 
      dataUrl, 
      timestamp: Date.now(),
      tabContext: {
        tabId: tab.id,
        url: tab.url,
        title: tab.title,
        windowId: tab.windowId,
        profile: profileInfo
      }
    };
  } catch (error) {
    return { success: false, error: error.message || 'Screenshot failed' };
  }
}

async function takeFullPageScreenshot(tabId) {
  try {
    // Capture full page by scrolling and stitching
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        return {
          scrollHeight: document.documentElement.scrollHeight,
          scrollWidth: document.documentElement.scrollWidth,
          viewportHeight: window.innerHeight,
          viewportWidth: window.innerWidth,
          currentScrollY: window.scrollY,
          currentScrollX: window.scrollX
        };
      }
    });
    
    const pageInfo = results[0].result;
    
    // For now, capture visible area (full page capture requires more complex stitching)
    // In production, you'd scroll and stitch multiple screenshots
    const window = await chrome.windows.getCurrent();
    // Optimized: Use JPEG compression
    const dataUrl = await chrome.tabs.captureVisibleTab(window.id, {
      format: 'jpeg',
      quality: 85
    });
    
    return {
      success: true,
      dataUrl,
      pageInfo: {
        scrollHeight: pageInfo.scrollHeight,
        scrollWidth: pageInfo.scrollWidth,
        viewportHeight: pageInfo.viewportHeight,
        viewportWidth: pageInfo.viewportWidth
      },
      timestamp: Date.now()
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function takeElementScreenshot(tabId, selector) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (selector) => {
        const element = document.querySelector(selector);
        if (!element) {
          return { error: 'Element not found' };
        }
        
        const rect = element.getBoundingClientRect();
        return {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          scrollX: window.scrollX,
          scrollY: window.scrollY
        };
      },
      args: [selector]
    });
    
    const elementInfo = results[0].result;
    if (elementInfo.error) {
      return { success: false, error: elementInfo.error };
    }
    
    // Capture full page screenshot
    const window = await chrome.windows.getCurrent();
    // Optimized: Use JPEG compression
    const fullScreenshot = await chrome.tabs.captureVisibleTab(window.id, {
      format: 'jpeg',
      quality: 85
    });
    
    // Return full screenshot with element bounds for cropping on backend
    return {
      success: true,
      dataUrl: fullScreenshot,
      elementBounds: {
        x: elementInfo.x + elementInfo.scrollX,
        y: elementInfo.y + elementInfo.scrollY,
        width: elementInfo.width,
        height: elementInfo.height
      },
      timestamp: Date.now()
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function startVisionStream(tabId, interval = 1000) {
  try {
    if (visionStreamCallbacks.has(tabId)) {
      return { success: false, error: 'Vision stream already active for this tab' };
    }
    
    visionStreamingActive = true;
    
    const streamCallback = async () => {
      try {
        const screenshot = await takeScreenshot(tabId);
        if (screenshot.success) {
          sendToDesktopApp({
            type: 'vision_frame',
            tabId: tabId,
            dataUrl: screenshot.dataUrl,
            timestamp: screenshot.timestamp,
            tabContext: screenshot.tabContext || null
          });
        }
      } catch (error) {
        console.error('[Sentris Extension] Vision stream error:', error);
      }
    };
    
    visionStreamCallbacks.set(tabId, streamCallback);
    
    // Start streaming
    visionStreamInterval = setInterval(streamCallback, interval);
    
    return { success: true, interval: interval };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function stopVisionStream(tabId) {
  try {
    if (visionStreamCallbacks.has(tabId)) {
      visionStreamCallbacks.delete(tabId);
      
      // Stop interval if no more streams
      if (visionStreamCallbacks.size === 0) {
        if (visionStreamInterval) {
          clearInterval(visionStreamInterval);
          visionStreamInterval = null;
        }
        visionStreamingActive = false;
      }
      
      return { success: true };
    }
    return { success: false, error: 'No vision stream active for this tab' };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function findElementByVision(tabId, description) {
  try {
    // Take screenshot first
    const screenshot = await takeScreenshot(tabId);
    if (!screenshot.success) {
      return { success: false, error: 'Failed to capture screenshot' };
    }
    
    // Send to backend for vision analysis
    // The backend will use vision models to find the element
    // For now, return screenshot with description for backend processing
    return {
      success: true,
      screenshot: screenshot.dataUrl,
      description: description,
      timestamp: Date.now()
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function clickByCoordinates(tabId, x, y) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (x, y) => {
        // Get element at coordinates
        const element = document.elementFromPoint(x, y);
        if (!element) {
          return { success: false, error: 'No element at coordinates' };
        }
        
        // Scroll element into view
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Wait for scroll, then click
        return new Promise((resolve) => {
          setTimeout(() => {
            const beforeUrl = window.location.href;
            const beforeState = document.readyState;
            
            // Create and dispatch click event
            const clickEvent = new MouseEvent('click', {
              view: window,
              bubbles: true,
              cancelable: true,
              clientX: x,
              clientY: y
            });
            
            element.dispatchEvent(clickEvent);
            
            // Also try native click as fallback
            if (element.click) {
              element.click();
            }
            
            setTimeout(() => {
              const afterUrl = window.location.href;
              const afterState = document.readyState;
              const changed = beforeUrl !== afterUrl || beforeState !== afterState;
              
              resolve({
                success: true,
                element: element.tagName,
                changeDetected: changed,
                coordinates: { x, y }
              });
            }, 100);
          }, 300);
        });
      },
      args: [x, y]
    });
    
    return await results[0].result;
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LLM-FREE ELEMENT FINDING - Text-based search through cached snapshot
// This enables "instant execute" patterns without LLM calls for element discovery
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Get element info by nodeId - used for enriching cached patterns with descriptors.
 * Returns the element's semantic info (name, ariaLabel, role, etc.) so patterns
 * can be replayed even when nodeIds change.
 * 
 * @param {number} tabId - Tab ID
 * @param {number} nodeId - Node ID from snapshot
 * @returns {object} - Element info or error
 */
async function getNodeInfo(tabId, nodeId) {
  // Get active tab if not specified
  if (!tabId) {
    const activeTab = await getActiveTab();
    tabId = activeTab?.id;
  }
  
  if (!tabId) {
    return { success: false, error: 'No tab ID available' };
  }
  
  const tabMapping = nodeIdMappings.get(tabId);
  if (!tabMapping) {
    return { 
      success: false, 
      error: 'No snapshot data for this tab. Call getInteractiveSnapshot first.',
    };
  }
  
  const nodeInfo = tabMapping.get(nodeId);
  if (!nodeInfo) {
    return { 
      success: false, 
      error: `Node ID ${nodeId} not found in snapshot`,
    };
  }
  
  // Return the semantic info that can be used for pattern replay
  return {
    success: true,
    nodeId: nodeId,
    nodeInfo: {
      name: nodeInfo.name,
      ariaLabel: nodeInfo.ariaLabel,
      role: nodeInfo.role,
      type: nodeInfo.type,
      tagName: nodeInfo.tagName,
      placeholder: nodeInfo.placeholder,
      textContent: nodeInfo.textContent,
      title: nodeInfo.title,
      htmlId: nodeInfo.htmlId,
      dataTestId: nodeInfo.dataTestId,
      bounds: nodeInfo.bounds,
      selector: nodeInfo.selector
    }
  };
}

/**
 * Find element in current snapshot by text pattern - NO LLM REQUIRED!
 * Searches: name, ariaLabel, textContent, placeholder, role
 * 
 * @param {number} tabId - Tab ID
 * @param {string} textPattern - Text to search for (case-insensitive, supports | for OR)
 * @param {object} options - Additional matching options
 * @returns {object} - Matched element with nodeId or error
 */
async function findElementByText(tabId, textPattern, options = {}) {
  const tabMapping = nodeIdMappings.get(tabId);
  if (!tabMapping) {
    return { 
      success: false, 
      error: 'No snapshot data for this tab. Call getInteractiveSnapshot first.',
      hint: 'Get a fresh snapshot with get_interactive_snapshot before using find_element_by_text'
    };
  }
  
  const {
    matchType = 'contains',  // 'exact', 'contains', 'startsWith', 'regex'
    role = null,             // Filter by role (button, link, textbox, etc.)
    type = null,             // Filter by type (clickable, typeable, selectable)
    preferVisible = true,    // Prefer elements with larger bounds (more visible)
    maxResults = 5           // Return top N matches
  } = options;
  
  const matches = [];
  const patterns = textPattern.split('|').map(p => p.trim().toLowerCase());
  
  // Search through all elements in the snapshot
  for (const [nodeId, nodeInfo] of tabMapping.entries()) {
    // Build searchable text from all element properties
    const searchableTexts = [
      nodeInfo.name,
      nodeInfo.ariaLabel,
      nodeInfo.textContent,
      nodeInfo.placeholder,
      nodeInfo.title,
      nodeInfo.htmlId,
      nodeInfo.dataTestId
    ].filter(Boolean).map(t => t.toLowerCase());
    
    // Check if any pattern matches any searchable text
    let matchScore = 0;
    let matchedPattern = null;
    let matchedField = null;
    
    for (const pattern of patterns) {
      for (const text of searchableTexts) {
        let matched = false;
        
        if (matchType === 'exact') {
          matched = text === pattern;
        } else if (matchType === 'startsWith') {
          matched = text.startsWith(pattern);
        } else if (matchType === 'regex') {
          try {
            matched = new RegExp(pattern, 'i').test(text);
          } catch (e) {
            matched = text.includes(pattern);
          }
        } else {  // contains (default)
          matched = text.includes(pattern);
        }
        
        if (matched) {
          // Score based on match quality
          if (text === pattern) matchScore = 100;  // Exact match
          else if (text.startsWith(pattern)) matchScore = Math.max(matchScore, 80);
          else matchScore = Math.max(matchScore, 60);
          
          // Boost score for ariaLabel/name matches (more semantic)
          if (text === (nodeInfo.ariaLabel || '').toLowerCase() || 
              text === (nodeInfo.name || '').toLowerCase()) {
            matchScore += 10;
          }
          
          matchedPattern = pattern;
          matchedField = text;
        }
      }
    }
    
    if (matchScore > 0) {
      // Apply role filter
      if (role && nodeInfo.role !== role && nodeInfo.tagName !== role) {
        continue;
      }
      
      // Apply type filter
      if (type && nodeInfo.type !== type) {
        continue;
      }
      
      // Boost score for visible elements (has bounds with positive area)
      if (preferVisible && nodeInfo.bounds) {
        const area = nodeInfo.bounds.width * nodeInfo.bounds.height;
        if (area > 0) matchScore += 5;
        if (area > 1000) matchScore += 5;  // Reasonably sized element
      }
      
      matches.push({
        nodeId: nodeId,
        score: matchScore,
        matchedPattern: matchedPattern,
        matchedField: matchedField,
        name: nodeInfo.name,
        ariaLabel: nodeInfo.ariaLabel,
        role: nodeInfo.role,
        type: nodeInfo.type,
        tagName: nodeInfo.tagName,
        bounds: nodeInfo.bounds,
        selector: nodeInfo.selector,
        htmlId: nodeInfo.htmlId
      });
    }
  }
  
  // Sort by score (highest first)
  matches.sort((a, b) => b.score - a.score);
  
  if (matches.length === 0) {
    return {
      success: false,
      error: `No element found matching "${textPattern}"`,
      searchedPattern: textPattern,
      options: options,
      hint: 'Try a different text pattern or call get_interactive_snapshot to refresh'
    };
  }
  
  const topMatch = matches[0];
  
  return {
    success: true,
    found: true,
    nodeId: topMatch.nodeId,
    score: topMatch.score,
    matchedPattern: topMatch.matchedPattern,
    element: {
      name: topMatch.name,
      ariaLabel: topMatch.ariaLabel,
      role: topMatch.role,
      type: topMatch.type,
      tagName: topMatch.tagName,
      bounds: topMatch.bounds,
      selector: topMatch.selector,
      htmlId: topMatch.htmlId
    },
    alternativeMatches: matches.slice(1, maxResults).map(m => ({
      nodeId: m.nodeId,
      score: m.score,
      name: m.name,
      type: m.type
    }))
  };
}

/**
 * Click element by text pattern - NO LLM REQUIRED!
 * Combines find_element_by_text + click_node in one operation
 * This is the key to instant pattern execution!
 * 
 * @param {number} tabId - Tab ID  
 * @param {string} textPattern - Text to search for
 * @param {object} options - Matching options
 * @returns {object} - Click result
 */
async function clickElementByText(tabId, textPattern, options = {}) {
  // First, find the element
  const findResult = await findElementByText(tabId, textPattern, {
    ...options,
    type: options.type || 'clickable'  // Default to clickable elements
  });
  
  if (!findResult.success) {
    return findResult;
  }
  
  // Then click it
  const clickResult = await clickNode(tabId, findResult.nodeId);
  
  return {
    ...clickResult,
    foundElement: findResult.element,
    matchedPattern: findResult.matchedPattern,
    matchScore: findResult.score,
    method: 'text_pattern'
  };
}

/**
 * Input text into element by text pattern - NO LLM REQUIRED!
 * Combines find_element_by_text + input_text_node in one operation
 * 
 * @param {number} tabId - Tab ID
 * @param {string} textPattern - Text pattern to find the input field
 * @param {string} text - Text to type
 * @param {object} options - Matching options
 * @returns {object} - Input result
 */
async function inputTextByPattern(tabId, textPattern, text, options = {}) {
  // First, find the element
  const findResult = await findElementByText(tabId, textPattern, {
    ...options,
    type: options.type || 'typeable'  // Default to typeable elements
  });
  
  if (!findResult.success) {
    return findResult;
  }
  
  // Then type into it
  const typeResult = await typeIntoNode(tabId, findResult.nodeId, text);
  
  return {
    ...typeResult,
    foundElement: findResult.element,
    matchedPattern: findResult.matchedPattern,
    matchScore: findResult.score,
    method: 'text_pattern'
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// SMART CLICK - Intent-based element clicking with ZERO token bloat!
// ═══════════════════════════════════════════════════════════════════════════════
// 
// This is the key to massive token reduction:
// - Takes a FRESH snapshot internally (no pre-req)
// - Filters by description BEFORE returning to LLM
// - If 1 match → clicks immediately (ZERO LLM disambiguation tokens!)
// - If 2-5 matches → returns ONLY candidates (~200 tokens vs 3000)
// - If 0 matches → returns error with suggestions
//
// Token reduction: 40 elements × 75 tokens = 3000 → 0-375 tokens (87-100% reduction!)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Smart click - takes fresh snapshot, filters by description, auto-clicks if unambiguous
 * 
 * @param {number} tabId - Tab ID
 * @param {string} description - Natural language description like "search button", "compose", "inbox"
 * @param {object} options - Options for matching behavior
 * @returns {object} - Click result or candidates for disambiguation
 */
async function smartClick(tabId, description, options = {}) {
  const {
    autoClick = true,         // Auto-click if only 1 match found
    maxCandidates = 5,        // Max candidates to return for disambiguation
    typeFilter = 'clickable', // 'clickable', 'typeable', 'any'
    strictMatch = false       // Require high confidence match
  } = options;
  
  // Step 1: Take a FRESH snapshot (don't rely on stale cache)
  const snapshotResult = await getInteractiveSnapshot(tabId);
  
  if (!snapshotResult || !snapshotResult.interactiveNodes) {
    return {
      success: false,
      error: 'Failed to get page snapshot',
      hint: 'Make sure the page has loaded completely'
    };
  }
  
  const allElements = snapshotResult.interactiveNodes;
  
  // Step 2: Parse description into search terms
  const descLower = description.toLowerCase().trim();
  const searchTerms = descLower.split(/[\s,]+/).filter(t => t.length > 1);
  
  // Common synonyms for better matching
  const synonyms = {
    'search': ['search', 'find', 'lookup', 'query'],
    'compose': ['compose', 'new', 'write', 'create'],
    'send': ['send', 'submit', 'post', 'publish'],
    'inbox': ['inbox', 'mail', 'messages'],
    'settings': ['settings', 'preferences', 'config', 'options', 'gear', 'cog'],
    'menu': ['menu', 'hamburger', 'nav', 'navigation'],
    'close': ['close', 'x', 'dismiss', 'cancel'],
    'login': ['login', 'sign in', 'signin', 'log in'],
    'logout': ['logout', 'sign out', 'signout', 'log out'],
    'profile': ['profile', 'account', 'user', 'avatar'],
    'home': ['home', 'main', 'dashboard'],
    'back': ['back', 'previous', 'return'],
    'next': ['next', 'forward', 'continue'],
    'save': ['save', 'update', 'apply'],
    'delete': ['delete', 'remove', 'trash', 'bin'],
    'edit': ['edit', 'modify', 'change'],
    'add': ['add', 'plus', 'new', 'create'],
    'refresh': ['refresh', 'reload', 'sync'],
    'download': ['download', 'export', 'save as'],
    'upload': ['upload', 'import', 'attach']
  };
  
  // Expand search terms with synonyms
  const expandedTerms = new Set(searchTerms);
  for (const term of searchTerms) {
    for (const [key, syns] of Object.entries(synonyms)) {
      if (syns.includes(term) || term.includes(key)) {
        syns.forEach(s => expandedTerms.add(s));
      }
    }
  }
  
  // Step 3: Score each element based on description match
  const scoredElements = [];
  
  for (const el of allElements) {
    // Apply type filter
    if (typeFilter === 'clickable' && el.type !== 'clickable') continue;
    if (typeFilter === 'typeable' && el.type !== 'typeable') continue;
    
    // Build searchable text from element
    const searchableText = [
      el.name,
      el.ariaLabel,
      el.role,
      el.tagName,
      el.htmlId,
      el.selector
    ].filter(Boolean).join(' ').toLowerCase();
    
    let score = 0;
    let matchedTerms = [];
    
    // Score based on term matches
    for (const term of expandedTerms) {
      if (searchableText.includes(term)) {
        // Exact word match scores higher
        if (new RegExp(`\\b${term}\\b`).test(searchableText)) {
          score += 30;
        } else {
          score += 15;
        }
        matchedTerms.push(term);
      }
    }
    
    // Bonus for ariaLabel matches (most semantic)
    if (el.ariaLabel) {
      const ariaLower = el.ariaLabel.toLowerCase();
      if (ariaLower.includes(descLower) || descLower.includes(ariaLower)) {
        score += 50;
      }
    }
    
    // Bonus for role matches
    if (el.role) {
      const roleLower = el.role.toLowerCase();
      if (searchTerms.some(t => roleLower.includes(t))) {
        score += 20;
      }
    }
    
    // Bonus for exact name match
    if (el.name && el.name.toLowerCase() === descLower) {
      score += 100;
    }
    
    if (score > 0) {
      scoredElements.push({
        nodeId: el.nodeId,
        score: score,
        matchedTerms: matchedTerms,
        // Minimal info for disambiguation (token efficient!)
        name: (el.name || '').substring(0, 40),
        type: el.type,
        ariaLabel: el.ariaLabel?.substring(0, 30) || null,
        role: el.role
      });
    }
  }
  
  // Sort by score descending
  scoredElements.sort((a, b) => b.score - a.score);
  
  // Step 4: Make decision based on matches
  const candidates = scoredElements.slice(0, maxCandidates);
  
  if (candidates.length === 0) {
    // No matches - return error with available elements for debugging
    const availableTypes = {};
    allElements.forEach(el => {
      availableTypes[el.type] = (availableTypes[el.type] || 0) + 1;
    });
    
    return {
      success: false,
      error: `No element matching "${description}" found`,
      searched: description,
      availableElementTypes: availableTypes,
      totalElements: allElements.length,
      hint: 'Try a different description or use get_interactive_snapshot to see all elements'
    };
  }
  
  if (candidates.length === 1 && autoClick) {
    // Single match - AUTO CLICK! No LLM disambiguation needed!
    const target = candidates[0];
    const clickResult = await clickNode(tabId, target.nodeId);
    
    return {
      success: clickResult.success,
      autoClicked: true,
      clicked: target,
      matchConfidence: target.score,
      message: clickResult.success 
        ? `Auto-clicked "${target.name || target.ariaLabel || description}"`
        : `Found match but click failed: ${clickResult.error}`,
      // Include click result details
      ...clickResult
    };
  }
  
  // Multiple matches - check if top match is significantly better
  if (autoClick && candidates.length >= 2) {
    const topScore = candidates[0].score;
    const secondScore = candidates[1].score;
    
    // If top match is 2x better than second, auto-click it
    if (topScore >= secondScore * 2 && topScore >= 50) {
      const target = candidates[0];
      const clickResult = await clickNode(tabId, target.nodeId);
      
      return {
        success: clickResult.success,
        autoClicked: true,
        clicked: target,
        matchConfidence: target.score,
        message: clickResult.success 
          ? `Auto-clicked best match "${target.name || target.ariaLabel || description}"`
          : `Found best match but click failed: ${clickResult.error}`,
        otherCandidates: candidates.slice(1),
        ...clickResult
      };
    }
  }
  
  // Multiple ambiguous matches - return candidates for LLM to pick
  // This is MUCH smaller than full snapshot! (5 elements vs 40)
  return {
    success: true,
    autoClicked: false,
    needsDisambiguation: true,
    message: `Found ${candidates.length} possible matches for "${description}"`,
    candidates: candidates,
    hint: 'Call click_node with the nodeId of the correct element'
  };
}

/**
 * Smart type - takes fresh snapshot, finds input by description, types into it
 * 
 * @param {number} tabId - Tab ID
 * @param {string} description - Natural language description of the input field
 * @param {string} text - Text to type
 * @param {object} options - Options for matching behavior
 * @returns {object} - Type result or candidates for disambiguation
 */
async function smartType(tabId, description, text, options = {}) {
  // Use smart click logic but for typeable elements
  const result = await smartClick(tabId, description, {
    ...options,
    typeFilter: 'typeable',
    autoClick: false  // Don't click, we'll type instead
  });
  
  if (!result.success && !result.needsDisambiguation) {
    return result;
  }
  
  // Get the target element
  let targetNodeId;
  
  if (result.autoClicked) {
    // Already found single match
    targetNodeId = result.clicked.nodeId;
  } else if (result.candidates && result.candidates.length > 0) {
    // Take the best match
    if (result.candidates.length === 1 || result.candidates[0].score >= result.candidates[1]?.score * 2) {
      targetNodeId = result.candidates[0].nodeId;
    } else {
      // Ambiguous - return candidates for disambiguation
      return {
        ...result,
        message: `Found ${result.candidates.length} input fields matching "${description}"`,
        hint: 'Call input_text_node with the nodeId of the correct field'
      };
    }
  }
  
  if (!targetNodeId) {
    return {
      success: false,
      error: `No input field matching "${description}" found`
    };
  }
  
  // Type into the element
  const typeResult = await inputTextNode(tabId, targetNodeId, text);
  
  return {
    ...typeResult,
    targetDescription: description,
    text: text.substring(0, 50) + (text.length > 50 ? '...' : ''),
    method: 'smart_type'
  };
}

async function getBrowserProcessInfo(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    
    // Get basic tab info
    const processInfo = {
      tabId: tab.id,
      url: tab.url,
      title: tab.title,
      status: tab.status,
      active: tab.active,
      windowId: tab.windowId,
      index: tab.index,
      pinned: tab.pinned,
      audible: tab.audible,
      mutedInfo: tab.mutedInfo,
      discarded: tab.discarded,
      autoDiscardable: tab.autoDiscardable,
      timestamp: Date.now()
    };
    
    // Try to get more detailed process info (if available)
    try {
      const processId = await chrome.processes.getProcessIdForTab(tabId);
      if (processId) {
        processInfo.processId = processId;
      }
    } catch (e) {
      // Process API might not be available in all Chrome versions
    }
    
    return { success: true, processInfo };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getAllWindows() {
  try {
    const windows = await chrome.windows.getAll({ populate: true });
    return {
      success: true,
      windows: windows.map(win => ({
        id: win.id,
        focused: win.focused,
        top: win.top,
        left: win.left,
        width: win.width,
        height: win.height,
        state: win.state,
        type: win.type,
        tabs: win.tabs ? win.tabs.map(tab => ({
          id: tab.id,
          url: tab.url,
          title: tab.title,
          active: tab.active
        })) : []
      }))
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function createNewTab(url, windowId) {
  try {
    const tab = await chrome.tabs.create({
      url: url || 'about:blank',
      windowId: windowId
    });
    
    return {
      success: true,
      tab: {
        id: tab.id,
        url: tab.url,
        title: tab.title,
        windowId: tab.windowId
      }
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function closeTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function monitorTabChanges(tabId) {
  try {
    // Set up listeners for tab changes
    const changeListener = (changedTabId, changeInfo, tab) => {
      if (changedTabId === tabId) {
        sendToDesktopApp({
          type: 'tab_changed',
          tabId: tabId,
          changeInfo: changeInfo,
          tab: {
            id: tab.id,
            url: tab.url,
            title: tab.title,
            status: tab.status
          }
        });
      }
    };
    
    chrome.tabs.onUpdated.addListener(changeListener);
    
    // Store listener for cleanup
    tabProcessInfo.set(tabId, { listener: changeListener });
    
    return { success: true, message: 'Monitoring tab changes' };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getTabContext(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const profileInfo = await getProfileInfo(tabId);
    
    // Get more detailed context
    const pageInfo = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        return {
          url: window.location.href,
          title: document.title,
          readyState: document.readyState,
          hasLocalStorage: typeof localStorage !== 'undefined',
          hasSessionStorage: typeof sessionStorage !== 'undefined',
          cookieCount: document.cookie.split(';').filter(c => c.trim()).length
        };
      }
    }).catch(() => ({ result: null }));
    
    return {
      success: true,
      tab: {
        id: tab.id,
        url: tab.url,
        title: tab.title,
        windowId: tab.windowId,
        active: tab.active,
        status: tab.status
      },
      profile: profileInfo,
      page: pageInfo[0]?.result || null
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function getAllProfiles() {
  try {
    // Get all windows and their tabs
    const windows = await chrome.windows.getAll({ populate: true });
    
    const profiles = [];
    for (const window of windows) {
      if (window.tabs) {
        for (const tab of window.tabs.slice(0, 10)) { // Limit for performance
          if (tab.url && tab.url.startsWith('http')) {
            try {
              const profileInfo = await getProfileInfo(tab.id);
              profiles.push({
                tabId: tab.id,
                url: tab.url,
                title: tab.title,
                domain: new URL(tab.url).hostname,
                profile: profileInfo
              });
            } catch (e) {
              // Skip tabs that can't be accessed
            }
          }
        }
      }
    }
    
    return {
      success: true,
      profiles: profiles,
      totalWindows: windows.length,
      totalTabs: windows.reduce((sum, w) => sum + (w.tabs?.length || 0), 0)
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Tab monitoring for process info
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabProcessInfo.has(tabId)) {
    const info = tabProcessInfo.get(tabId);
    info.status = changeInfo.status || tab.status;
    info.url = changeInfo.url || tab.url;
    info.title = changeInfo.title || tab.title;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  // Clean up monitoring
  if (tabProcessInfo.has(tabId)) {
    tabProcessInfo.delete(tabId);
  }
  
  // Clean up vision streams
  if (visionStreamCallbacks.has(tabId)) {
    stopVisionStream(tabId);
  }
  
  // CRITICAL: Do NOT close WebSocket connection when tabs close
  // The extension should maintain persistent connection regardless of tab state
  // WebSocket connection is independent of tabs - it's a background service
  logWithTimestamp('debug', '🗑️ Tab closed - cleaned up tab-specific data (WebSocket connection preserved)', {
    tabId,
    wsConnectionState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
    note: 'WebSocket connection is independent of tabs and remains active'
  });
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'check_status') {
    // Check if connected via any method
    const isConnected = (communicationMethod === 'native_messaging' && nativeMessagingAvailable) ||
                        (wsConnection && wsConnection.readyState === WebSocket.OPEN);
    
    sendResponse({
      connected: isConnected,
      connectionMethod: communicationMethod,  // 'native_messaging' | 'websocket' | 'disconnected'
      nativeMessagingAvailable: nativeMessagingAvailable,
      webSocketConnected: wsConnection && wsConnection.readyState === WebSocket.OPEN,
      version: '2.0.0',
      capabilities: [
        'native_messaging',
        'vision_streaming',
        'full_page_screenshots',
        'element_screenshots',
        'vision_based_detection',
        'coordinate_clicking',
        'process_monitoring',
        'window_management'
      ]
    });
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'reconnect') {
    logWithTimestamp('info', '🔄 Manual reconnect requested from popup', {
      currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
      reconnectAttempts
    });
    
    // Close existing connection if it exists
    if (wsConnection) {
      try {
        // Remove event handlers to prevent race conditions
        wsConnection.onclose = null;
        wsConnection.onerror = null;
        wsConnection.onmessage = null;
        wsConnection.close();
      } catch (e) {
        logWithTimestamp('warn', '⚠️ Error closing connection during reconnect', {
          error: e.message
        });
      }
      wsConnection = null;
    }
    
    // Reset reconnect attempts and connect
    reconnectAttempts = 0;
    
    // Small delay to ensure previous connection is fully closed
    setTimeout(() => {
      connectToDesktopApp();
    }, 100);
    
    sendResponse({ success: true });
    return true;
  }
  
  // Handle tool execution from popup (for interactive elements, highlights, etc.)
  if (message.type === 'execute_tool') {
    const { tool, params } = message;
    logWithTimestamp('info', `🔧 Popup requested tool execution: ${tool}`, { params });
    
    (async () => {
      try {
        let result;
        switch (tool) {
          case 'get_interactive_snapshot':
            result = await getInteractiveSnapshot(params.tabId);
            break;
          case 'get_interactive_elements':
            result = await getInteractiveElements(params.tabId);
            break;
          case 'show_highlights':
            result = await showInteractiveHighlights(params.tabId, params.showLabels);
            break;
          case 'clear_visuals':
            result = await clearAllVisuals(params.tabId);
            break;
          default:
            result = { success: false, error: `Unknown tool: ${tool}` };
        }
        sendResponse(result);
      } catch (error) {
        logWithTimestamp('error', `❌ Tool execution failed: ${tool}`, { error: error.message });
        sendResponse({ success: false, error: error.message });
      }
    })();
    
    return true; // Keep channel open for async response
  }
  
  // Handle DOM change notifications from content script (for SPA cache invalidation)
  if (message.type === 'centris_dom_changed') {
    logWithTimestamp('debug', '🔄 DOM change detected - forwarding to backend for cache invalidation', {
      url: message.url,
      addedNodes: message.addedNodes,
      removedNodes: message.removedNodes
    });
    
    // Forward to backend to invalidate snapshot cache
    const tabId = sender.tab?.id;
    if (tabId) {
      sendToBackend({
        type: 'dom_changed',
        tabId: tabId,
        url: message.url,
        timestamp: message.timestamp
      });
    }
    
    sendResponse({ success: true });
    return true;
  }
  
  // Handle SPA navigation notifications
  if (message.type === 'centris_spa_navigation') {
    logWithTimestamp('debug', '🔄 SPA navigation detected - forwarding to backend', {
      url: message.url,
      method: message.navigationMethod
    });
    
    // Forward to backend to invalidate snapshot cache
    const tabId = sender.tab?.id;
    if (tabId) {
      sendToBackend({
        type: 'spa_navigation',
        tabId: tabId,
        url: message.url,
        navigationMethod: message.navigationMethod,
        timestamp: message.timestamp
      });
    }
    
    sendResponse({ success: true });
    return true;
  }
  
  return false;
});

// Connect on browser startup (when Chrome starts)
chrome.runtime.onStartup.addListener(() => {
  logWithTimestamp('info', '🚀 Browser startup detected - initiating connection', {
    event: 'onStartup',
    timestamp: new Date().toISOString()
  });
  connectToDesktopApp();
});

// Connect on extension install/update
chrome.runtime.onInstalled.addListener((details) => {
  logWithTimestamp('info', '📦 Extension installed/updated - initiating connection', {
    event: 'onInstalled',
    reason: details.reason,
    previousVersion: details.previousVersion,
    timestamp: new Date().toISOString()
  });
  connectToDesktopApp();
});

// Initial connection attempt (when extension loads) - IMMEDIATE, NO DELAY
// This ensures extension connects as soon as it loads
// Priority: Native Messaging first (faster), WebSocket fallback
if (communicationMethod === 'disconnected' || 
    (!wsConnection || (wsConnection.readyState !== WebSocket.OPEN && wsConnection.readyState !== WebSocket.CONNECTING))) {
  logWithTimestamp('info', '🔌 Initial connection attempt (extension loaded - IMMEDIATE)', {
    event: 'initialLoad',
    currentMethod: communicationMethod,
    currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
    timestamp: new Date().toISOString(),
    note: 'Trying Native Messaging first, then WebSocket fallback'
  });
  // Use unified initialization that tries Native Messaging first
  initializeCommunication();
} else {
  logWithTimestamp('info', '✅ Already connected or connecting - skipping initial attempt', {
    event: 'initialLoad',
    currentMethod: communicationMethod,
    currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
    timestamp: new Date().toISOString()
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// MEMORY & CONTEXT MODULE INITIALIZATION
// ═══════════════════════════════════════════════════════════════════════════════
// Initialize TabContextManager and CrossTabSync for memory persistence

(async function initializeMemoryModules() {
  try {
    // Initialize Tab Context Manager
    if (typeof tabContextManager !== 'undefined') {
      const sessionId = await tabContextManager.init();
      logWithTimestamp('info', '🧠 TabContextManager initialized', {
        sessionId: sessionId,
        timestamp: new Date().toISOString()
      });
      
      // Add listener to sync context updates to backend
      tabContextManager.addListener((eventType, data) => {
        if (eventType === 'context_updated') {
          logWithTimestamp('debug', '📋 Tab context updated', { tabId: data.tabId });
        }
      });
    } else {
      logWithTimestamp('warn', '⚠️ TabContextManager not available');
    }
    
    // Initialize Cross-Tab Sync
    if (typeof crossTabSync !== 'undefined') {
      await crossTabSync.init();
      logWithTimestamp('info', '🔄 CrossTabSync initialized', {
        memoryCount: crossTabSync.memoryCache?.length || 0,
        timestamp: new Date().toISOString()
      });
      
      // Add listener for memory updates
      crossTabSync.onMemoryUpdate((eventType, data) => {
        logWithTimestamp('debug', `📝 Memory update: ${eventType}`, { data });
        
        // Forward memory updates to backend if connected
        if (eventType === 'memory_added' && wsConnection && wsConnection.readyState === WebSocket.OPEN) {
          wsConnection.send(JSON.stringify({
            type: 'memory_sync',
            event: eventType,
            memory: data,
            timestamp: Date.now()
          }));
        }
      });
    } else {
      logWithTimestamp('warn', '⚠️ CrossTabSync not available');
    }
    
    logWithTimestamp('info', '✅ Memory modules initialization complete');
    
  } catch (error) {
    logWithTimestamp('error', '❌ Failed to initialize memory modules', {
      error: error.message,
      stack: error.stack
    });
  }
})();

// ═══════════════════════════════════════════════════════════════════════════════
// READING MODE - Text Extraction Functions
// ═══════════════════════════════════════════════════════════════════════════════
// These functions support Reading Mode - extracting text from web pages for TTS

/**
 * Extract readable content from the active tab for Reading Mode.
 * Sends message to content script to extract article/email/selection.
 */
async function extractReadableContentFromTab(tabId) {
  try {
    // Get the tab ID if not provided
    if (!tabId || tabId === 'active') {
      const activeTab = await getActiveTab();
      if (activeTab.error || !activeTab.id) {
        return { success: false, error: activeTab.error || 'No active tab found' };
      }
      tabId = activeTab.id;
    }
    
    // Ensure content script is injected
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => window.__centrisContentScriptLoaded = true
      });
    } catch (e) {
      // Content script might already be loaded or page is not injectable
      logWithTimestamp('debug', 'Content script injection check:', e.message);
    }
    
    // Send message to content script
    const result = await chrome.tabs.sendMessage(tabId, {
      action: 'getReadableContent'
    });
    
    if (result && result.success) {
      logWithTimestamp('info', '📖 Extracted readable content', {
        tabId,
        type: result.type,
        textLength: result.text?.length || 0,
        title: result.title?.substring(0, 50)
      });
      return {
        success: true,
        text: result.text,
        title: result.title,
        type: result.type,
        source: result.source || result.type
      };
    }
    
    return {
      success: false,
      error: result?.error || 'Failed to extract content'
    };
  } catch (error) {
    logWithTimestamp('error', '📖 Extract readable content error:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Get selected text from the active tab.
 */
async function getSelectedTextFromTab(tabId) {
  try {
    if (!tabId || tabId === 'active') {
      const activeTab = await getActiveTab();
      if (activeTab.error || !activeTab.id) {
        return { success: false, error: activeTab.error || 'No active tab found' };
      }
      tabId = activeTab.id;
    }
    
    const result = await chrome.tabs.sendMessage(tabId, {
      type: 'centris_get_selected_text'
    });
    
    return {
      success: result?.success || false,
      text: result?.text || '',
      length: result?.length || 0
    };
  } catch (error) {
    logWithTimestamp('error', '📖 Get selected text error:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Show reading mode indicator on the page.
 */
async function showReadingIndicatorOnTab(tabId, title = 'Reading...', progress = 0) {
  try {
    if (!tabId || tabId === 'active') {
      const activeTab = await getActiveTab();
      if (activeTab.error || !activeTab.id) {
        return { success: false, error: activeTab.error || 'No active tab found' };
      }
      tabId = activeTab.id;
    }
    
    await chrome.tabs.sendMessage(tabId, {
      type: 'centris_show_reading_indicator',
      title,
      progress
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Hide reading mode indicator.
 */
async function hideReadingIndicatorOnTab(tabId) {
  try {
    if (!tabId || tabId === 'active') {
      const activeTab = await getActiveTab();
      if (activeTab.error || !activeTab.id) {
        return { success: false, error: activeTab.error || 'No active tab found' };
      }
      tabId = activeTab.id;
    }
    
    await chrome.tabs.sendMessage(tabId, {
      type: 'centris_hide_reading_indicator'
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * Update reading progress on the page.
 */
async function updateReadingProgressOnTab(tabId, progress) {
  try {
    if (!tabId || tabId === 'active') {
      const activeTab = await getActiveTab();
      if (activeTab.error || !activeTab.id) {
        return { success: false, error: activeTab.error || 'No active tab found' };
      }
      tabId = activeTab.id;
    }
    
    // Execute script directly to update progress (faster than message passing)
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: (p) => {
        const progressBar = document.getElementById('centris-reading-progress');
        if (progressBar) {
          progressBar.style.width = `${p}%`;
        }
      },
      args: [progress]
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// CRITICAL: Keep service worker alive to prevent WebSocket disconnection
// Chrome Manifest V3 suspends service workers when idle, which kills WebSocket connections
// Solution: Use chrome.alarms to wake up service worker periodically
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keep_alive') {
    // Wake up service worker - this prevents suspension
    logWithTimestamp('debug', '⏰ Keep-alive alarm fired - service worker kept alive', {
      event: 'keepAlive',
      timestamp: new Date().toISOString()
    });
    
    // Check connection status and reconnect if needed
    if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
      logWithTimestamp('info', '🔄 Keep-alive check: Connection lost, reconnecting', {
        event: 'keepAliveReconnect',
        currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
        timestamp: new Date().toISOString()
      });
      connectToDesktopApp();
    }
  } else if (alarm.name === 'command_keep_alive') {
    // Command-specific keep-alive - wake up service worker and reschedule
    // This is fired every 3 seconds during command execution to prevent suspension
    logWithTimestamp('debug', '🔋 Command keep-alive alarm fired', {
      event: 'commandKeepAlive',
      activeCommands: activeCommands.size,
      timestamp: new Date().toISOString()
    });
    
    // CRITICAL: Reschedule keep-alive if commands are still active
    // This ensures continuous keep-alive during long operations
    if (activeCommands.size > 0 && commandKeepAliveActive) {
      chrome.alarms.create('command_keep_alive', { delayInMinutes: 0.05 }); // Reschedule for 3 seconds
      
      // Also send a ping to keep WebSocket connection alive
      if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
        try {
          // Send a small ping message to keep connection alive
          wsConnection.send(JSON.stringify({ type: 'ping', timestamp: Date.now() }));
        } catch (e) {
          // Ignore ping errors - connection might be closing
        }
      }
    }
  }
});

// Create keep-alive alarm (fires every 5 seconds to prevent service worker suspension)
// AGGRESSIVE keep-alive: Chrome Manifest V3 aggressively suspends service workers
// This ensures WebSocket connection stays alive even when user switches tabs/apps
chrome.alarms.create('keep_alive', { periodInMinutes: 0.083 }); // 5 seconds

// Periodic reconnection check (every 30 seconds if disconnected)
// Also checks if extension is disabled or Chrome crashed
setInterval(() => {
  // MVP: Check if extension is still enabled (Chrome crash detection)
  try {
    // If we can't access chrome.runtime, extension might be disabled
    if (!chrome.runtime || !chrome.runtime.id) {
      logWithTimestamp('error', '⚠️ Extension may be disabled or Chrome crashed', {
        event: 'extensionStatusCheck',
        timestamp: new Date().toISOString()
      });
      // Try to reconnect - if extension is disabled, this will fail silently
      connectToDesktopApp();
      return;
    }
  } catch (e) {
    logWithTimestamp('error', '⚠️ Extension status check failed - possible Chrome crash', {
      event: 'extensionStatusCheck',
      error: e.message,
      timestamp: new Date().toISOString()
    });
    // Try to reconnect
    connectToDesktopApp();
    return;
  }

  if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
    logWithTimestamp('info', '🔄 Periodic reconnection check - connection lost, reconnecting', {
      event: 'periodicCheck',
      currentState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
      reconnectAttempts,
      timestamp: new Date().toISOString()
    });
    // Reset reconnect attempts for periodic checks (allows recovery after Chrome restart)
    reconnectAttempts = 0;
    connectToDesktopApp();
  } else {
    // Log connection health periodically
    logWithTimestamp('debug', '✅ Connection health check - connected', {
      event: 'periodicCheck',
      readyState: wsConnection ? getWebSocketStateName(wsConnection.readyState) : 'null',
      messagesSent: connectionState.messageCount.sent,
      messagesReceived: connectionState.messageCount.received,
      handshakeSent: connectionState.handshakeSent,
      handshakeAcknowledged: connectionState.handshakeAcknowledged,
      timestamp: new Date().toISOString()
    });
  }
}, 30000); // Check every 30 seconds

