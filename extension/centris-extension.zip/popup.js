// Centris AI Extension Popup

document.addEventListener('DOMContentLoaded', () => {
  const dot = document.getElementById('dot');
  const reconnectBtn = document.getElementById('reconnect');
  
  // Initialize galaxy background
  initGalaxy();
  
  function updateStatus(connected) {
    if (connected) {
      dot.classList.add('connected');
    } else {
      dot.classList.remove('connected');
    }
    reconnectBtn.disabled = false;
  }
  
  function checkStatus() {
    chrome.runtime.sendMessage({ type: 'check_status' }, (response) => {
      if (chrome.runtime.lastError) {
        updateStatus(false);
      } else {
        updateStatus(response?.connected || false);
      }
    });
  }
  
  checkStatus();
  
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'extension_ready') {
      updateStatus(true);
    }
  });
  
  reconnectBtn.addEventListener('click', () => {
    reconnectBtn.disabled = true;
    dot.classList.remove('connected');
    
    chrome.runtime.sendMessage({ type: 'reconnect' }, () => {
      let attempts = 0;
      const check = () => {
        chrome.runtime.sendMessage({ type: 'check_status' }, (response) => {
          if (response?.connected) {
            updateStatus(true);
          } else if (attempts++ < 6) {
            setTimeout(check, 500);
          } else {
            updateStatus(false);
          }
        });
      };
      setTimeout(check, 500);
    });
  });
});

// Animated Galaxy Background - matching Sentris landing page style
function initGalaxy() {
  const canvas = document.getElementById('galaxy');
  const ctx = canvas.getContext('2d');
  
  let width = canvas.width = 280;
  let height = canvas.height = 320;
  
  const stars = [];
  const starCount = 150;
  
  class Star {
    constructor() {
      this.reset();
    }
    
    reset() {
      this.x = Math.random() * width;
      this.y = Math.random() * height;
      this.z = Math.random() * 1000 + 200;
      this.baseOpacity = Math.random() * 0.5 + 0.3;
      this.twinkleSpeed = Math.random() * 0.02 + 0.01;
      this.twinkleOffset = Math.random() * Math.PI * 2;
      this.speed = Math.random() * 0.15 + 0.05;
    }
    
    update(time) {
      this.z -= this.speed;
      if (this.z <= 0) {
        this.reset();
        this.z = 1000;
      }
      this.currentOpacity = this.baseOpacity * (0.7 + 0.3 * Math.sin(time * this.twinkleSpeed + this.twinkleOffset));
    }
    
    draw() {
      const cx = width / 2;
      const cy = height / 2;
      const k = 64 / this.z;
      const px = (this.x - cx) * k + cx;
      const py = (this.y - cy) * k + cy;
      
      if (px < 0 || px > width || py < 0 || py > height) {
        this.reset();
        return;
      }
      
      const size = Math.max(0.3, (1 - this.z / 1000) * 1.8);
      const opacity = Math.max(0.1, this.currentOpacity * (1 - this.z / 1200));
      
      const gradient = ctx.createRadialGradient(px, py, 0, px, py, size * 3);
      gradient.addColorStop(0, `rgba(255, 255, 255, ${opacity})`);
      gradient.addColorStop(0.5, `rgba(255, 255, 255, ${opacity * 0.3})`);
      gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
      
      ctx.beginPath();
      ctx.arc(px, py, size * 3, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(px, py, size * 0.5, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(1, opacity * 1.5)})`;
      ctx.fill();
    }
  }
  
  for (let i = 0; i < starCount; i++) {
    stars.push(new Star());
  }
  
  let time = 0;
  
  function animate() {
    time += 16;
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
    ctx.fillRect(0, 0, width, height);
    
    stars.forEach(star => {
      star.update(time);
      star.draw();
    });
    
    requestAnimationFrame(animate);
  }
  
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);
  
  animate();
}
